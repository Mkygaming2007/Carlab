import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('node_modules')) {
              // Bundle core rendering engines together
              if (id.includes('react') || id.includes('react-dom') || id.includes('motion')) {
                return 'vendor-render-core';
              }
              // Separate heavy telemetry graphing systems
              if (id.includes('recharts') || id.includes('d3')) {
                return 'vendor-telemetry-charts';
              }
              return 'vendor-subsystems';
            }
          }
        }
      },
      chunkSizeWarningLimit: 900,
      minify: 'esbuild',
      cssMinify: true,
      sourcemap: false // reduce production deployment weight
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
