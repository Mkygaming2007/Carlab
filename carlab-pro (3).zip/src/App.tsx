import React, { useState, useEffect, useRef } from 'react';
import {
  Activity,
  Cpu,
  Flame,
  Fuel,
  Gauge,
  Layers,
  Settings,
  Save,
  Share2,
  Printer,
  Play,
  RotateCcw,
  Sparkles,
  TrendingUp,
  Clock,
  Wrench,
  Check,
  ChevronDown,
  ChevronRight,
  Plus,
  Trash,
  Bot,
  Info,
  Loader2,
  AlertTriangle,
  ZoomIn,
  ZoomOut,
  Car,
  MousePointerClick
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { COMPONENT_CATALOG, ComponentItem } from './data/components';
import { CarPlatform, VEHICLE_DATABASE } from './data/carDatabase';
import { EngineState, MODIFICATIONS_LIBRARY, mapEngineStateToDSP, createBaseEngineState, applyMods, clampToCarLimits, getAvailableMods } from './data/modificationRules';
import { ExhaustSynthEngine } from './data/ExhaustSynthEngine';
import { EngineControlPanel } from './components/EngineControlPanel';
import { ModificationBrowser } from './components/ModificationBrowser';
import { AdvancedModificationPanel } from './components/AdvancedModificationPanel';
import { ErrorBoundary } from './components/ErrorBoundary';
import { SelectedBuildSummary } from './components/SelectedBuildSummary';
import { VEHICLE_MODS_DATABASE, applySelectedModsToEngine } from './data/modsDatabase';
import { deserializeBuild } from './data/shareSystem';

const getCarPlatform = (vehicleId: string): CarPlatform => {
  const vehicleIdMap: Record<string, string> = {
    'polo-gt': 'polo-1.0tsi',
    'swift-k12': 'swift-k12',
    'thar-mstallion': 'thar-2.0tgdi',
    'civic-1.5t': 'civic-1.5t',
    'bmw-e46': 'bmw-e46-m3',
    'shelby-v8': 'shelby-gt500',
    'custom-tuner': 'project-custom',
    'custom-project-car': 'project-custom',
  };
  const targetId = vehicleIdMap[vehicleId] || 'project-custom';
  return VEHICLE_DATABASE.find(c => c.id === targetId) || VEHICLE_DATABASE[0];
};

export interface CanvasNode {
  id: string;
  componentId: string;
  x: number;
  y: number;
  category: string;
  brand: string;
  name: string;
  model: string;
}

export interface Connection {
  id: string;
  fromNode: string;
  fromPort: string;
  toNode: string;
  toPort: string;
}

const getPortsForCategory = (category: string) => {
  switch (category) {
    case 'Engine Block':
      return {
        inputs: ['air-in', 'fuel-in', 'ecu-in', 'internals-in'],
        outputs: ['exhaust-out']
      };
    case 'Forced Induction':
      return {
        inputs: ['in'],
        outputs: ['out']
      };
    case 'Cooling System':
      return {
        inputs: ['in'],
        outputs: ['out']
      };
    case 'Fuel System':
      return {
        inputs: [],
        outputs: ['out']
      };
    case 'Electronics':
      return {
        inputs: [],
        outputs: ['out']
      };
    case 'Engine Internals':
      return {
        inputs: [],
        outputs: ['out']
      };
    case 'Exhaust System':
      return {
        inputs: ['in'],
        outputs: []
      };
    default:
      return { inputs: [], outputs: [] };
  }
};

// Theme Settings Matching Specifications
const THEME_COLORS = {
  background: "#050716", // Deep dark blue-black
  panel: "#0c0e25",      // Slightly lighter sidebar blue
  canvas: "#07091a",     // Canvas slate tone
  accent: "#8a2be2",     // Purple
  secondary: "#ff6b35",  // Orange
};

const COMPONENT_COLORS = {
  "Engine Block": "#06b6d4",      // Cyan
  "Forced Induction": "#10b981",  // Green
  "Fuel System": "#8b5cf6",        // Purple
  "Engine Internals": "#ec4899",   // Pink
  "Electronics": "#ef4444",        // Red
  "Cooling System": "#0891b2",     // Teal
  "Exhaust System": "#f97316",     // Orange
};

export interface VehicleProfile {
  id: string;
  name: string;
  brand: string;
  year: string;
  baseHP: number;
  baseTorque: number;
  baseWeight: number;
  baseRedline: number;
  cylinders: number;
  displacement: string;
  difficulty: string;
  description: string;
}

const VEHICLE_PROFILES: VehicleProfile[] = [
  {
    id: 'polo-gt',
    name: 'Polo GT 1.0 TSI (Stage 2)',
    brand: 'Volkswagen India',
    year: '2021',
    baseHP: 110,
    baseTorque: 175,
    baseWeight: 1070,
    baseRedline: 6800,
    cylinders: 3,
    displacement: '1.0 Liters TSI',
    difficulty: 'Stage 2 Ready',
    description: 'The absolute king of Indian tuner hatchbacks. The 1.0 TSI three-cylinder engine is highly responsive to de-cat downpipes, Stage 2 premium ECU remaps, high-flow intercoolers, and aggressive pops-and-bangs ignition maps!'
  },
  {
    id: 'swift-k12',
    name: 'Swift Pocket Rocket K12',
    brand: 'Maruti Suzuki',
    year: '2024',
    baseHP: 89,
    baseTorque: 113,
    baseWeight: 890,
    baseRedline: 6500,
    cylinders: 4,
    displacement: '1.2 Liters K-Series',
    difficulty: 'Street Cruiser',
    description: 'India\'s most popular custom project car platform. Extremely lightweight chassis (under 900kg) that makes it incredibly nimble on winding roads. Sounds spectacular with a custom valvetronic track-pipe exhaust bypass!'
  },
  {
    id: 'thar-mstallion',
    name: 'Thar mStallion 2.0T 4x4',
    brand: 'Mahindra',
    year: '2023',
    baseHP: 150,
    baseTorque: 320,
    baseWeight: 1750,
    baseRedline: 5500,
    cylinders: 4,
    displacement: '2.0 Liters mStallion',
    difficulty: 'High-Torque Builder',
    description: 'Rugged Indian 4x4 offroad icon powered by the heavy duty mStallion turbo gasoline engine. Excellent torque capability, responds beautifully to high flow downpipes, large intercooler upgrades, and performance tuning.'
  },
  {
    id: 'civic-1.5t',
    name: 'JDM Civic Si 1.5T',
    brand: 'Honda',
    year: '2023',
    baseHP: 180,
    baseTorque: 240,
    baseWeight: 1280,
    baseRedline: 7200,
    cylinders: 4,
    displacement: '1.5 Liters',
    difficulty: 'Beginner Tuner',
    description: 'A light-weight front-wheel drive corner carver. Its small L15B7 turbo engine has rapid spooling but needs forged internals for high boost thresholds.'
  },
  {
    id: 'bmw-e46',
    name: 'M3 Euro Coupe E46',
    brand: 'BMW',
    year: '2004',
    baseHP: 343,
    baseTorque: 365,
    baseWeight: 1540,
    baseRedline: 8000,
    cylinders: 6,
    displacement: '3.2 Liters',
    difficulty: 'Advanced Drift',
    description: 'Iconic high-revving naturally aspirated S54 inline-6. Upgrading this masterpiece requires premium balanced crank balancing and titanium parts.'
  },
  {
    id: 'shelby-v8',
    name: 'Shelby GT500 Drag-Spec',
    brand: 'Ford',
    year: '2021',
    baseHP: 760,
    baseTorque: 850,
    baseWeight: 1810,
    baseRedline: 7500,
    cylinders: 8,
    displacement: '5.2 Liters',
    difficulty: 'Extreme Drag',
    description: 'A giant supercharged V8 beast with ground-shaking muscle torque. Relies on heavy cooling systems to prevent severe supercharger heat soak.'
  },
  {
    id: 'custom-tuner',
    name: 'Custom Tuner Project',
    brand: 'Project Car',
    year: 'Built',
    baseHP: 150,
    baseTorque: 190,
    baseWeight: 1100,
    baseRedline: 6800,
    cylinders: 4,
    displacement: '2.0 Liters',
    difficulty: 'Unrestricted Build',
    description: 'A stripped-down, lightweight project shell. Highly adaptable. Starting from modest NA power, ready to be turbocharged or wired with extreme ECUs.'
  }
];

export interface SubPartItem {
  name: string;
  brand: string;
  powerBonus: number;
  torqueBonus: number;
  cost: number;
  weight: number;
  tempIncrease: number;
  reliabilityBonus: number;
  description: string;
}

const SUBPART_CATALOG: Record<string, Record<string, SubPartItem>> = {
  pistons: {
    stock: { name: 'Stock Cast Pistons', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard factory pistons. Fine for low boost but will buckle/melt under heavy cylinder load.' },
    'je-forged': { name: 'JE Forged 2618', brand: 'JE Pistons', powerBonus: 15, torqueBonus: 10, cost: 1100, weight: -0.8, tempIncrease: -2, reliabilityBonus: 12, description: 'High strength forged aluminum alloy pistons. Can handle up to 2.2 Bar boost without fatigue.' },
    'wiseco-forged': { name: 'Wiseco ArmorGlide Forged', brand: 'Wiseco', powerBonus: 25, torqueBonus: 15, cost: 1350, weight: -1.2, tempIncrease: -4, reliabilityBonus: 16, description: 'Ultimate armor-coated piston domes. High silicon alloy, supports extremes of modern tuning.' }
  },
  pistonSize: {
    stock: { name: 'Stock Cylinder Bore', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard cylinder diameter.' },
    'overbore-0.5': { name: '+0.5mm Cylinder Overbore', brand: 'Machine Shop', powerBonus: 12, torqueBonus: 15, cost: 450, weight: 0.1, tempIncrease: 1, reliabilityBonus: -2, description: 'Increases displacement and cylinder capacity. More natural combustion space.' },
    'overbore-1.0': { name: '+1.0mm Max Overbore', brand: 'Machine Shop', powerBonus: 26, torqueBonus: 30, cost: 890, weight: 0.2, tempIncrease: 3, reliabilityBonus: -5, description: 'Maximum safe bore expansion. Delivers extra torque and power across the powerband!' }
  },
  crankshaft: {
    stock: { name: 'Stock Cast Crankshaft', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard factory cast shaft. Low balancing rating.' },
    'eagle-forged': { name: 'Eagle Forged 4340', brand: 'Eagle', powerBonus: 15, torqueBonus: 20, cost: 1600, weight: -1.4, tempIncrease: 0, reliabilityBonus: 10, description: 'Forged steel counter-weighted shaft. Resists twist. Adds high durability.' },
    'carrillo-billet': { name: 'Carrillo Billet Steel Pro', brand: 'Carrillo', powerBonus: 25, torqueBonus: 35, cost: 2950, weight: -2.3, tempIncrease: -1, reliabilityBonus: 18, description: 'Precision-machined billet steel. True motorsport balanced, allows massive high RPM scream.' }
  },
  rods: {
    stock: { name: 'Stock Cast Connecting Rods', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard thin-rods. Very prone to bending.' },
    'manley-hbeam': { name: 'Manley Forged H-Beam Rods', brand: 'Manley', powerBonus: 10, torqueBonus: 8, cost: 890, weight: -0.6, tempIncrease: 0, reliabilityBonus: 11, description: 'H-Profile heavy duty connecting rods. Absorbs heavy boost shockwaves.' }
  },
  sparkPlugs: {
    stock: { name: 'OEM Standard Copper Plugs', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard ignition plugs. Subject to spark blowout under 1.2+ Bar boost.' },
    'ngk-iridium': { name: 'NGK Iridium Racing', brand: 'NGK', powerBonus: 5, torqueBonus: 2, cost: 95, weight: -0.05, tempIncrease: -1, reliabilityBonus: 5, description: 'Iridium alloy cold plugs. Excellent anti-fouling and crisp spark response.' },
    'laser-iridium': { name: 'Laser 3-Electrode Iridium', brand: 'NGK Co.', powerBonus: 12, torqueBonus: 6, cost: 180, weight: -0.05, tempIncrease: -2, reliabilityBonus: 10, description: 'Aerospace-grade multispark plugs. Guaranteed zero spark blowout up to 3.5 Bar!' }
  },
  camshaft: {
    stock: { name: 'Stock Duration Cams', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Conservative emission-friendly profile.' },
    'tomei-272': { name: 'Tomei Procam 272° High-Lift', brand: 'Tomei', powerBonus: 35, torqueBonus: 12, cost: 1200, weight: -1.5, tempIncrease: 3, reliabilityBonus: 2, description: 'Lumpy racing cams. Delivers massive breath above 5500 RPM. Beautiful idle sound!' }
  },
  airFilter: {
    stock: { name: 'OEM Paper Air Filter', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Restricted high density paper.' },
    'kn-highflow': { name: 'K&N High-Flow Conical Mesh', brand: 'K&N', powerBonus: 12, torqueBonus: 8, cost: 120, weight: -0.5, tempIncrease: -2, reliabilityBonus: 2, description: 'Aggressive air suction. Sharpens throttle snap and spool times.' },
    'aem-coldair': { name: 'AEM Cold Air Intake Tube', brand: 'AEM', powerBonus: 24, torqueBonus: 15, cost: 380, weight: -1.2, tempIncrease: -5, reliabilityBonus: 5, description: 'Extended routing draws fresh cold air from behind bumper. Substantially denser intake charge!' }
  },
  wastegate: {
    internal: { name: 'Internal Actuator Flap', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Flap built into the turbo. Moderate pressure seal.' },
    'tial-external': { name: 'TiAL 44mm External Wastegate', brand: 'TiAL', powerBonus: 15, torqueBonus: 10, cost: 580, weight: 1.5, tempIncrease: -3, reliabilityBonus: 7, description: 'Dumps excess air directly into atmosphere with a deafening screamer roar!' }
  },
  boostValve: {
    manual: { name: 'Manual Bleed valve', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Adjust manually under the hood. Prone to boost fluctuations.' },
    'mac-3port': { name: 'Mac 3-Port Electronic Solenoid', brand: 'MAC Valve', powerBonus: 8, torqueBonus: 5, cost: 240, weight: 0.1, tempIncrease: -1, reliabilityBonus: 6, description: 'Precise electronic control via ECU mapping tables. Ensures rock-steady high boost.' }
  },
  injectorSize: {
    stock: { name: 'OEM 220cc Set', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Sufficient only for standard power. Will starve under boost.' },
    'dw-440': { name: 'Deatschwerks 440cc Set', brand: 'Deatschwerks', powerBonus: 15, torqueBonus: 10, cost: 520, weight: 0.2, tempIncrease: -2, reliabilityBonus: 2, description: 'Excellent atomization for minor performance setups.' },
    'id-850': { name: 'ID850 High-Impedance', brand: 'Injector Dynamics', powerBonus: 35, torqueBonus: 20, cost: 950, weight: 0.2, tempIncrease: -5, reliabilityBonus: 4, description: 'Ultimate fuel delivery. Highly reliable and linear sweep.' },
    'ultra-1200': { name: 'Ultra Injectors 1200cc Set', brand: 'Fuel Dynamics', powerBonus: 55, torqueBonus: 30, cost: 1450, weight: 0.3, tempIncrease: -8, reliabilityBonus: 5, description: 'Vast fuel supply. Mandatory for heavy racing boost profiles.' }
  },
  fuelRail: {
    stock: { name: 'Stock Pressed Steel Rail', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Factory fuel rail.' },
    'radium-billet': { name: 'Radium Billet Double-Feed', brand: 'Radium Engineering', powerBonus: 5, torqueBonus: 2, cost: 350, weight: -0.2, tempIncrease: -1, reliabilityBonus: 3, description: 'Eliminates fuel starvation in back cylinders. Maintains rock solid rail pressure.' }
  },
  fuelLine: {
    stock: { name: 'Stock Rubber Hoses', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard rubber hoses. Prone to cracking and deterioration.' },
    'braided-an': { name: '-6AN Braided Stainless Lines', brand: 'Aeroquip', powerBonus: 4, torqueBonus: 2, cost: 190, weight: 0.3, tempIncrease: -1, reliabilityBonus: 6, description: 'Stainless steel braid sleeve. Prevents leaks, highly resistant to rubbing wear.' },
    'ptfe-teflon': { name: 'PTFE Teflon Braided Lines', brand: 'Radium Engineering', powerBonus: 10, torqueBonus: 4, cost: 340, weight: 0.1, tempIncrease: -2, reliabilityBonus: 14, description: 'Premium teflon liner. Chemically immune to high ethanol (E85) fuels.' }
  },
  fuelPump: {
    stock: { name: 'OEM Fuel Pump (150 LPH)', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard fuel pump.' },
    'walbro-255': { name: 'Walbro 255 LPH In-Tank', brand: 'TI Automotive', powerBonus: 10, torqueBonus: 5, cost: 290, weight: 0.5, tempIncrease: -1, reliabilityBonus: 2, description: 'Industry classic in-tank fuel pump upgrade. Feeds up to 450 HP.' },
    'bosch-044': { name: 'Bosch 044 External Inline', brand: 'Bosch Motor', powerBonus: 25, torqueBonus: 15, cost: 650, weight: 1.2, tempIncrease: -3, reliabilityBonus: 3, description: 'Heavy-duty motorsport fuel pump mounting externally. Constant 5+ Bar flow!' }
  },
  ecuVariant: {
    stock: { name: 'Restricted Factory ECU', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Strict ignition/boost safety cuts. Not tunable.' },
    haltech: { name: 'Haltech Elite 1500 Standalone', brand: 'Haltech', powerBonus: 40, torqueBonus: 30, cost: 1950, weight: -0.4, tempIncrease: -1, reliabilityBonus: 6, description: 'Snappy standalone ECU with active knock sensing and safety bypass maps.' },
    motec: { name: 'MoTeC M130 Clubman Ultimate', brand: 'MoTeC', powerBonus: 65, torqueBonus: 50, cost: 3400, weight: -0.3, tempIncrease: -3, reliabilityBonus: 12, description: 'The peak of engine management. Individual cylinder spark trimming and fast maps.' }
  },
  wiringHarness: {
    stock: { name: 'Standard OEM Harness', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Original wiring. Old connectors suffer heat brittleness and signal noise.' },
    'raychem-milspec': { name: 'Mil-Spec Raychem DR-25', brand: 'TunerWires', powerBonus: 14, torqueBonus: 8, cost: 950, weight: -1.2, tempIncrease: -1, reliabilityBonus: 16, description: 'Gold-plated pins, concentric twisted loom under heat-shrink. Completely immune to RF noise and heat.' }
  },
  ignitionCoils: {
    stock: { name: 'OEM Ignition Coils', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard coils.' },
    'okada-plasma': { name: 'Okada Projects Smart Coils', brand: 'Okada Projects', powerBonus: 12, torqueBonus: 8, cost: 650, weight: 0.4, tempIncrease: -1, reliabilityBonus: 3, description: 'Plasma direct multispark cycle prevents combustion blowout under high boost.' }
  },
  intercooler: {
    stock: { name: 'OEM Narrow Core Intercooler', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard intercooler, heats up quickly.' },
    'mishimoto-triple': { name: 'Mishimoto Triple-Core FMIC', brand: 'Mishimoto', powerBonus: 15, torqueBonus: 10, cost: 850, weight: 6.5, tempIncrease: -16, reliabilityBonus: 8, description: 'Massive plate core drops intake charge temperature by over 30°C.' }
  },
  radiator: {
    stock: { name: 'OEM Plastic End-tank Radiator', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Prone to cracking under pressure spikes.' },
    'mishimoto-alu': { name: 'Mishimoto 3-Row Aluminum', brand: 'Mishimoto', powerBonus: 0, torqueBonus: 0, cost: 490, weight: 2.5, tempIncrease: -12, reliabilityBonus: 7, description: 'Aircraft grade aluminum core with dual-pass water channels.' }
  },
  coolingPipes: {
    stock: { name: 'Standard Black Rubber Hoses', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Gets soft and balloons at high coolant temperatures.' },
    'silicone-reinforced': { name: 'Silicone High-Temp Hose Kit', brand: 'Samco Sport', powerBonus: 0, torqueBonus: 0, cost: 180, weight: -0.2, tempIncrease: -3, reliabilityBonus: 8, description: 'Mesh reinforced silicone. Rated for triple standard water cooling pressure!' }
  },
  thermostat: {
    stock: { name: 'OEM Thermostat (92°C)', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Standard operating thermostat.' },
    'performance-68': { name: 'Performance Low-Temp (68°C)', brand: 'Mishimoto', powerBonus: 0, torqueBonus: 0, cost: 85, weight: 0.1, tempIncrease: -8, reliabilityBonus: 3, description: 'Opens much earlier than standard to keep the engine away from critical knock temperatures.' }
  },
  manifoldType: {
    stock: { name: 'OEM Standard Cast iron Manifold', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Extremely restrictive and heavy cast iron.' },
    'tomei-equal': { name: 'Tomei Equal-Length Headers', brand: 'Tomei', powerBonus: 22, torqueBonus: 18, cost: 890, weight: -3.5, tempIncrease: -2, reliabilityBonus: 2, description: 'Perfect cylinder exhaust matching. Accelerates gas evacuation!' }
  },
  catbackDiameter: {
    stock: { name: 'Restricted 2.0" Factory piping', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Restricted throat, muffles sound.' },
    'edelstahl-3.0': { name: 'Edelstahl 3.0" Stainless Pipe', brand: 'BBR Racing', powerBonus: 20, torqueBonus: 15, cost: 680, weight: -4.5, tempIncrease: -2, reliabilityBonus: 1, description: 'Straight-though performance stainless steel pipe. Roaring exhaust note.' },
    'titanium-3.5': { name: 'Aerospace Titanium 3.5" Pipe', brand: 'Akrapovič', powerBonus: 38, torqueBonus: 28, cost: 1950, weight: -8.8, tempIncrease: -4, reliabilityBonus: 3, description: 'Pure titanium ultra-light tube. Unlocked horsepower potential and screaming top-end idle!' }
  },
  exhaustValve: {
    stock: { name: 'No Exhaust Valve Bypass', brand: 'OEM', powerBonus: 0, torqueBonus: 0, cost: 0, weight: 0, tempIncrease: 0, reliabilityBonus: 0, description: 'Continuous steady sound levels.' },
    'active-bypass': { name: 'Active Remote Bypass Valve', brand: 'Capristo', powerBonus: 6, torqueBonus: 3, cost: 420, weight: 0.8, tempIncrease: -1, reliabilityBonus: 4, description: 'Electronic throttle flaps. Opens direct pipe via remote control to alternate track and city modes.' }
  }
};

/**
 * =========================================================================================
 *                   ADVANCED AUTOMOTIVE SOUND SYNTHESIS ENGINE (v3.0 ULTRA)
 * =========================================================================================
 * 
 * PROCEDURAL MODULATION AND AUDIO ROUTING TOPOLOGY:
 * 
 * [Ignition Pulses (Oscs 1-4)] ---> [Waveshaper Saturation (Capristo)] ---> [Muffler Lowpass] ---> [Delay Reverb / Echo] ----\
 * [Mechanical Valve Tappets (Square)] ---> [Highpass 4.5kHz Filter] -----------------------------------------------------> [Master Gain] ---> AudioDestination
 * [Intake Air Suction (White Noise)] ---> [Dynamic Bandpass 320-1200Hz] -------------------------------------------------/
 * [Turbocharger Whistle (High sine)] ---> [Highpass 700Hz Solenoid] ----------------------------------------------------/
 * [Dynamic Exhaust Gas flow (Noise)] ---> [Bandpass 260Hz Resonator] ---------------------------------------------------/
 * 
 * PHYSICS & SYNTHESIS CONTROL FORMULAS:
 * 1. Non-linear Pitch Scaling: 
 *    Effective Hz = FundamentalHz * Math.pow(RPM / Redline, 1.15) * (1.0 + JitterOffset)
 * 2. Throttle / Engine Load Influence:
 *    - High Throttle: Opens Intake butterfly flap (intakeGain slides up). Boosts power stroke amplitude.
 *    - Deceleration (Overrun): Reduces fundamental tone presence, escalates friction clicks, triggers burbles.
 * 3. Spatial reflections:
 *    Adjustable delay line models ambient reverberation bouncing off nearby test walls.
 * =========================================================================================
 */
class OldExhaustSynthEngine {
  private ctx: AudioContext | null = null;
  private oscs: OscillatorNode[] = [];
  private oscGains: GainNode[] = [];
  private masterGain: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private shaper: WaveShaperNode | null = null;
  private delayNode: DelayNode | null = null;
  private delayGain: GainNode | null = null;
  
  // Custom Synthesis Sound Layers
  private sharedNoiseNode: ScriptProcessorNode | null = null;
  
  // 1. Intake Suction whistle
  private intakeFilter: BiquadFilterNode | null = null;
  private intakeGain: GainNode | null = null;
  
  // 2. Mechanical valve ticking noise
  private mechOsc: OscillatorNode | null = null;
  private mechFilter: BiquadFilterNode | null = null;
  private mechGain: GainNode | null = null;
  
  // 3. Exhaust Gas rushed flow
  private gasFilter: BiquadFilterNode | null = null;
  private gasGain: GainNode | null = null;

  // 4. Turbo engine whistle layout
  private turboOsc: OscillatorNode | null = null;
  private turboGain: GainNode | null = null;
  
  // 5. Classic V8 Bubble LFO
  private lfo: OscillatorNode | null = null;
  private lfoGain: GainNode | null = null;

  // 6. Supercharger whine (specific to Shelby V8)
  private superchargerOsc: OscillatorNode | null = null;
  private superchargerGain: GainNode | null = null;

  private cylinderCount: number = 4;
  private isMuted: boolean = false;
  private baseGainValue: number = 0.22;
  private currentRPM: number = 1000;
  private hasTurbo: boolean = false;
  private lastUpdate: number = 0;

  // Track Specs
  private manifold: string = 'stock';
  private catback: string = 'stock';
  private valve: string = 'stock';
  private camshaft: string = 'stock';
  private ecu: string = 'stock';
  private pistons: string = 'stock';
  private sparkPlugs: string = 'stock';
  private wastegate: string = 'internal';
  private bov: string = 'manual';
  private airFilter: string = 'stock';

  private vehicleId: string = 'polo-gt';
  private lastThrottle: number = 0;
  private previousBlowoffTrigger: boolean = false;
  private isStock: boolean = true;

  constructor() {}

  private makeDistortionCurve(amount: number) {
    const k = typeof amount === 'number' ? amount : 50;
    const n_samples = 44100;
    const curve = new Float32Array(n_samples);
    const deg = Math.PI / 180;
    for (let i = 0 ; i < n_samples; ++i ) {
      const x = (i * 2) / n_samples - 1;
      // Precision formulation modeling asymmetric exhaust manifold metal acoustic saturation
      curve[i] = (3 + k) * x * 20 * deg / (Math.PI + k * Math.abs(x));
    }
    return curve;
  }

  public toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.masterGain) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.baseGainValue, this.ctx?.currentTime || 0);
    }
  }

  public getMuted() {
    return this.isMuted;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGain) {
      const targetVal = this.isMuted ? 0 : this.baseGainValue;
      if (this.ctx) {
        this.masterGain.gain.setValueAtTime(targetVal, this.ctx.currentTime);
      } else {
        this.masterGain.gain.value = targetVal;
      }
    }
  }

  public start(vehicle: VehicleProfile, subParts: Record<string, string>, hasTurbo: boolean) {
    try {
      this.vehicleId = vehicle.id;
      this.cylinderCount = vehicle.cylinders;
      this.hasTurbo = hasTurbo;

      this.manifold = subParts.manifoldType || 'stock';
      this.catback = subParts.catbackDiameter || 'stock';
      this.valve = subParts.exhaustValve || 'stock';
      this.camshaft = subParts.camshaft || 'stock';
      this.ecu = subParts.ecuVariant || 'stock';
      this.pistons = subParts.pistons || 'stock';
      this.sparkPlugs = subParts.sparkPlugs || 'stock';
      this.wastegate = subParts.wastegate || 'internal';
      this.bov = subParts.boostValve || 'manual';
      this.airFilter = subParts.airFilter || 'stock';
      
      this.isStock = this.checkIsStock();

      const AudioCtxClass = (window.AudioContext || (window as any).webkitAudioContext);
      if (!AudioCtxClass) return;

      this.ctx = new AudioCtxClass();
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }

      this.masterGain = this.ctx.createGain();
      
      // Compute base volume gain corresponding to how modified the car is (stock is extremely civil and quiet)
      if (this.isStock) {
        this.baseGainValue = 0.055;
      } else {
        let tempGain = 0.22;
        if (this.catback === 'titanium-3.5') tempGain += 0.08;
        else if (this.catback === 'edelstahl-3.0') tempGain += 0.04;
        
        if (this.valve === 'active-bypass') tempGain += 0.10;
        if (this.ecu === 'haltech' || this.ecu === 'motec') tempGain += 0.03;
        
        this.baseGainValue = tempGain;
      }
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.baseGainValue, this.ctx.currentTime);

      // --- PRIMARY SIGNAL PATH (EXHAUST NOTE ENGINE) ---
      this.filter = this.ctx.createBiquadFilter();
      this.filter.type = 'lowpass';
      
      const initialCutoff = this.isStock ? 160 : (this.catback === 'titanium-3.5' ? 620 : this.catback === 'edelstahl-3.0' ? 440 : 280);
      this.filter.frequency.setValueAtTime(initialCutoff, this.ctx.currentTime);
      
      const resonanceQ = this.isStock ? 1.5 : (this.manifold === 'tomei-equal' ? 8.0 : 4.0);
      this.filter.Q.setValueAtTime(resonanceQ, this.ctx.currentTime);

      // Waveshaper mimics expansion chamber backpressure friction saturation clipping
      this.shaper = this.ctx.createWaveShaper();
      const distortionStrength = this.isStock ? 1 : (this.valve === 'active-bypass' ? 45 : this.catback === 'titanium-3.5' ? 35 : this.catback === 'edelstahl-3.0' ? 20 : 8);
      this.shaper.curve = this.makeDistortionCurve(distortionStrength);
      this.shaper.oversample = '4x';

      // --- ENVIRONMENT REFLECTION NODE (REVERB / TUNNEL SYSTEM) ---
      this.delayNode = this.ctx.createDelay(1.0);
      this.delayNode.delayTime.setValueAtTime(0.055, this.ctx.currentTime);
      
      this.delayGain = this.ctx.createGain();
      const delayAmount = this.isStock ? 0.04 : 0.18;
      this.delayGain.gain.setValueAtTime(delayAmount, this.ctx.currentTime);

      // Routing main exhaust path
      this.shaper.connect(this.filter);
      
      this.filter.connect(this.masterGain);
      this.filter.connect(this.delayNode);
      this.delayNode.connect(this.delayGain);
      this.delayGain.connect(this.masterGain);

      this.masterGain.connect(this.ctx.destination);

      const t = this.ctx.currentTime;
      
      // Build oscillators dynamically based on custom harmonics!
      this.rebuildOscillators();

      // --- PROCEDURAL SHARED WHITE NOISE GENERATOR ---
      this.sharedNoiseNode = this.ctx.createScriptProcessor(4096, 0, 1);
      this.sharedNoiseNode.onaudioprocess = (e) => {
        const outputBuffer = e.outputBuffer;
        const channelData = outputBuffer.getChannelData(0);
        for (let i = 0; i < outputBuffer.length; i++) {
          channelData[i] = Math.random() * 2 - 1;
        }
      };

      // --- LAYER 2: INTAKE SUCTION (AIR ESCAPE WHISTLING) ---
      this.intakeFilter = this.ctx.createBiquadFilter();
      this.intakeFilter.type = 'bandpass';
      this.intakeFilter.frequency.setValueAtTime(350, t);
      this.intakeFilter.Q.setValueAtTime(2.0, t);

      this.intakeGain = this.ctx.createGain();
      // Vacuum intake suction starting extremely low at idle
      this.intakeGain.gain.setValueAtTime(0.002, t);

      // Route: Shared Noise -> Intake Bandpass Filter -> Gain -> Master
      this.sharedNoiseNode.connect(this.intakeFilter);
      this.intakeFilter.connect(this.intakeGain);
      this.intakeGain.connect(this.masterGain);

      // --- LAYER 3: MECHANICAL VALVE TICKING ---
      this.mechFilter = this.ctx.createBiquadFilter();
      this.mechFilter.type = 'highpass';
      this.mechFilter.frequency.setValueAtTime(4500, t);
      this.mechFilter.Q.setValueAtTime(5.0, t);

      this.mechGain = this.ctx.createGain();
      const idleMechVol = this.isStock ? 0.005 : 0.015;
      this.mechGain.gain.setValueAtTime(idleMechVol, t);

      this.mechOsc = this.ctx.createOscillator();
      this.mechOsc.type = 'square';
      this.mechOsc.frequency.setValueAtTime(24, t); 
      
      this.mechOsc.connect(this.mechFilter);
      this.mechFilter.connect(this.mechGain);
      this.mechGain.connect(this.masterGain);
      this.mechOsc.start(0);

      // --- LAYER 4: EXHAUST MOUNTED GAS FLOW CORES ---
      this.gasFilter = this.ctx.createBiquadFilter();
      this.gasFilter.type = 'bandpass';
      this.gasFilter.frequency.setValueAtTime(260, t);
      this.gasFilter.Q.setValueAtTime(1.0, t);

      this.gasGain = this.ctx.createGain();
      const initialGas = this.isStock ? 0.003 : 0.012;
      this.gasGain.gain.setValueAtTime(initialGas, t);

      this.sharedNoiseNode.connect(this.gasFilter);
      this.gasFilter.connect(this.gasGain);
      this.gasGain.connect(this.masterGain);

      // --- EXTRA OPTIONAL: TURBO Spool Layer ---
      if (this.hasTurbo) {
        this.turboOsc = this.ctx.createOscillator();
        this.turboOsc.type = 'sine';
        this.turboOsc.frequency.setValueAtTime(800, t);
        
        this.turboGain = this.ctx.createGain();
        this.turboGain.gain.setValueAtTime(0.002, t);

        const turboHighpass = this.ctx.createBiquadFilter();
        turboHighpass.type = 'highpass';
        turboHighpass.frequency.setValueAtTime(650, t);

        this.turboOsc.connect(this.turboGain);
        this.turboGain.connect(turboHighpass);
        turboHighpass.connect(this.masterGain);
        this.turboOsc.start(0);
      }

      // --- EXTRA OPTIONAL: SUPERCHARGER (Shelby V8 only) ---
      if (this.vehicleId === 'shelby-v8') {
        this.superchargerOsc = this.ctx.createOscillator();
        this.superchargerOsc.type = 'sine';
        this.superchargerOsc.frequency.setValueAtTime(600, t);
        
        this.superchargerGain = this.ctx.createGain();
        this.superchargerGain.gain.setValueAtTime(0.005, t);
        
        const scHighpass = this.ctx.createBiquadFilter();
        scHighpass.type = 'highpass';
        scHighpass.frequency.setValueAtTime(500, t);
        
        this.superchargerOsc.connect(this.superchargerGain);
        this.superchargerGain.connect(scHighpass);
        scHighpass.connect(this.masterGain);
        this.superchargerOsc.start(0);
      }

    } catch (err) {
      console.error("Advanced Web Audio startup fault:", err);
    }
  }

  private rebuildOscillators() {
    if (!this.ctx || !this.shaper) return;
    
    // Stop and disconnect old oscillators
    this.oscs.forEach(o => {
      try { o.stop(); } catch(e) {}
    });
    this.oscs = [];
    this.oscGains = [];
    
    if (this.lfo) {
      try { this.lfo.stop(); } catch(e) {}
      this.lfo = null;
    }
    
    const t = this.ctx.currentTime;
    const baseIdleFreq = 30; // Standard 30Hz fundamental matching 900 RPM
    
    if (this.cylinderCount === 3) {
      // Polo GT 1.0 TSI unbalanced off-beat 3-cylinder growl
      this.addOscillator('sawtooth', baseIdleFreq, 0.44 * (this.isStock ? 0.35 : 1.0), this.shaper);
      this.addOscillator('triangle', baseIdleFreq * 0.5, 0.52 * (this.isStock ? 0.45 : 1.0), this.shaper);
      this.addOscillator('sawtooth', baseIdleFreq * 1.5, 0.38 * (this.isStock ? 0.20 : 1.0), this.shaper); // Odd off-beat thrum
      this.addOscillator('square', baseIdleFreq * 2.5, 0.12 * (this.isStock ? 0.08 : 1.0), this.shaper);
    } else if (this.cylinderCount === 6) {
      // BMW E46 screaming straight-six metallic vocal overlaps
      this.addOscillator('sawtooth', baseIdleFreq, 0.35 * (this.isStock ? 0.35 : 1.0), this.shaper);
      this.addOscillator('triangle', baseIdleFreq * 0.5, 0.48 * (this.isStock ? 0.45 : 1.0), this.shaper);
      this.addOscillator('sawtooth', baseIdleFreq * 2.0, 0.30 * (this.isStock ? 0.20 : 1.0), this.shaper);
      this.addOscillator('sawtooth', baseIdleFreq * 3.0, 0.18 * (this.isStock ? 0.10 : 1.0), this.shaper);
      this.addOscillator('sine', baseIdleFreq * 5.0, 0.15 * (this.isStock ? 0.05 : 1.0), this.shaper); // Ringing high harmonics
    } else if (this.cylinderCount === 8) {
      // Shelby GT500 heavy, detuned crossplane V8 muscle rumble
      this.addOscillator('sawtooth', baseIdleFreq, 0.45 * (this.isStock ? 0.35 : 1.0), this.shaper);
      this.addOscillator('sawtooth', baseIdleFreq * 1.025, 0.42 * (this.isStock ? 0.35 : 1.0), this.shaper); // Core Detune
      this.addOscillator('triangle', baseIdleFreq * 0.5, 0.60 * (this.isStock ? 0.50 : 1.0), this.shaper); // Heavy low thuds
      this.addOscillator('sawtooth', baseIdleFreq * 2.0, 0.28 * (this.isStock ? 0.15 : 1.0), this.shaper);
      this.addOscillator('square', baseIdleFreq * 3.0, 0.08 * (this.isStock ? 0.05 : 1.0), this.shaper);
      
      // Low frequency bubbling envelope
      this.lfo = this.ctx.createOscillator();
      this.lfo.type = 'sine';
      this.lfo.frequency.setValueAtTime(7.5, t);
      
      this.lfoGain = this.ctx.createGain();
      const lfoAmp = this.isStock ? 0.06 : 0.24;
      this.lfoGain.gain.setValueAtTime(lfoAmp, t);
      
      this.lfo.connect(this.lfoGain);
      if (this.oscGains[2]) {
        this.lfoGain.connect(this.oscGains[2].gain);
      }
      this.lfo.start(0);
    } else {
      // Swift K12 & Civic Si flat plane Inline-4 buzzy, sporty screamers
      this.addOscillator('sawtooth', baseIdleFreq, 0.48 * (this.isStock ? 0.35 : 1.0), this.shaper);
      this.addOscillator('triangle', baseIdleFreq * 0.5, 0.42 * (this.isStock ? 0.45 : 1.0), this.shaper);
      this.addOscillator('sawtooth', baseIdleFreq * 2.0, 0.24 * (this.isStock ? 0.15 : 1.0), this.shaper);
      this.addOscillator('square', baseIdleFreq * 3.0, 0.08 * (this.isStock ? 0.05 : 1.0), this.shaper);
    }
  }

  private checkIsStock(): boolean {
    const isExhaustStock = this.catback === 'stock' || !this.catback;
    const isManifoldStock = this.manifold === 'stock' || !this.manifold;
    const isValveStock = this.valve === 'stock' || !this.valve;
    const isCamStock = this.camshaft === 'stock' || !this.camshaft;
    const isEcuStock = this.ecu === 'stock' || !this.ecu;
    const isPistonsStock = this.pistons === 'stock' || !this.pistons;
    
    return isExhaustStock && isManifoldStock && isValveStock && isCamStock && isEcuStock && isPistonsStock;
  }

  public recalibrateSound(vehicle: VehicleProfile, subParts: Record<string, string>, hasTurbo: boolean) {
    if (!this.ctx) return;
    if (!vehicle) return;
    const safeSubParts = subParts || {};
    
    const t = this.ctx.currentTime;
    
    const cylindersChanged = this.cylinderCount !== (vehicle.cylinders || 4);
    this.vehicleId = vehicle.id;
    this.cylinderCount = vehicle.cylinders || 4;
    this.hasTurbo = hasTurbo;
    
    this.manifold = safeSubParts.manifoldType || 'stock';
    this.catback = safeSubParts.catbackDiameter || 'stock';
    this.valve = safeSubParts.exhaustValve || 'stock';
    this.camshaft = safeSubParts.camshaft || 'stock';
    this.ecu = safeSubParts.ecuVariant || 'stock';
    this.pistons = safeSubParts.pistons || 'stock';
    this.sparkPlugs = safeSubParts.sparkPlugs || 'stock';
    this.wastegate = safeSubParts.wastegate || 'internal';
    this.bov = safeSubParts.boostValve || 'manual';
    this.airFilter = safeSubParts.airFilter || 'stock';
    
    this.isStock = this.checkIsStock();
    
    // Recalibrate volume gain
    if (this.isStock) {
      this.baseGainValue = 0.055;
    } else {
      let tempGain = 0.22;
      if (this.catback === 'titanium-3.5') tempGain += 0.08;
      else if (this.catback === 'edelstahl-3.0') tempGain += 0.04;
      
      if (this.valve === 'active-bypass') tempGain += 0.10;
      if (this.ecu === 'haltech' || this.ecu === 'motec') tempGain += 0.03;
      
      this.baseGainValue = tempGain;
    }
    
    if (this.masterGain && !this.isMuted) {
      this.masterGain.gain.setValueAtTime(this.baseGainValue, t);
    }
    
    // Rebuild oscillators if cylinders changed or are uninitialized
    if (cylindersChanged || this.oscs.length === 0) {
      this.rebuildOscillators();
    }
    
    // Configure main lowpass filter
    if (this.filter) {
      const initialCutoff = this.isStock ? 160 : (this.catback === 'titanium-3.5' ? 620 : this.catback === 'edelstahl-3.0' ? 440 : 280);
      this.filter.frequency.setValueAtTime(initialCutoff, t);
      
      const resonanceQ = this.isStock ? 1.5 : (this.manifold === 'tomei-equal' ? 8.0 : 4.0);
      this.filter.Q.setValueAtTime(resonanceQ, t);
    }
    
    // Waveshaper distortion
    if (this.shaper) {
      const distortionStrength = this.isStock ? 1 : (this.valve === 'active-bypass' ? 45 : this.catback === 'titanium-3.5' ? 35 : this.catback === 'edelstahl-3.0' ? 20 : 8);
      this.shaper.curve = this.makeDistortionCurve(distortionStrength);
    }
    
    // Setup turbocharger
    if (this.hasTurbo && !this.turboOsc) {
      this.turboOsc = this.ctx.createOscillator();
      this.turboOsc.type = 'sine';
      this.turboOsc.frequency.setValueAtTime(800, t);
      
      this.turboGain = this.ctx.createGain();
      this.turboGain.gain.setValueAtTime(0.003, t);

      const turboHighpass = this.ctx.createBiquadFilter();
      turboHighpass.type = 'highpass';
      turboHighpass.frequency.setValueAtTime(650, t);

      this.turboOsc.connect(this.turboGain);
      this.turboGain.connect(turboHighpass);
      turboHighpass.connect(this.masterGain!);
      this.turboOsc.start(0);
    } else if (!this.hasTurbo && this.turboOsc) {
      try { this.turboOsc.stop(); } catch(e) {}
      this.turboOsc = null;
      this.turboGain = null;
    }

    // Setup supercharger for V8
    if (this.vehicleId === 'shelby-v8') {
      if (!this.superchargerOsc) {
        this.superchargerOsc = this.ctx.createOscillator();
        this.superchargerOsc.type = 'sine';
        this.superchargerOsc.frequency.setValueAtTime(600, t);
        
        this.superchargerGain = this.ctx.createGain();
        this.superchargerGain.gain.setValueAtTime(0.005, t);
        
        const scHighpass = this.ctx.createBiquadFilter();
        scHighpass.type = 'highpass';
        scHighpass.frequency.setValueAtTime(500, t);
        
        this.superchargerOsc.connect(this.superchargerGain);
        this.superchargerGain.connect(scHighpass);
        scHighpass.connect(this.masterGain!);
        this.superchargerOsc.start(0);
      }
    } else {
      if (this.superchargerOsc) {
        try { this.superchargerOsc.stop(); } catch(e) {}
        this.superchargerOsc = null;
        this.superchargerGain = null;
      }
    }
  }

  private addOscillator(type: OscillatorType, freq: number, gainVal: number, destination: AudioNode) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    
    const gainNode = this.ctx.createGain();
    gainNode.gain.setValueAtTime(gainVal, this.ctx.currentTime);
    
    osc.connect(gainNode);
    gainNode.connect(destination);
    osc.start(0);
    this.oscs.push(osc);
    this.oscGains.push(gainNode);
  }

  /**
   * Updates synthesis outputs in real-time according to RPM and throttle level input.
   * Includes structural mapping layers (Idle -> Mid acceleration -> Aggressive screaming redline)
   */
  public update(rpm: number, maxRPM: number, boost: number, throttle: number = 0.95, isShifting: boolean = false) {
    try {
      if (!this.ctx || !this.filter || this.oscs.length === 0) return;
      
      this.currentRPM = rpm;
      const rpmRatio = rpm / maxRPM;
      const t = this.ctx.currentTime;

      // 1. NON-LINEAR PITCH PHYSICS & SPARKS JITTER
      const hasRacingPlugs = this.sparkPlugs === 'ngk-iridium' || this.sparkPlugs === 'laser-iridium';
      const maxJitter = hasRacingPlugs ? 0.001 : 0.006 * (this.isStock ? 0.5 : 1.0);
      const jitterOffset = (Math.sin(t * 42) * maxJitter) + (Math.random() - 0.5) * (maxJitter * 0.7) * (rpmRatio * 1.5);
      
      // Calculate custom frequencies per car (Making sounds unique)
      let baseFreqFactor = 1.0;
      if (this.vehicleId === 'polo-gt') baseFreqFactor = 1.15;
      else if (this.vehicleId === 'swift-k12') baseFreqFactor = 1.30;
      else if (this.vehicleId === 'thar-mstallion') baseFreqFactor = 0.85;
      else if (this.vehicleId === 'civic-1.5t') baseFreqFactor = 1.10;
      else if (this.vehicleId === 'bmw-e46') baseFreqFactor = 1.05;
      else if (this.vehicleId === 'shelby-v8') baseFreqFactor = 0.70;

      const baseFreq = (rpm / 60) * (this.cylinderCount / 2) * baseFreqFactor;
      const outputBaseFreq = baseFreq * (1.0 + (isShifting ? -0.12 : jitterOffset));

      // 2. LAYER CONTROLS (PULSING COMBUSTION HARMONICS)
      if (this.cylinderCount === 3) {
        this.oscs[0].frequency.setValueAtTime(outputBaseFreq, t); 
        this.oscs[1].frequency.setValueAtTime(outputBaseFreq * 0.5, t); 
        this.oscs[2].frequency.setValueAtTime(outputBaseFreq * 1.5, t); 
        this.oscs[3].frequency.setValueAtTime(outputBaseFreq * 2.5, t); 
      } else if (this.cylinderCount === 6) {
        this.oscs[0].frequency.setValueAtTime(outputBaseFreq, t);
        this.oscs[1].frequency.setValueAtTime(outputBaseFreq * 0.5, t);
        this.oscs[2].frequency.setValueAtTime(outputBaseFreq * 2.0, t);
        this.oscs[3].frequency.setValueAtTime(outputBaseFreq * 3.0, t);
        this.oscs[4].frequency.setValueAtTime(outputBaseFreq * 5.0, t);
      } else if (this.cylinderCount === 8) {
        this.oscs[0].frequency.setValueAtTime(outputBaseFreq, t);
        this.oscs[1].frequency.setValueAtTime(outputBaseFreq * 1.025 * (1 + jitterOffset), t); 
        this.oscs[2].frequency.setValueAtTime(outputBaseFreq * 0.5, t); 
        this.oscs[3].frequency.setValueAtTime(outputBaseFreq * 2.0, t);
        this.oscs[4].frequency.setValueAtTime(outputBaseFreq * 3.0, t);

        if (this.lfo) {
          const lfoFreq = 7.0 + (rpmRatio * 22);
          this.lfo.frequency.setValueAtTime(lfoFreq, t);
        }
      } else {
        // Standard I-4
        const scaleExponent = 1.05;
        const warpedBase = baseFreq * Math.pow(rpmRatio, scaleExponent - 1.0);
        this.oscs[0].frequency.setValueAtTime(warpedBase, t);
        this.oscs[1].frequency.setValueAtTime(warpedBase * 0.5, t);
        this.oscs[2].frequency.setValueAtTime(warpedBase * 2.0, t);
        this.oscs[3].frequency.setValueAtTime(warpedBase * 3.0, t);
      }

      // Check if pistons are forged -> adds deep compression slap to harmonics
      const isForgedPistons = this.pistons === 'je-forged' || this.pistons === 'wiseco-forged';
      if (isForgedPistons && this.oscGains[0]) {
        this.oscGains[0].gain.setValueAtTime(0.55 * (this.isStock ? 0.35 : 1.0), t);
      }

      // 3. INTAKE LAYER MODULATION (AIR SUCTION)
      if (this.intakeFilter && this.intakeGain) {
        const targetIntakePitch = 320 + (rpmRatio * 850);
        this.intakeFilter.frequency.setValueAtTime(targetIntakePitch, t);
        
        let intakeScale = 0.015;
        if (this.airFilter === 'kn-highflow') intakeScale = 0.038;
        else if (this.airFilter === 'aem-coldair') intakeScale = 0.055;
        else if (this.isStock) intakeScale = 0.003;

        const targetIntakeVol = isShifting ? 0.001 : Math.max(0.002, intakeScale * throttle * (0.2 + rpmRatio * 0.8));
        this.intakeGain.gain.setTargetAtTime(targetIntakeVol, t, 0.05);
      }

      // 4. MECHANICAL TAPPET TICKING SPEEDUP
      if (this.mechOsc && this.mechGain) {
        const tickingFreq = 16 + (rpmRatio * 75);
        this.mechOsc.frequency.setValueAtTime(tickingFreq, t);
        
        let mechDampen = this.isStock ? 0.005 : 0.015;
        const targetMechVol = Math.max(0.002, mechDampen * (1.0 - (throttle * 0.45)) * (0.4 + (1.0 - rpmRatio) * 0.6));
        this.mechGain.gain.setValueAtTime(targetMechVol, t);
      }

      // 5. EXHAUST GAS FLOW NOISE & EXTERNAL WASTEGATE DUMP
      if (this.gasFilter && this.gasGain) {
        if (this.wastegate === 'tial-external' && throttle > 0.80 && boost > 0.6) {
          // External wastegate dumps screaming downpipe noise
          const wastegateScreamerVol = 0.09 * (boost / 1.5);
          this.gasGain.gain.setValueAtTime(wastegateScreamerVol, t);
          this.gasFilter.frequency.setValueAtTime(3200, t); // Metallic hiss
          this.gasFilter.Q.setValueAtTime(3.0, t);
        } else {
          const flowPitch = 240 + (rpmRatio * 320);
          this.gasFilter.frequency.setValueAtTime(flowPitch, t);
          
          const maxGasVol = this.isStock ? 0.008 : 0.06;
          const flowVol = Math.min(maxGasVol, 0.004 + (rpmRatio * 0.038) + (throttle * 0.015));
          this.gasGain.gain.setValueAtTime(flowVol, t);
          this.gasFilter.Q.setValueAtTime(1.0, t);
        }
      }

      // 6. DETECT TURBOCHARGER AND ADJUST SPOOLING WHISTLES
      if (this.turboOsc && this.turboGain) {
        const turboFreq = 800 + (rpmRatio * 1850) + (boost * 450);
        this.turboOsc.frequency.setValueAtTime(turboFreq, t);
        
        const maxSpoolGain = this.isStock ? 0.004 : 0.075;
        const whistleGain = isShifting ? 0.001 : Math.min(maxSpoolGain, 0.002 + (rpmRatio * 0.03) + (boost * 0.022));
        this.turboGain.gain.setTargetAtTime(whistleGain, t, 0.04);
      }

      // 6b. DETECT SUPERCHARGER WHINE (Shelby V8 only)
      if (this.superchargerOsc && this.superchargerGain) {
        const scFreq = 400 + (rpmRatio * 1800);
        this.superchargerOsc.frequency.setValueAtTime(scFreq, t);
        
        const scWhineVol = Math.min(0.045, 0.001 + (throttle * 0.035) * (0.3 + rpmRatio * 0.7));
        this.superchargerGain.gain.setTargetAtTime(scWhineVol, t, 0.05);
      }

      // 7. LOWPASS MUFFLER FILTER DYNAMIC OPENING
      const bypassBonus = this.catback === 'titanium-3.5' ? 240 : this.catback === 'edelstahl-3.0' ? 120 : 0;
      const targetMufflerCutoff = this.isStock ? (140 + rpmRatio * 200) : (160 + (rpmRatio * 910) + (boost * 100) + bypassBonus);
      this.filter.frequency.setValueAtTime(targetMufflerCutoff, t);

      // 8. MASTER THROTTLE GAIN ENVELOPE MODULATION & CAMMED CHOP
      const engineBrakingPenalty = throttle < 0.2 ? 0.38 : (0.35 + (rpmRatio * 0.65));
      let targetGainVal = isShifting ? (this.baseGainValue * 0.1) : (engineBrakingPenalty * this.baseGainValue * throttle);
      if (this.isStock && throttle < 0.1) {
        targetGainVal = 0.003; // Quiet at idle if stock
      }

      // CAMMED CHOP IDLE: Tomei 272 / Stage 2 race cams lope lumpy at standard idle
      if (rpm < 1600 && (this.camshaft === 'tomei-272' || this.camshaft === 'race-stage2')) {
        const chopFreq = 4.2; // Lope speed
        const chopSignal = Math.sin(t * chopFreq * 2 * Math.PI);
        if (chopSignal < -0.2) {
          targetGainVal *= 0.25 + (Math.random() * 0.12);
        } else if (chopSignal > 0.7) {
          targetGainVal *= 1.35;
        }
      }

      if (this.masterGain && !this.isMuted) {
        this.masterGain.gain.setTargetAtTime(targetGainVal, t, 0.03);
      }

      // 9. DYNAMIC BOV SNEEZE TRIGGER
      const isBovSneezing = (this.lastThrottle > 0.35 && throttle < 0.10) || isShifting;
      if (isBovSneezing && !this.previousBlowoffTrigger && this.hasTurbo && rpm > 2000) {
        this.triggerBlowoffValve();
      }
      this.lastThrottle = throttle;
      this.previousBlowoffTrigger = isBovSneezing;

      // 10. POPS & BANGS BURBLE OVERRUNS
      if (throttle < 0.1 && rpm > 2600 && (this.ecu === 'haltech' || this.ecu === 'motec')) {
        const burbleChance = this.valve === 'active-bypass' ? 0.18 : 0.08;
        if (Math.random() < burbleChance) {
          this.triggerOverrunBurblePop();
        }
      }

    } catch (err) {
      console.warn("Audio live bypass:", err);
    }
  }

  public triggerBlowoffValve() {
    try {
      if (!this.ctx || this.isMuted) return;
      
      const t = this.ctx.currentTime;
      
      const bufferSize = this.ctx.sampleRate * 0.6; // 600ms duration
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      
      const noiseSource = this.ctx.createBufferSource();
      noiseSource.buffer = buffer;
      
      const bovFilter = this.ctx.createBiquadFilter();
      bovFilter.type = 'bandpass';
      
      const bovGain = this.ctx.createGain();
      
      if (this.bov === 'greddy-bov') {
        // High-performance atmospheric Greddy Bov: sharp fluttering sound
        bovFilter.frequency.setValueAtTime(2500, t);
        bovFilter.Q.setValueAtTime(12.0, t); // Metallic whistle resonance
        
        bovGain.gain.setValueAtTime(0.35, t);
        
        // Rapid flutter loops
        for (let i = 0; i < 6; i++) {
          const tickTime = t + i * 0.07;
          bovGain.gain.setValueAtTime(0.35, tickTime);
          bovGain.gain.exponentialRampToValueAtTime(0.02, tickTime + 0.05);
        }
        bovGain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
        bovFilter.frequency.exponentialRampToValueAtTime(1400, t + 0.45);
      } else {
        // Factory recirculating valve: soft, quiet "pSSShhhh" aerodynamic hiss
        bovFilter.frequency.setValueAtTime(1200, t);
        bovFilter.Q.setValueAtTime(1.0, t);
        
        bovGain.gain.setValueAtTime(0.08, t);
        bovGain.gain.exponentialRampToValueAtTime(0.001, t + 0.40);
      }
      
      noiseSource.connect(bovFilter);
      bovFilter.connect(bovGain);
      bovGain.connect(this.masterGain!);
      
      noiseSource.start(t);
      noiseSource.stop(t + 0.60);
    } catch (e) {
      // Ignored
    }
  }

  private triggerOverrunBurblePop() {
    try {
      if (!this.ctx || this.isMuted || !this.masterGain) return;
      const t = this.ctx.currentTime;
      const intensityScale = this.valve === 'active-bypass' ? 1.5 : 0.70;
      
      // Heavy sub bass explosion
      const popOsc = this.ctx.createOscillator();
      popOsc.type = 'triangle';
      popOsc.frequency.setValueAtTime(140 + Math.random() * 80, t);
      popOsc.frequency.exponentialRampToValueAtTime(20, t + 0.06);
      
      const popGain = this.ctx.createGain();
      popGain.gain.setValueAtTime(0.42 * intensityScale, t);
      popGain.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
      
      popOsc.connect(popGain);
      popGain.connect(this.masterGain);
      popOsc.start(t);
      popOsc.stop(t + 0.08);
      
      // Searing metal crackle
      const crackOsc = this.ctx.createOscillator();
      crackOsc.type = 'sawtooth';
      crackOsc.frequency.setValueAtTime(350 + Math.random() * 200, t);
      crackOsc.frequency.exponentialRampToValueAtTime(40, t + 0.04);
      
      const crackGain = this.ctx.createGain();
      crackGain.gain.setValueAtTime(0.18 * intensityScale, t);
      crackGain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
      
      crackOsc.connect(crackGain);
      crackGain.connect(this.masterGain);
      crackOsc.start(t);
      crackOsc.stop(t + 0.06);
    } catch(e) {}
  }

  /**
   * Play heavy metal-on-metal transmission shifts with clutch release echo
   */
  public triggerShift() {
    try {
      if (!this.ctx || this.isMuted || !this.masterGain) return;
      const t = this.ctx.currentTime;

      // Click 1: Sharp high metallic ring frequency representing gears locking in
      const gearRing = this.ctx.createOscillator();
      gearRing.type = 'sine';
      gearRing.frequency.setValueAtTime(1450, t);
      
      const ringGain = this.ctx.createGain();
      ringGain.gain.setValueAtTime(0.065, t);
      ringGain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);

      gearRing.connect(ringGain);
      ringGain.connect(this.masterGain);
      gearRing.start(t);
      gearRing.stop(t + 0.08);

      // Click 2: Low-end clonk representing mechanical clutch snap
      const clutchClonk = this.ctx.createOscillator();
      clutchClonk.type = 'triangle';
      clutchClonk.frequency.setValueAtTime(170, t);
      clutchClonk.frequency.exponentialRampToValueAtTime(32, t + 0.1);

      const clonkGain = this.ctx.createGain();
      clonkGain.gain.setValueAtTime(0.24, t);
      clonkGain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

      clutchClonk.connect(clonkGain);
      clonkGain.connect(this.masterGain);
      clutchClonk.start(t);
      clutchClonk.stop(t + 0.15);

    } catch (e) {
      // Ignored
    }
  }

  /**
   * Fires combustible fuel pocket in direct bypass pipes, creating pops, crackles and burble bangs!
   */
  public triggerBackfire() {
    try {
      if (!this.ctx || this.isMuted || !this.masterGain) return;
      
      const t = this.ctx.currentTime;
      
      // Explosion 1: Heavy sub boom
      const pop1 = this.ctx.createOscillator();
      pop1.type = 'triangle';
      pop1.frequency.setValueAtTime(105, t);
      pop1.frequency.exponentialRampToValueAtTime(12, t + 0.15);
      
      const pop1Gain = this.ctx.createGain();
      pop1Gain.gain.setValueAtTime(0.85, t);
      pop1Gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
      
      pop1.connect(pop1Gain);
      pop1Gain.connect(this.masterGain);
      pop1.start(t);
      pop1.stop(t + 0.18);

      // Explosion 2: Searing metal clap (fuel combustion inside SUS304 steel)
      const pop2 = this.ctx.createOscillator();
      pop2.type = 'sawtooth';
      pop2.frequency.setValueAtTime(220, t);
      pop2.frequency.exponentialRampToValueAtTime(16, t + 0.09);
      
      const pop2Gain = this.ctx.createGain();
      pop2Gain.gain.setValueAtTime(0.52, t);
      pop2Gain.gain.exponentialRampToValueAtTime(0.001, t + 0.11);
      
      pop2.connect(pop2Gain);
      pop2Gain.connect(this.masterGain);
      pop2.start(t);
      pop2.stop(t + 0.13);

      // Crack 3: Reverberating combustion echo (30ms later)
      const t2 = t + 0.04;
      const pop3 = this.ctx.createOscillator();
      pop3.type = 'sawtooth';
      pop3.frequency.setValueAtTime(140, t2);
      pop3.frequency.exponentialRampToValueAtTime(10, t2 + 0.08);
      
      const pop3Gain = this.ctx.createGain();
      pop3Gain.gain.setValueAtTime(0.38, t2);
      pop3Gain.gain.exponentialRampToValueAtTime(0.001, t2 + 0.09);
      
      pop3.connect(pop3Gain);
      pop3Gain.connect(this.masterGain);
      pop3.start(t2);
      pop3.stop(t2 + 0.11);

    } catch (e) {
      // Ignored
    }
  }

  public stop() {
    try {
      this.oscs.forEach(o => {
        try { o.stop(); } catch(e) {}
      });
      this.oscs = [];
      this.oscGains = [];

      if (this.turboOsc) {
        try { this.turboOsc.stop(); } catch(e) {}
        this.turboOsc = null;
      }
      if (this.mechOsc) {
        try { this.mechOsc.stop(); } catch(e) {}
        this.mechOsc = null;
      }
      if (this.sharedNoiseNode) {
        this.sharedNoiseNode.disconnect();
        this.sharedNoiseNode = null;
      }
      if (this.lfo) {
        try { this.lfo.stop(); } catch(e) {}
        this.lfo = null;
      }

      if (this.ctx) {
        this.ctx.close();
        this.ctx = null;
      }
    } catch (err) {
      console.warn("Audio engine shutdown bypass:", err);
    }
  }
}

export default function App() {
  const audioEngineRef = useRef<ExhaustSynthEngine | null>(null);
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(false);

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      audioEngineRef.current?.stop();
    };
  }, []);

  // Navigation Tabs States
  const [activeTab, setActiveTab ] = useState<'builder' | 'tuning' | 'mods' | 'test' | 'ai' | 'manual'>('builder');
  const [modsViewMode, setModsViewMode] = useState<'categorized' | 'grid'>('categorized');
  const [selectedManualCat, setSelectedManualCat] = useState<'engine' | 'forced_induction' | 'fuel' | 'exhaust' | 'ecu'>('engine');
  const [installedModIds, setInstalledModIds] = useState<string[]>([]);

  // Garage and Subpart internal configurations
  const [activeVehicle, setActiveVehicle] = useState<VehicleProfile>(VEHICLE_PROFILES[0]);
  const [subParts, setSubParts] = useState<Record<string, string>>({
    pistons: 'stock',
    pistonSize: 'stock',
    crankshaft: 'stock',
    rods: 'stock',
    sparkPlugs: 'stock',
    camshaft: 'stock',
    airFilter: 'stock',
    wastegate: 'internal',
    boostValve: 'manual',
    injectorSize: 'stock',
    fuelRail: 'stock',
    fuelLine: 'stock',
    fuelPump: 'stock',
    ecuVariant: 'stock',
    wiringHarness: 'stock',
    ignitionCoils: 'stock',
    intercooler: 'stock',
    radiator: 'stock',
    coolingPipes: 'stock',
    thermostat: 'stock',
    manifoldType: 'stock',
    catbackDiameter: 'stock',
    exhaustValve: 'stock'
  });
  const [showVehicleGarage, setShowVehicleGarage] = useState(false);
  const [customCarForm, setCustomCarForm] = useState({
    name: '',
    brand: '',
    year: '2026',
    baseHP: 150,
    baseTorque: 200,
    baseWeight: 1300,
    baseRedline: 7000,
    cylinders: 4,
    displacement: '2.0 Liters'
  });

  // Load Search Param for Shared Build
  const [loadingShared, setLoadingShared] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ text: string, type: 'success' | 'info' | 'error' } | null>(null);

  const applyVehicleProfile = (profile: VehicleProfile) => {
    setActiveVehicle(profile);
    setInstalledModIds([]);
    // Find matching engine component in standard COMPONENT_CATALOG
    let matchingEngineId = 'inline4-stock';
    if (profile.cylinders === 6) {
      matchingEngineId = 'v6-valkyrie';
    } else if (profile.cylinders === 8) {
      matchingEngineId = 'v8-titan-crate';
    }
    
    setCanvasNodes(prev => prev.map(n => n.id === 'node-engine' ? {
      ...n,
      componentId: matchingEngineId,
      brand: profile.brand,
      name: `${profile.displacement} ${profile.brand} Block`,
      model: `${profile.name} Engine`
    } : n));

    setSelectedEngine(matchingEngineId);
    showToast(`Loaded ${profile.name} into the Tuning Bay! Engine initialized.`, 'success');
  };

  const handleToggleVehicleMod = (modId: string) => {
    setInstalledModIds((prev) => {
      if (prev.includes(modId)) {
        showToast("Uninstalled upgrade package", "info");
        return prev.filter((id) => id !== modId);
      } else {
        showToast("Hot-installed upgrade package!", "success");
        return [...prev, modId];
      }
    });
  };

  // Core Build Configurations
  const [buildName, setBuildName] = useState<string>('Daily Driver Pro');
  const [buildDescription, setBuildDescription] = useState<string>('Street tuned balance for spirited weekend track days and daily commutes.');

  // Interactive Node Canvas States
  const [canvasNodes, setCanvasNodes] = useState<CanvasNode[]>([
    { id: 'node-engine', componentId: 'inline4-stock', x: 380, y: 150, category: 'Engine Block', brand: 'OEM Spec', name: '2.0L I4 Stock Block', model: 'Standard 2.0L' },
    { id: 'node-turbo', componentId: 'gt2560-turbo', x: 40, y: 30, category: 'Forced Induction', brand: 'Garrett', name: 'Garrett GT2560 Turbocharger', model: 'GT2560R Ball-Bearing' },
    { id: 'node-cooling', componentId: 'cooling-intercooler-stock', x: 200, y: 30, category: 'Cooling System', brand: 'OEM Spec', name: 'OEM Standard Intercooler', model: 'Factory Core V1' },
    { id: 'node-fuel', componentId: 'injector-440', x: 40, y: 220, category: 'Fuel System', brand: 'Deatschwerks', name: 'High-Flow Fuel Injector Set (440cc)', model: 'DW 440cc Flow-Matched' },
    { id: 'node-ecu', componentId: 'ecu-stock', x: 200, y: 410, category: 'Electronics', brand: 'OEM Spec', name: 'Factory OEM Restricted ECU', model: 'ECU-OEM Standard Version' },
    { id: 'node-exhaust', componentId: 'exhaust-manifold-headers', x: 680, y: 180, category: 'Exhaust System', brand: 'Tomei Powered', name: 'Equal-Length Tubular Exhaust Headers', model: 'Expreme Equal-Length Headers' }
  ]);

  const [connections, setConnections] = useState<Connection[]>([
    { id: 'conn-1', fromNode: 'node-turbo', fromPort: 'out', toNode: 'node-cooling', toPort: 'in' },
    { id: 'conn-2', fromNode: 'node-cooling', fromPort: 'out', toNode: 'node-engine', toPort: 'air-in' },
    { id: 'conn-3', fromNode: 'node-fuel', fromPort: 'out', toNode: 'node-engine', toPort: 'fuel-in' },
    { id: 'conn-4', fromNode: 'node-ecu', fromPort: 'out', toNode: 'node-engine', toPort: 'ecu-in' },
    { id: 'conn-5', fromNode: 'node-engine', fromPort: 'exhaust-out', toNode: 'node-exhaust', toPort: 'in' }
  ]);

  const [activeWiring, setActiveWiring] = useState<{ nodeId: string; portId: string; isInput: boolean } | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Selected Components (IDs) - Synchronized using Canvas
  const [selectedEngine, setSelectedEngine] = useState<string>('inline4-stock');
  const [selectedTurbo, setSelectedTurbo] = useState<string | null>('gt2560-turbo');
  const [selectedFuelInjector, setSelectedFuelInjector] = useState<string | null>('injector-440');
  const [selectedFuelPump, setSelectedFuelPump] = useState<string | null>(null);
  const [selectedFuelRail, setSelectedFuelRail] = useState<string | null>(null);
  const [selectedECU, setSelectedECU] = useState<string>('ecu-stock');
  const [selectedIgnitionCoils, setSelectedIgnitionCoils] = useState<string | null>(null);
  
  // Multiple Select Items
  const [selectedInternals, setSelectedInternals] = useState<string[]>([]);
  const [selectedCooling, setSelectedCooling] = useState<string[]>(['cooling-intercooler-stock']);
  const [selectedExhaust, setSelectedExhaust] = useState<string[]>(['exhaust-manifold-headers']);

  // Tuning Parameters (Live adjusters)
  const [boostLimit, setBoostLimit] = useState<number>(1.2); // Bar
  const [fuelMapOffset, setFuelMapOffset] = useState<number>(0); // % Offset (Lean vs Rich)
  const [ignitionTimingOffset, setIgnitionTimingOffset] = useState<number>(0); // Deg (Retarded vs Advanced)

  // Dynamic audio recalibration on tuning/customization detail changes
  useEffect(() => {
    if (audioEngineRef.current) {
      audioEngineRef.current.recalibrateSound(getCarPlatform(activeVehicle.id), subParts, !!selectedTurbo);
    }
  }, [subParts, activeVehicle, selectedTurbo]);

  // Zoom control value for flowchart
  const [zoom, setZoom] = useState<number>(100);

  // Left sidebar collapse state
  const [expandedSection, setExpandedSection] = useState<string | null>('Engine Block');
  const [searchQuery, setSearchQuery] = useState('');

  // AI Dialog States
  const [aiAnalysis, setAiAnalysis] = useState<string>("CarLab PRO Diagnostics online. Set custom components and tuning offsets to analyze simulated thresholds.");
  const [aiWarnings, setAiWarnings] = useState<string[]>([
    "Review fuel supply rate when implementing stage 2 boost maps.",
    "Recommend upgraded clutch assemblies before exceeding 450 NM torque."
  ]);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([
    "Fit a Custom Front-Mount Intercooler (+15 HP cooling offset)",
    "Upgrade to high-durability JE Forged Pistons to handle cylinder compression",
    "Install standalone MoTeC Engine Management"
  ]);
  const [aiTip, setAiTip] = useState<string>("Ready for simulation testing!");
  const [loadingAI, setLoadingAI] = useState<boolean>(false);

  // Direct AI Chat State
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'assistant', text: string }>>([
    { role: 'assistant', text: "Hello! I am your CarLab PRO AI Advisors Assistant. Customize your powertrain, adjust fuel or boost dials on our Tuning mapping strip, or task me to audit your reliability and performance envelopes!" }
  ]);
  const [sendingChat, setSendingChat] = useState(false);

  // Save Builds History (locally persist so user never loses them)
  const [savedBuilds, setSavedBuilds] = useState<any[]>([]);

  // Selected item detail modal view
  const [inspectComponent, setInspectComponent] = useState<ComponentItem | null>(null);

  // Dyno Test Drive Runs States
  const [dynoRunning, setDynoRunning] = useState(false);
  const [dynoCountdown, setDynoCountdown] = useState<number | null>(null);
  const [dynoSpecsReport, setDynoSpecsReport] = useState<any | null>(null);
  const [dynoRPM, setDynoRPM] = useState(1000);
  const [dynoHP, setDynoHP] = useState(0);
  const [dynoSpeed, setDynoSpeed] = useState(0);
  const [dynoGear, setDynoGear] = useState(1);

  // Manual Interactive Audio Simulator States (Inspired by soundsmap.com)
  const [manualRevActive, setManualRevActive] = useState(false);
  const [manualRPM, setManualRPM] = useState(900);
  const [manualThrottle, setManualThrottle] = useState(0);
  const [manualGear, setManualGear] = useState(1);
  const [manualBoost, setManualBoost] = useState(0);
  const [manualClutchState, setManualClutchState] = useState(false);
  const [testMode, setTestMode] = useState<'auto' | 'manual'>('auto');

  // Stop manual engine if dyno is triggered
  useEffect(() => {
    if (dynoRunning) {
      setManualRevActive(false);
    }
  }, [dynoRunning]);

  // Clean up audio when both simulation types are stopped running
  useEffect(() => {
    if (!dynoRunning && !manualRevActive) {
      audioEngineRef.current?.stop();
      audioEngineRef.current = null;
    }
  }, [dynoRunning, manualRevActive]);

  // Print PDF modal state
  const [showPrintCertificate, setShowPrintCertificate] = useState(false);

  // Canvas details
  const [selectedCanvasNode, setSelectedCanvasNode] = useState<string | null>(null);

  // TRACING ALGORITHM TO DETERMINE ACTIVE/CONNECTED NODES ON WORKSPACE
  const getActiveConnectedIds = (): string[] => {
    const activeIds: string[] = [];
    const visited = new Set<string>();

    const traceLineage = (startNodeId: string, portId: string): string[] => {
      const results: string[] = [];
      const queue: { nodeId: string; port: string }[] = [{ nodeId: startNodeId, port: portId }];
      
      while (queue.length > 0) {
        const curr = queue.shift()!;
        const key = `${curr.nodeId}-${curr.port}`;
        if (visited.has(key)) continue;
        visited.add(key);

        // Find connections where 'toNode' is curr.nodeId and 'toPort' is curr.port
        const incoming = connections.filter(c => c.toNode === curr.nodeId && c.toPort === curr.port);
        incoming.forEach(conn => {
          const srcNode = canvasNodes.find(n => n.id === conn.fromNode);
          if (srcNode) {
            results.push(srcNode.id);
            // Trace further back if the source node has inputs
            const srcPorts = getPortsForCategory(srcNode.category);
            srcPorts.inputs.forEach(p => {
              queue.push({ nodeId: srcNode.id, port: p });
            });
          }
        });
      }
      return results;
    };

    // Forward trace for outputs (Exhaust)
    const traceForwardLineage = (startNodeId: string, portId: string): string[] => {
      const results: string[] = [];
      const queue: { nodeId: string; port: string }[] = [{ nodeId: startNodeId, port: portId }];
      const visitedF = new Set<string>();

      while (queue.length > 0) {
        const curr = queue.shift()!;
        const key = `${curr.nodeId}-${curr.port}`;
        if (visitedF.has(key)) continue;
        visitedF.add(key);

        // Find connections where 'fromNode' is curr.nodeId and 'fromPort' is curr.port
        const outgoing = connections.filter(c => c.fromNode === curr.nodeId && c.fromPort === curr.port);
        outgoing.forEach(conn => {
          const dstNode = canvasNodes.find(n => n.id === conn.toNode);
          if (dstNode) {
            results.push(dstNode.id);
            // Trace forward to its outputs if any
            const dstPorts = getPortsForCategory(dstNode.category);
            dstPorts.outputs.forEach(p => {
              queue.push({ nodeId: dstNode.id, port: p });
            });
          }
        });
      }
      return results;
    };

    // 1. Engine Block itself is always active
    activeIds.push('node-engine');

    // 2. Trace air input line
    const airActive = traceLineage('node-engine', 'air-in');
    activeIds.push(...airActive);

    // 3. Trace fuel input line
    const fuelActive = traceLineage('node-engine', 'fuel-in');
    activeIds.push(...fuelActive);

    // 4. Trace ECU input line
    const ecuActive = traceLineage('node-engine', 'ecu-in');
    activeIds.push(...ecuActive);

    // 5. Trace Internals input line
    const internalsActive = traceLineage('node-engine', 'internals-in');
    activeIds.push(...internalsActive);

    // 6. Trace Exhaust output line (outgoing)
    const exhaustActive = traceForwardLineage('node-engine', 'exhaust-out');
    activeIds.push(...exhaustActive);

    return activeIds;
  };

  // Keep selection states in sync with connected nodes on canvas
  useEffect(() => {
    const activeIds = getActiveConnectedIds();

    // 1. Engine
    const engineNd = canvasNodes.find(n => n.category === 'Engine Block');
    if (engineNd) {
      setSelectedEngine(engineNd.componentId);
    }

    // 2. Turbo
    const activeTurbo = canvasNodes.find(n => n.category === 'Forced Induction' && activeIds.includes(n.id));
    setSelectedTurbo(activeTurbo ? activeTurbo.componentId : null);

    // 3. Fuel setup
    const activeInj = canvasNodes.find(n => n.category === 'Fuel System' && n.componentId.includes('injector') && activeIds.includes(n.id));
    setSelectedFuelInjector(activeInj ? activeInj.componentId : null);

    const activePump = canvasNodes.find(n => n.category === 'Fuel System' && n.componentId.includes('pump') && activeIds.includes(n.id));
    setSelectedFuelPump(activePump ? activePump.componentId : null);

    const activeRail = canvasNodes.find(n => n.category === 'Fuel System' && n.componentId.includes('rail') && activeIds.includes(n.id));
    setSelectedFuelRail(activeRail ? activeRail.componentId : null);

    // 4. ECU
    const activeEcuNode = canvasNodes.find(n => n.category === 'Electronics' && n.componentId.includes('ecu') && activeIds.includes(n.id));
    setSelectedECU(activeEcuNode ? activeEcuNode.componentId : 'ecu-stock'); 

    const activeCoils = canvasNodes.find(n => n.category === 'Electronics' && n.componentId.includes('ignition') && activeIds.includes(n.id));
    setSelectedIgnitionCoils(activeCoils ? activeCoils.componentId : null);

    // 5. Internals
    const activeInternals = canvasNodes.filter(n => n.category === 'Engine Internals' && activeIds.includes(n.id)).map(n => n.componentId);
    setSelectedInternals(activeInternals);

    // 6. Cooling
    const activeCooling = canvasNodes.filter(n => n.category === 'Cooling System' && activeIds.includes(n.id)).map(n => n.componentId);
    setSelectedCooling(activeCooling);

    // 7. Exhaust
    const activeExhaust = canvasNodes.filter(n => n.category === 'Exhaust System' && activeIds.includes(n.id)).map(n => n.componentId);
    setSelectedExhaust(activeExhaust);
  }, [canvasNodes, connections]);

  // Sync canvas nodes from a structured load
  const syncCanvasFromSelection = (components: any) => {
    const newNodes: CanvasNode[] = [];
    const newConns: Connection[] = [];

    // Always place Engine Block
    const engineId = components.engine || 'inline4-stock';
    const engineItem = COMPONENT_CATALOG.find(c => c.id === engineId) || COMPONENT_CATALOG[0];
    newNodes.push({
      id: 'node-engine',
      componentId: engineId,
      x: 380,
      y: 150,
      category: 'Engine Block',
      brand: engineItem.brand,
      name: engineItem.name,
      model: engineItem.model
    });

    // Forced Induction
    if (components.turbo) {
      const turboItem = COMPONENT_CATALOG.find(c => c.id === components.turbo);
      if (turboItem) {
        newNodes.push({
          id: 'node-turbo',
          componentId: components.turbo,
          x: 40,
          y: 30,
          category: 'Forced Induction',
          brand: turboItem.brand,
          name: turboItem.name,
          model: turboItem.model
        });
        const hasCooling = components.cooling && components.cooling.length > 0;
        if (hasCooling) {
          newConns.push({ id: 'sync-conn-turbo', fromNode: 'node-turbo', fromPort: 'out', toNode: 'node-cooling-0', toPort: 'in' });
        } else {
          newConns.push({ id: 'sync-conn-turbo-direct', fromNode: 'node-turbo', fromPort: 'out', toNode: 'node-engine', toPort: 'air-in' });
        }
      }
    }

    // Cooling System
    if (components.cooling && components.cooling.length > 0) {
      components.cooling.forEach((cId: string, idx: number) => {
        const item = COMPONENT_CATALOG.find(c => c.id === cId);
        if (item) {
          const nodeId = `node-cooling-${idx}`;
          newNodes.push({
            id: nodeId,
            componentId: cId,
            x: 200,
            y: 30 + (idx * 110),
            category: 'Cooling System',
            brand: item.brand,
            name: item.name,
            model: item.model
          });
          newConns.push({ id: `sync-conn-cooling-${idx}`, fromNode: nodeId, fromPort: 'out', toNode: 'node-engine', toPort: 'air-in' });
        }
      });
    }

    // Fuel System - Injector
    if (components.fuelInjector) {
      const item = COMPONENT_CATALOG.find(c => c.id === components.fuelInjector);
      if (item) {
        newNodes.push({
          id: 'node-fuel-inj',
          componentId: components.fuelInjector,
          x: 40,
          y: 220,
          category: 'Fuel System',
          brand: item.brand,
          name: item.name,
          model: item.model
        });
        newConns.push({ id: 'sync-conn-fuel-inj', fromNode: 'node-fuel-inj', fromPort: 'out', toNode: 'node-engine', toPort: 'fuel-in' });
      }
    }
    // Pump
    if (components.fuelPump) {
      const item = COMPONENT_CATALOG.find(c => c.id === components.fuelPump);
      if (item) {
        newNodes.push({
          id: 'node-fuel-pump',
          componentId: components.fuelPump,
          x: 40,
          y: 340,
          category: 'Fuel System',
          brand: item.brand,
          name: item.name,
          model: item.model
        });
        newConns.push({ id: 'sync-conn-fuel-pump', fromNode: 'node-fuel-pump', fromPort: 'out', toNode: 'node-engine', toPort: 'fuel-in' });
      }
    }

    // ECU/Electronics
    if (components.ecu) {
      const item = COMPONENT_CATALOG.find(c => c.id === components.ecu);
      if (item) {
        newNodes.push({
          id: 'node-ecu',
          componentId: components.ecu,
          x: 200,
          y: 410,
          category: 'Electronics',
          brand: item.brand,
          name: item.name,
          model: item.model
        });
        newConns.push({ id: 'sync-conn-ecu', fromNode: 'node-ecu', fromPort: 'out', toNode: 'node-engine', toPort: 'ecu-in' });
      }
    }

    // Exhaust System
    if (components.exhaust && components.exhaust.length > 0) {
      components.exhaust.forEach((eId: string, idx: number) => {
        const item = COMPONENT_CATALOG.find(c => c.id === eId);
        if (item) {
          const nodeId = `node-exhaust-${idx}`;
          newNodes.push({
            id: nodeId,
            componentId: eId,
            x: 680,
            y: 180 + (idx * 110),
            category: 'Exhaust System',
            brand: item.brand,
            name: item.name,
            model: item.model
          });
          newConns.push({ id: `sync-conn-exhaust-${idx}`, fromNode: 'node-engine', fromPort: 'exhaust-out', toNode: nodeId, toPort: 'in' });
        }
      });
    }

    // Engine Internals
    if (components.internals && components.internals.length > 0) {
      components.internals.forEach((iId: string, idx: number) => {
        const item = COMPONENT_CATALOG.find(c => c.id === iId);
        if (item) {
          const nodeId = `node-internals-${idx}`;
          newNodes.push({
            id: nodeId,
            componentId: iId,
            x: 500,
            y: 360 + (idx * 110),
            category: 'Engine Internals',
            brand: item.brand,
            name: item.name,
            model: item.model
          });
          newConns.push({ id: `sync-conn-internals-${idx}`, fromNode: nodeId, fromPort: 'out', toNode: 'node-engine', toPort: 'internals-in' });
        }
      });
    }

    setCanvasNodes(newNodes);
    setConnections(newConns);
  };

  // Load saved configurations from LocalStorage & remote server DB
  const handleLoadSharedBase64Build = (code: string) => {
    setLoadingShared(true);
    showToast("Decoding shared telemetry specifications...", "info");
    try {
      const build = deserializeBuild(code);
      if (build && build.carId) {
        // Find matching vehicle profile
        const profile = VEHICLE_PROFILES.find(v => v.id === build.carId);
        if (profile) {
          setActiveVehicle(profile);
          
          let matchingEngineId = 'inline4-stock';
          if (profile.cylinders === 6) {
            matchingEngineId = 'v6-valkyrie';
          } else if (profile.cylinders === 8) {
            matchingEngineId = 'v8-titan-crate';
          }
          
          setCanvasNodes(prev => prev.map(n => n.id === 'node-engine' ? {
            ...n,
            componentId: matchingEngineId,
            brand: profile.brand,
            name: `${profile.displacement} ${profile.brand} Block`,
            model: `${profile.name} Engine`
          } : n));

          setSelectedEngine(matchingEngineId);
        }

        if (Array.isArray(build.modIds)) {
          setInstalledModIds(build.modIds);
        }

        if (build.subParts) {
          setSubParts(build.subParts);
        }

        showToast("Tuner build loaded successfully!", "success");
      } else {
        showToast("The shared build code is invalid.", "error");
      }
    } catch (err) {
      showToast("Could not unpack build specifications.", "error");
    } finally {
      setLoadingShared(false);
    }
  };

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const buildParam = searchParams.get('build');
    const sharedId = searchParams.get('shared');
    
    if (buildParam) {
      handleLoadSharedBase64Build(buildParam);
    } else if (sharedId) {
      loadSharedBuild(sharedId);
    } else {
      const savedStr = localStorage.getItem('carlab_local_builds');
      if (savedStr) {
        setSavedBuilds(JSON.parse(savedStr));
      }
    }
    
    fetch('/api/builds')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data) && data.length > 0) {
          setSavedBuilds(prev => {
            const keys = new Set(prev.map(b => b.id));
            const serverUnique = data.filter(s => !keys.has(s.id));
            return [...prev, ...serverUnique];
          });
        }
      })
      .catch(_err => console.log("Offline mode, using browser local storage state."));
  }, []);

  // Sync state to local storage fallback
  useEffect(() => {
    localStorage.setItem('carlab_local_builds', JSON.stringify(savedBuilds));
  }, [savedBuilds]);

  // Toast auto-dissolve
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);



  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'info') => {
    setToastMessage({ text, type });
  };

  // Remote Shared Build fetch
  const loadSharedBuild = async (id: string) => {
    setLoadingShared(true);
    showToast(`Retrieving shared telemetry mapping #${id}...`, 'info');
    try {
      const res = await fetch(`/api/builds/${id}`);
      if (res.ok) {
        const build = await res.json();
        setBuildName(build.name || 'Shared Build');
        setBuildDescription(build.description || '');
        if (build.components) {
          syncCanvasFromSelection(build.components);
        }
        if (build.tuning) {
          setBoostLimit(build.tuning.boostLimit ?? 1.2);
          setFuelMapOffset(build.tuning.fuelMapOffset ?? 0);
          setIgnitionTimingOffset(build.tuning.ignitionTimingOffset ?? 0);
        }
        showToast("Telemetry successfully synchronized!", "success");
      } else {
        showToast("Shared build not found or expired.", "error");
      }
    } catch (e) {
      showToast("Offline mode. Unable to fetch shared telemetry.", "error");
    } finally {
      setLoadingShared(false);
    }
  };

  // Gather actual details of selected components
  const engineItem = COMPONENT_CATALOG.find(c => c.id === selectedEngine) || COMPONENT_CATALOG[0];
  const turboItem = COMPONENT_CATALOG.find(c => c.id === selectedTurbo);
  const injectorItem = COMPONENT_CATALOG.find(c => c.id === selectedFuelInjector);
  const pumpItem = COMPONENT_CATALOG.find(c => c.id === selectedFuelPump);
  const railItem = COMPONENT_CATALOG.find(c => c.id === selectedFuelRail);
  const ecuItem = COMPONENT_CATALOG.find(c => c.id === selectedECU) || COMPONENT_CATALOG.find(c => c.id === 'ecu-stock')!;
  const coilsItem = COMPONENT_CATALOG.find(c => c.id === selectedIgnitionCoils);
  
  const internalsItems = COMPONENT_CATALOG.filter(c => selectedInternals.includes(c.id));
  const coolingItems = COMPONENT_CATALOG.filter(c => selectedCooling.includes(c.id));
  const exhaustItems = COMPONENT_CATALOG.filter(c => selectedExhaust.includes(c.id));

  // --- COMPUTE MATH TELEMETRY SIMULATIONS ---
  // Base HP & Torque defaults based on active vehicle profile
  let baseHP = activeVehicle.baseHP;
  let baseTorque = activeVehicle.baseTorque;
  let baseWeight = activeVehicle.baseWeight;
  let baseRedline = activeVehicle.baseRedline;

  // Let legacy engine selector override defaults only if on default Civic profile
  if (activeVehicle.id === 'civic-1.5t') {
    if (selectedEngine === 'v6-valkyrie') {
      baseHP = 360;
      baseTorque = 510;
      baseWeight = 1180;
      baseRedline = 6800;
    } else if (selectedEngine === 'v8-titan-crate') {
      baseHP = 440;
      baseTorque = 580;
      baseWeight = 1290;
      baseRedline = 6500;
    }
  }

  // Sum sub-parts adjustments
  let subPartsHPAdd = 0;
  let subPartsTorqueAdd = 0;
  let subPartsWeightAdd = 0;
  let subPartsTempImpact = 0;
  let subPartsReliabilityAdd = 0;
  let subPartsCostAdd = 0;

  Object.entries(subParts).forEach(([partKey, selectedOption]) => {
    const item = (SUBPART_CATALOG as Record<string, Record<string, any>>)[partKey]?.[selectedOption as string];
    if (item) {
      subPartsHPAdd += item.powerBonus;
      subPartsTorqueAdd += item.torqueBonus;
      subPartsWeightAdd += item.weight;
      subPartsTempImpact += item.tempIncrease;
      subPartsReliabilityAdd += item.reliabilityBonus;
      subPartsCostAdd += item.cost;
    }
  });

  // Turbo boost scalar (Tuning adjustment)
  // Standard bar rating is 1.0. For turbo boosts, the multiplier affects turbo power output
  const turboMultiplier = selectedTurbo ? (boostLimit / 1.0) : 1.0;

  // sum component power offsets
  let componentHPAdd = 0;
  let componentTorqueAdd = 0;
  let componentWeightAdd = 0;
  let temperatureImpact = 0;

  // Turbocharger
  if (turboItem) {
    componentHPAdd += turboItem.powerBonus * turboMultiplier;
    componentTorqueAdd += turboItem.torqueBonus * turboMultiplier;
    componentWeightAdd += turboItem.weight;
    temperatureImpact += turboItem.tempIncrease * (boostLimit * 0.9);
  }

  // Fuel System
  if (injectorItem) {
    componentHPAdd += injectorItem.powerBonus;
    componentTorqueAdd += injectorItem.torqueBonus;
    componentWeightAdd += injectorItem.weight;
    temperatureImpact += injectorItem.tempIncrease;
  }
  if (pumpItem) {
    componentHPAdd += pumpItem.powerBonus;
    componentTorqueAdd += pumpItem.torqueBonus;
    componentWeightAdd += pumpItem.weight;
    temperatureImpact += pumpItem.tempIncrease;
  }
  if (railItem) {
    componentHPAdd += railItem.powerBonus;
    componentTorqueAdd += railItem.torqueBonus;
    componentWeightAdd += railItem.weight;
    temperatureImpact += railItem.tempIncrease;
  }

  // ECU & Electronics
  if (ecuItem) {
    componentHPAdd += ecuItem.powerBonus;
    componentTorqueAdd += ecuItem.torqueBonus;
    componentWeightAdd += ecuItem.weight;
    temperatureImpact += ecuItem.tempIncrease;
  }
  if (coilsItem) {
    componentHPAdd += coilsItem.powerBonus;
    componentTorqueAdd += coilsItem.torqueBonus;
    componentWeightAdd += coilsItem.weight;
    temperatureImpact += coilsItem.tempIncrease;
  }

  // Internals
  internalsItems.forEach(item => {
    componentHPAdd += item.powerBonus;
    componentTorqueAdd += item.torqueBonus;
    componentWeightAdd += item.weight;
    temperatureImpact += item.tempIncrease;
  });

  // Cooling
  coolingItems.forEach(item => {
    // These reduce intake/engine temps
    temperatureImpact += item.tempIncrease;
    componentHPAdd += item.powerBonus;
    componentTorqueAdd += item.torqueBonus;
    componentWeightAdd += item.weight;
  });

  // Exhaust
  exhaustItems.forEach(item => {
    componentHPAdd += item.powerBonus;
    componentTorqueAdd += item.torqueBonus;
    componentWeightAdd += item.weight; // Headers reduce weight (negative)
    temperatureImpact += item.tempIncrease;
  });

  // Tuning Slider Multipliers:
  // Advanced Ignition Timing Timing offset yields +1.2% power per degree advanced, but elevates temps and knock risk
  const timingHPFactor = 1.0 + (ignitionTimingOffset * 0.015);
  const timingTorqueFactor = 1.0 + (ignitionTimingOffset * 0.011);

  // Fuel air maps lean vs rich offsets
  // Lean fueling increases heat, increases cylinder danger, yields +0.5% till knock point, but is extremely hazardous.
  // Rich fueling lowers temp dramatically, but reduces peak power slightly.
  let fuelHPFactor = 1.0;
  if (fuelMapOffset < 0) {
    // Lean
    fuelHPFactor = 1.0 + (Math.abs(fuelMapOffset) * 0.004);
  } else {
    // Rich
    fuelHPFactor = 1.0 - (fuelMapOffset * 0.003);
  }

  // Compute final Horsepower and Torque
  const currentVehicleMods = VEHICLE_MODS_DATABASE.filter(mod => installedModIds.includes(mod.id));
  const activeModsCalculations = applySelectedModsToEngine(
    { hp: baseHP, torque: baseTorque, weight: baseWeight, loudness: 0, roughness: 0, brightness: 0, backfireRate: 0 },
    currentVehicleMods
  );

  let calculatedHP = Math.round((baseHP + componentHPAdd + subPartsHPAdd + activeModsCalculations.hpAdd) * timingHPFactor * fuelHPFactor);
  let calculatedTorque = Math.round((baseTorque + componentTorqueAdd + subPartsTorqueAdd + activeModsCalculations.torqueAdd) * timingTorqueFactor * fuelHPFactor);

  // Weight Calculation: Base carcass + added components + sub-parts weight
  const calculatedWeight = Math.round(baseWeight + componentWeightAdd + subPartsWeightAdd + activeModsCalculations.weightImpact);

  // Acceleration (0-100 km/h) based on pure HP/Weight ratio
  // Accel = SQRT(Weight / HP) * 10.5
  let calculatedAccel = parseFloat((Math.sqrt(calculatedWeight / calculatedHP) * 9.8).toFixed(2));
  if (calculatedAccel < 2.5) calculatedAccel = 2.5; // supercar traction limit
  if (calculatedAccel > 8.5) calculatedAccel = 8.5; // low power traction limit

  // Top Speed (km/h) based on HP and aeroflow drag
  // TopSpeed = (HP * 1.635) / (Weight / 1000)
  let calculatedTopSpeed = Math.round((calculatedHP * 1.95) / (calculatedWeight / 1050));
  if (calculatedTopSpeed < 160) calculatedTopSpeed = 160;
  if (calculatedTopSpeed > 365) calculatedTopSpeed = 365;

  // Redline (RPM limit)
  let updatedRedline = baseRedline;
  if (subParts.crankshaft === 'carrillo-billet') {
    updatedRedline += 900;
  } else if (subParts.crankshaft === 'eagle-forged') {
    updatedRedline += 400;
  } else if (selectedInternals.includes('crankshaft-carrillo')) {
    updatedRedline += 800; // Racing crank unlocks higher limit!
  } else if (selectedInternals.includes('crankshaft-eagle')) {
    updatedRedline += 400;
  }

  if (subParts.ecuVariant === 'motec') {
    updatedRedline += 350;
  } else if (subParts.ecuVariant === 'haltech') {
    updatedRedline += 150;
  } else if (selectedECU === 'ecu-motec') {
    updatedRedline += 300;
  } else if (selectedECU === 'ecu-haltech') {
    updatedRedline += 150;
  }

  // Estimated Operating Temperature (°C)
  // Base is 92°C. Affected by boost, fuel map states, radiator updates
  let calculatedTemp = Math.round(92 + temperatureImpact + subPartsTempImpact + (ignitionTimingOffset * 0.7) + (fuelMapOffset < 0 ? Math.abs(fuelMapOffset) * 0.5 : -fuelMapOffset * 0.3));

  // Start manual sound engine (sound matching rig inspired by soundsmap.com)
  const startManualEngine = () => {
    if (dynoRunning) {
      showToast("Please standby. Stop the active Dyno run first!", "error");
      return;
    }
    
    // Stop any existing context
    audioEngineRef.current?.stop();
    
    const synth = new ExhaustSynthEngine();
    synth.setMuted(isAudioMuted);
    
    const hasTurboVal = !!selectedTurbo;

    synth.start(getCarPlatform(activeVehicle.id), subParts, hasTurboVal);
    
    audioEngineRef.current = synth;
    setManualRevActive(true);
    setManualRPM(900); // Start cleanly as low idle
    setManualThrottle(0);
    setManualGear(1);
    setManualClutchState(false);
    showToast("Engine Ignition ON. Idle loop acoustic humming active! 🔊", "success");
  };

  const stopManualEngine = () => {
    setManualRevActive(false);
    audioEngineRef.current?.stop();
    audioEngineRef.current = null;
    showToast("Engine Ignition OFF.", "info");
  };

  const triggerManualGearShift = (targetGear: number) => {
    if (!manualRevActive || !audioEngineRef.current) return;
    if (manualClutchState) return;

    // Shift clonk
    audioEngineRef.current.triggerShift();
    setManualClutchState(true);
    showToast(`Clutch pressed ➔ Gear ${targetGear}`, "info");

    // Re-engage clutch 200ms later to allow RPM snap and backfire
    setTimeout(() => {
      setManualGear(targetGear);
      setManualClutchState(false);
      
      // Dynamic overrun explosions are mapped to high exhaust flow loads above 3000 RPM
      if (manualRPM > 3000) {
        audioEngineRef.current?.triggerBackfire();
      }
    }, 200);
  };

  // Real-time manual physics calculations tick
  useEffect(() => {
    if (!manualRevActive) return;
    
    const isLightCrank = subParts.crankshaft === 'crankshaft-carrillo';
    const spoolFactor = selectedTurbo ? (selectedTurbo === 'gt2560-turbo' ? 0.95 : selectedTurbo === 's480-turbo' ? 0.4 : 0.65) : 0;
    
    const interval = setInterval(() => {
      setManualRPM(current => {
        // Clutch down frees engine flywheel load entirely (throttle becomes ineffective, drops to mechanical friction decay)
        let effectiveThrottle = manualClutchState ? 0.0 : manualThrottle / 100;
        
        let targetRPM = 900 + (updatedRedline - 900) * Math.pow(effectiveThrottle, 1.1);
        if (targetRPM > updatedRedline) targetRPM = updatedRedline;
        
        // Highly responsive billet crank cuts weight in half, accelerating spool
        const revFactor = isLightCrank ? 150 : 85;
        const dropFactor = manualClutchState ? (isLightCrank ? 180 : 110) : (isLightCrank ? 115 : 75);
        
        let nextRPM = current;
        if (current < targetRPM) {
          nextRPM += revFactor * (0.35 + effectiveThrottle * 0.65);
          if (nextRPM > targetRPM) nextRPM = targetRPM;
        } else if (current > targetRPM) {
          nextRPM -= dropFactor * (0.4 + (1.0 - effectiveThrottle) * 0.6);
          if (nextRPM < targetRPM) nextRPM = targetRPM;
        }
        
        // Micro-vibrations
        const thermalJitter = (Math.random() - 0.5) * 5;
        nextRPM = Math.max(900, Math.min(updatedRedline, nextRPM + thermalJitter));
        
        // Spooling forced-induction boost pressure value
        let currentBoost = 0;
        if (selectedTurbo) {
          if (effectiveThrottle > 0.4 && nextRPM > 2200) {
            currentBoost = Math.min(boostLimit, (nextRPM / updatedRedline) * boostLimit * spoolFactor);
          }
        }
        setManualBoost(parseFloat(currentBoost.toFixed(2)));
        
        // Update physical synthesizers
        if (audioEngineRef.current) {
          audioEngineRef.current.update(
            nextRPM,
            updatedRedline,
            currentBoost,
            Math.max(0.01, effectiveThrottle),
            manualClutchState
          );
        }
        
        return nextRPM;
      });
    }, 30);
    
    return () => clearInterval(interval);
  }, [
    manualRevActive,
    manualThrottle,
    manualClutchState,
    updatedRedline,
    subParts.crankshaft,
    selectedTurbo,
    boostLimit
  ]);

  // Real-time internals simulation diagnostic Warnings and Auto-Suggestions
  useEffect(() => {
    const warnings: string[] = [];
    const suggestions: string[] = [];

    // 1. Pistons warning
    if (selectedTurbo && boostLimit > 1.3 && subParts.pistons === 'stock') {
      warnings.push("Stock Cast Pistons are extremely vulnerable above 1.3 Bar! Risk of severe top dome cracking.");
      suggestions.push("Upgrade Engine Block Internals to JE Forged 2618 Pistons to support Stage II boost.");
    }
    // 2. Piston bore and Cylinder force
    if (boostLimit > 1.8 && subParts.pistonSize === 'overbore-1.0' && subParts.pistons !== 'wiseco-forged') {
      warnings.push("High overbore sleeve thinnings combined with extreme boost elevates cylinder block fracture risk.");
      suggestions.push("Equip Wiseco ArmorGlide pistons or reduce turbo boost levels below 1.8 Bar.");
    }
    // 3. Spark plugs blowout
    if (selectedTurbo && boostLimit > 1.5 && subParts.sparkPlugs === 'stock') {
      warnings.push("OEM copper range spark plugs suffer high cylinder pressure ionization blowout.");
      suggestions.push("Equip high-energy NGK Iridium cold range spark plugs via Engine Block internal upgrades.");
    }
    // 4. ECU bottleneck on forced induction
    if (selectedTurbo && subParts.ecuVariant === 'stock') {
      warnings.push("OEM locked factory computer lacks dynamic map sensors to monitor intake manifold boot flows.");
      suggestions.push("Upgrade Electronics Node to Haltech standalone or MoTeC Custom ECU.");
    }
    // 5. Fuel injector rate starvation
    if (selectedTurbo && boostLimit > 1.2 && subParts.injectorSize === 'stock') {
      warnings.push("Standard 220cc fuel injector size is narrow; severe danger of lean heat spikes and melted valves.");
      suggestions.push("Fit Deatschwerks 440cc or Injector Dynamics 850cc injectors via Fuel System upgrades.");
    }
    // 6. Fuel pump starve
    if (selectedTurbo && boostLimit > 1.5 && subParts.fuelPump === 'stock') {
      warnings.push("Factory fuel pump flow index cannot sustain sufficient pressure under peak wide-open throttle maps.");
      suggestions.push("Update Fuel System node with high density Walbro 255 LPH or Bosch 044 External pump.");
    }
    // 7. Radiator overheating block
    if (calculatedTemp > 102 && subParts.radiator === 'stock') {
      warnings.push("Critical coolant heat warning! Standard copper core radiator lacks dissipation surface size.");
      suggestions.push("Equip Mishimoto 3-Row Alloy Radiator to stabilize working water temperature.");
    }
    // 8. Fuel piping & Ethanol corrosion
    if (fuelMapOffset > 10 && subParts.fuelLine === 'stock') {
      warnings.push("Ethanol maps and rich fuel feeds will quickly corrode standard rubber fuel carriage hoses.");
      suggestions.push("Install PTFE Teflon solvent-proof Braided fuel lines inside the Fuel node.");
    }
    // 9. Ignition coils spark failure
    if (ignitionTimingOffset > 4 && subParts.ignitionCoils === 'stock') {
      warnings.push("Heavy ignition timing advances trigger spark scatter with low energy stock coils.");
      suggestions.push("Upgrade Electronics node with Okada Projects high-intensity Smart Coils.");
    }

    if (suggestions.length === 0) {
      suggestions.push("Advance ignition map timing by minor degrees to expand dynamic bottom-end power torque.");
      suggestions.push("Initiate virtual track test drive dyno simulation to gauge peak speed and shift metrics.");
      suggestions.push("Print your build certificate to manifest the current state for your records.");
    }

    setAiWarnings(warnings);
    setAiSuggestions(suggestions);
  }, [subParts, selectedTurbo, boostLimit, ignitionTimingOffset, fuelMapOffset, calculatedTemp]);

  // Fuel Consumption (L/100km)
  // Base fuel intake factor based on HP displacement + rich/lean mapping
  let calculatedFuel = parseFloat((5.5 + (calculatedHP * 0.015) + (fuelMapOffset > 0 ? fuelMapOffset * 0.15 : fuelMapOffset * 0.05)).toFixed(1));
  if (calculatedFuel < 4.5) calculatedFuel = 4.5;
  if (calculatedFuel > 22.5) calculatedFuel = 22.5;

  // Weight Distribution (%)
  // Default is 53% Front / 47% Rear.
  // Standard displacements & turbo elements shift the bias to front. Radium fuel additions add rear profile ballast.
  let shiftFront = 0;
  if (selectedEngine === 'v8-titan-crate') shiftFront += 3;
  else if (selectedEngine === 'v6-valkyrie') shiftFront += 1;
  
  if (selectedTurbo === 's480-turbo') shiftFront += 2;
  else if (selectedTurbo) shiftFront += 1;

  if (selectedFuelPump || selectedFuelInjector) shiftFront -= 1; // Rear additions

  const frontWeightRatio = 53 + shiftFront;
  const rearWeightRatio = 100 - frontWeightRatio;

  // --- OPTIMIZED RELIABILITY SCORE ALGORITHMS ---
  // Base is 85%, affected by active vehicle starting points and sub-parts upgrades
  let reliability = (activeVehicle.id === 'bmw-e46' ? 78 : activeVehicle.id === 'shelby-v8' ? 82 : 85) + subPartsReliabilityAdd;

  // 1. Boost level risk vs Internals strength
  if (selectedTurbo) {
    const boostOverage = Math.max(0, boostLimit - 1.0);
    // Heavy boost penalty
    let boostPenalty = boostOverage * 25; // -25% reliability per additional 1.0 Bar

    // Reduce boost penalty if robust internals are installed:
    let compressionResilience = 0;
    if (subParts.pistons === 'wiseco-forged') {
      compressionResilience += 16;
    } else if (subParts.pistons === 'je-forged') {
      compressionResilience += 12;
    } else if (selectedInternals.includes('pistons-wiseco')) {
      compressionResilience += 12;
    } else if (selectedInternals.includes('pistons-je')) {
      compressionResilience += 8;
    }

    if (subParts.crankshaft === 'carrillo-billet') {
      compressionResilience += 18;
    } else if (subParts.crankshaft === 'eagle-forged') {
      compressionResilience += 10;
    } else if (selectedInternals.includes('crankshaft-carrillo')) {
      compressionResilience += 15;
    } else if (selectedInternals.includes('crankshaft-eagle')) {
      compressionResilience += 10;
    }

    if (subParts.rods === 'manley-hbeam') {
      compressionResilience += 11;
    } else if (selectedInternals.includes('rods-hbeam')) {
      compressionResilience += 10;
    }

    boostPenalty = Math.max(0, boostPenalty - compressionResilience);
    reliability -= boostPenalty;
  }

  // 2. High heat penalty
  if (calculatedTemp > 100) {
    reliability -= (calculatedTemp - 100) * 1.5;
  }

  // 3. Engine knock timings advanced penalty
  if (ignitionTimingOffset > 0) {
    let sparkKnockMultiplier = 2.5;
    // Standalone ECU maps can dynamically trim knock
    if (subParts.ecuVariant === 'motec') sparkKnockMultiplier = 0.8;
    else if (subParts.ecuVariant === 'haltech') sparkKnockMultiplier = 1.3;
    else if (selectedECU === 'ecu-motec') sparkKnockMultiplier = 1.0;
    else if (selectedECU === 'ecu-haltech') sparkKnockMultiplier = 1.6;

    reliability -= (ignitionTimingOffset * sparkKnockMultiplier);
  }

  // 4. Lean fuel air map penalty
  if (fuelMapOffset < 0) {
    reliability -= (Math.abs(fuelMapOffset) * 1.2);
  }

  // 5. Comp honors of components
  if (subParts.ecuVariant === 'motec') reliability += 12;
  else if (subParts.ecuVariant === 'haltech') reliability += 8;
  else if (selectedECU === 'ecu-motec') reliability += 10;
  else if (selectedECU === 'ecu-haltech') reliability += 6;

  if (subParts.ignitionCoils === 'okada-plasma') reliability += 4;
  else if (selectedIgnitionCoils === 'ignition-coils-high') reliability += 3;

  // Bound reliability between 40% and 98%
  reliability = Math.round(Math.max(40, Math.min(98, reliability)));

  // Generate Power Curve data series for Recharts line graph
  const generatePowerCurveData = () => {
    const rpmSteps = [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000];
    const torquePeakRPM = 4800;
    
    return rpmSteps.filter(rpm => rpm <= updatedRedline).map(rpm => {
      if (rpm === 0) return { rpm: "0", Torque: 0, Power: 0 };
      
      // Real physics torque curve curve mapping
      // Torque rises, peaks around 4800, then slopes off
      const normalizedDist = (rpm - torquePeakRPM) / (updatedRedline * 0.95);
      const curveReduction = Math.pow(normalizedDist, 2) * 0.45;
      
      let currentTorque = calculatedTorque * (1.0 - curveReduction);
      if (rpm < 2000) {
        currentTorque = calculatedTorque * (0.5 + (rpm / 4000));
      }
      currentTorque = Math.round(Math.max(100, currentTorque));
      
      // Direct physics calculation formula of HP: HP = (Torque NM * RPM) / 9549 (scaled for model visuals)
      let currentHP = Math.round((currentTorque * rpm) / 9549 * 1.28);
      // Cap at actual computed calculatedHP
      if (currentHP > calculatedHP) {
        currentHP = Math.round(calculatedHP - (Math.random() * 5));
      }
      if (rpm < 1500) {
        currentHP = Math.round(calculatedHP * 0.15);
      }
      
      return {
        rpm: rpm.toString(),
        "Torque (NM)": currentTorque,
        "Power (HP)": currentHP
      };
    });
  };

  const powerCurveData = generatePowerCurveData();

  // Trigger Gemini AI advisor evaluation
  const executeAIAdvisorCall = async () => {
    setLoadingAI(true);
    showToast("Analyzing custom configuration...", "info");
    try {
      const response = await fetch('/api/ai/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          buildName,
          description: buildDescription,
          components: {
            engine: engineItem?.name,
            turbo: turboItem?.name,
            intercooler: coolingItems.find(c => c.id.includes('intercooler'))?.name || "Stock IC",
            fuelInjector: injectorItem?.name,
            fuelPump: pumpItem?.name,
            ecu: ecuItem?.name,
            internals: internalsItems.map(i => i.name),
            exhaust: exhaustItems.map(e => e.name),
          },
          stats: {
            hp: calculatedHP,
            torque: calculatedTorque,
            accel: calculatedAccel,
            topSpeed: calculatedTopSpeed,
            reliability,
            estTemp: calculatedTemp,
          }
        }),
      });
      if (response.ok) {
        const data = await response.json();
        setAiAnalysis(data.analysis || "Tuning limits calculated.");
        setAiWarnings(data.warnings || []);
        setAiSuggestions(data.suggestions || []);
        setAiTip(data.tip || "Diagnosis done.");
        showToast("AI diagnostics updated!", "success");
      } else {
        throw new Error();
      }
    } catch (e) {
      showToast("Unable to reach AI advisor, loaded diagnostics.", "info");
    } finally {
      setLoadingAI(false);
    }
  };

  // Trigger Chat with AI assistant
  const sendChatMessage = async () => {
    if (!chatInput.trim()) return;
    const userMsg = chatInput.trim();
    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setSendingChat(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          history: chatMessages,
          message: userMsg,
          currentBuild: {
            name: buildName,
            components: {
              engine: engineItem?.name,
              turbo: turboItem?.name,
              fuel: injectorItem?.name,
              ecu: ecuItem?.name,
              internals: internalsItems.map(i => i.name)
            },
            stats: {
              hp: calculatedHP,
              torque: calculatedTorque,
              reliability
            }
          }
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setChatMessages(prev => [...prev, { role: 'assistant', text: data.text }]);
      } else {
        throw new Error();
      }
    } catch (e) {
      setChatMessages(prev => [...prev, { role: 'assistant', text: "Tuning server communication interrupted. Configure custom setup or check API status in Secrets." }]);
    } finally {
      setSendingChat(false);
    }
  };

  // Perform virtual Dyno Test Drive simulation run
  const triggerDynoSimulation = () => {
    if (dynoRunning) return;
    setDynoRunning(true);
    setDynoCountdown(3);
    setDynoRPM(1000);
    setDynoSpeed(0);
    setDynoGear(1);
    
    // 3 second count down
    const countInterval = setInterval(() => {
      setDynoCountdown(prev => {
        if (prev === null) return null;
        if (prev <= 1) {
          clearInterval(countInterval);
          startSimulationAnimation();
          return null;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const startSimulationAnimation = () => {
    let currentRpm = 1000;
    let gear = 1;
    let speed = 0;
    let shiftTicks = 0; // State indicating clutch depression
    
    // Stop any existing audio context safely
    audioEngineRef.current?.stop();

    // Build and activate the new exhaust synthesizer
    const synth = new ExhaustSynthEngine();
    synth.setMuted(isAudioMuted);
    
    const hasTurboVal = !!selectedTurbo;

    synth.start(getCarPlatform(activeVehicle.id), subParts, hasTurboVal);
    audioEngineRef.current = synth;
    
    const runTimer = setInterval(() => {
      // 1. If currently depressed in shifting clutches, decline revs with throttle-off
      if (shiftTicks > 0) {
        shiftTicks--;
        
        // Revs drop during shift engagement
        currentRpm -= 180; 
        if (currentRpm < 1000) currentRpm = 1000;
        
        // Update audio: 0 throttle, shifting active, 0 boost
        synth.update(currentRpm, updatedRedline, 0, 0.0, true);
        
        setDynoRPM(currentRpm);
        
        // Shift finishes, snap clutch and slam full open throttle!
        if (shiftTicks === 0) {
          synth.triggerBackfire(); // Slam open fuel overrun pop
        }
        return;
      }

      // 2. Continuous smooth acceleration climb (slower crawl for auditory appreciation)
      currentRpm += 42;
      
      // Calculate instantaneous dyno HP (peaks around torque curves)
      const torqueRatio = 1.0 - Math.pow((currentRpm - 4800) / (updatedRedline), 2);
      const instantHP = Math.round((calculatedHP * (0.4 + (currentRpm / updatedRedline) * 0.6)) * (torqueRatio * 0.95 + 0.1));
      setDynoHP(Math.max(40, Math.min(calculatedHP, instantHP)));

      // Safely update audio oscillators (Wide open throttle = 1.0)
      synth.update(currentRpm, updatedRedline, boostLimit, 1.0, false);

      // Shifting gears layout
      if (currentRpm >= updatedRedline) {
        if (gear < 6) {
          // Play click & trigger shifter
          synth.triggerShift();
          
          gear += 1;
          // Hold clutch open for 9 ticks (9 * 60ms = 540ms shift duration)
          shiftTicks = 9;
          currentRpm = Math.round(updatedRedline * 0.62); // Match drop RPM target
          showToast(`Gear ${gear - 1} ➔ Gear ${gear}!`, 'info');
        } else {
          // Finished drag run at top speed!
          clearInterval(runTimer);
          synth.stop();
          setDynoRunning(false);
          const quarterMile = parseFloat((Math.sqrt(calculatedWeight / calculatedHP) * 25.2).toFixed(2));
          setDynoSpecsReport({
            achievedHP: calculatedHP,
            achievedTorque: calculatedTorque,
            topSpeedReached: calculatedTopSpeed,
            zeroToHundred: calculatedAccel,
            quarterMile,
            engineHealth: reliability > 78 ? 'PRISTINE' : reliability > 60 ? 'MILD LEAK' : 'MELTED BLOCK / GASKET BLOWN'
          });
          setActiveTab('test');
          return;
        }
      }

      speed = Math.round((currentRpm * gear * 0.005) + (gear * 22));
      if (speed > calculatedTopSpeed) speed = calculatedTopSpeed;

      setDynoRPM(currentRpm);
      setDynoGear(gear);
      setDynoSpeed(speed);
    }, 60);
  };

  // Full configuration saves structure
  const handleSaveBuild = async () => {
    const payload = {
      name: buildName,
      description: buildDescription,
      components: {
        engine: selectedEngine,
        turbo: selectedTurbo,
        fuelInjector: selectedFuelInjector,
        fuelPump: selectedFuelPump,
        fuelRail: selectedFuelRail,
        ecu: selectedECU,
        ignitionCoils: selectedIgnitionCoils,
        internals: selectedInternals,
        cooling: selectedCooling,
        exhaust: selectedExhaust,
      },
      tuning: {
        boostLimit,
        fuelMapOffset,
        ignitionTimingOffset,
      },
      subParts,
      activeVehicle,
      stats: {
        hp: calculatedHP,
        torque: calculatedTorque,
        accel: calculatedAccel,
        topSpeed: calculatedTopSpeed,
        reliability,
      }
    };

    try {
      const res = await fetch('/api/builds', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        // Insert into lists
        setSavedBuilds(prev => {
          if (prev.some(b => b.id === data.id)) return prev;
          return [data, ...prev];
        });
        showToast(`Configuration "${buildName}" saved successfully!`, 'success');
      } else {
        throw new Error();
      }
    } catch (e) {
      // Local storage fallback
      const mockSaved = {
        ...payload,
        id: Math.random().toString(36).substring(2, 9),
        createdAt: new Date().toISOString()
      };
      setSavedBuilds(prev => [mockSaved, ...prev]);
      showToast(`Saved locally! offline file persistence synced.`, 'success');
    }
  };

  // Share build URL link generator
  const handleShareBuildLink = async () => {
    // Save first
    const payload = {
      name: buildName,
      description: buildDescription,
      components: {
        engine: selectedEngine,
        turbo: selectedTurbo,
        fuelInjector: selectedFuelInjector,
        fuelPump: selectedFuelPump,
        fuelRail: selectedFuelRail,
        ecu: selectedECU,
        ignitionCoils: selectedIgnitionCoils,
        internals: selectedInternals,
        cooling: selectedCooling,
        exhaust: selectedExhaust,
      },
      tuning: {
        boostLimit,
        fuelMapOffset,
        ignitionTimingOffset,
      },
      subParts,
      activeVehicle,
      stats: {
        hp: calculatedHP,
        torque: calculatedTorque,
        accel: calculatedAccel,
        topSpeed: calculatedTopSpeed,
        reliability,
      }
    };

    try {
      const res = await fetch('/api/builds', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        const shareableUrl = `${window.location.origin}?shared=${data.id}`;
        await navigator.clipboard.writeText(shareableUrl);
        showToast("Telemetry share URL copied to clipboard!", "success");
      } else {
        throw new Error();
      }
    } catch (e) {
      showToast("Offline mode. Unable to generate cloud sync share link.", "error");
    }
  };

  // Canvas coordinate and wiring click handlers
  const canvasRef = useRef<HTMLDivElement>(null);
  const [draggedNodeId, setDraggedNodeId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number, y: number }>({ x: 0, y: 0 });

  const getPortAbsoluteCoords = (node: CanvasNode, portId: string) => {
    const nodeWidth = 200;
    const nodeHeight = 130;
    
    if (node.id === 'node-engine') {
      const engineWidth = 220;
      switch (portId) {
        case 'air-in': return { x: node.x, y: node.y + 35 };
        case 'fuel-in': return { x: node.x, y: node.y + 65 };
        case 'ecu-in': return { x: node.x, y: node.y + 95 };
        case 'internals-in': return { x: node.x, y: node.y + 125 };
        case 'exhaust-out': return { x: node.x + engineWidth, y: node.y + 75 };
      }
    }

    const ports = getPortsForCategory(node.category);
    
    if (ports.inputs.includes(portId)) {
      const pIdx = ports.inputs.indexOf(portId);
      const spacing = nodeHeight / (ports.inputs.length + 1);
      return { x: node.x, y: node.y + spacing * (pIdx + 1) };
    } else if (ports.outputs.includes(portId)) {
      const pIdx = ports.outputs.indexOf(portId);
      const spacing = nodeHeight / (ports.outputs.length + 1);
      return { x: node.x + nodeWidth, y: node.y + spacing * (pIdx + 1) };
    }

    return { x: node.x + nodeWidth / 2, y: node.y + nodeHeight / 2 };
  };

  const getBezierPath = (x1: number, y1: number, x2: number, y2: number) => {
    const dx = Math.abs(x2 - x1);
    const controlOffset = Math.max(50, dx * 0.5);
    return `M ${x1} ${y1} C ${x1 + controlOffset} ${y1}, ${x2 - controlOffset} ${y2}, ${x2} ${y2}`;
  };

  const handleNodeMouseDown = (nodeId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDraggedNodeId(nodeId);
    const node = canvasNodes.find(n => n.id === nodeId);
    if (node && canvasRef.current) {
      const rect = canvasRef.current.getBoundingClientRect();
      const mouseX = (e.clientX - rect.left) / (zoom / 100);
      const mouseY = (e.clientY - rect.top) / (zoom / 100);
      setDragOffset({
        x: mouseX - node.x,
        y: mouseY - node.y
      });
    }
  };

  const handleNodeTouchStart = (nodeId: string, e: React.TouchEvent) => {
    e.stopPropagation();
    setDraggedNodeId(nodeId);
    const node = canvasNodes.find(n => n.id === nodeId);
    if (node && canvasRef.current && e.touches.length > 0) {
      const touch = e.touches[0];
      const rect = canvasRef.current.getBoundingClientRect();
      const mouseX = (touch.clientX - rect.left) / (zoom / 100);
      const mouseY = (touch.clientY - rect.top) / (zoom / 100);
      setDragOffset({
        x: mouseX - node.x,
        y: mouseY - node.y
      });
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (draggedNodeId) {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        const mouseX = (e.clientX - rect.left) / (zoom / 100);
        const mouseY = (e.clientY - rect.top) / (zoom / 100);
        
        let newX = Math.round(mouseX - dragOffset.x);
        let newY = Math.round(mouseY - dragOffset.y);
        
        newX = Math.max(10, Math.min(1400, newX));
        newY = Math.max(10, Math.min(800, newY));

        setCanvasNodes(prev => prev.map(n => n.id === draggedNodeId ? { ...n, x: newX, y: newY } : n));
      }
    } else if (activeWiring) {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        const mouseX = (e.clientX - rect.left) / (zoom / 100);
        const mouseY = (e.clientY - rect.top) / (zoom / 100);
        setMousePos({ x: mouseX, y: mouseY });
      }
    }
  };

  const handleCanvasTouchMove = (e: React.TouchEvent) => {
    if (draggedNodeId && e.touches.length > 0) {
      if (e.cancelable) e.preventDefault();
      if (canvasRef.current) {
        const touch = e.touches[0];
        const rect = canvasRef.current.getBoundingClientRect();
        const mouseX = (touch.clientX - rect.left) / (zoom / 100);
        const mouseY = (touch.clientY - rect.top) / (zoom / 100);
        
        let newX = Math.round(mouseX - dragOffset.x);
        let newY = Math.round(mouseY - dragOffset.y);
        
        newX = Math.max(10, Math.min(1400, newX));
        newY = Math.max(10, Math.min(800, newY));

        setCanvasNodes(prev => prev.map(n => n.id === draggedNodeId ? { ...n, x: newX, y: newY } : n));
      }
    } else if (activeWiring && e.touches.length > 0) {
      if (canvasRef.current) {
        const touch = e.touches[0];
        const rect = canvasRef.current.getBoundingClientRect();
        const mouseX = (touch.clientX - rect.left) / (zoom / 100);
        const mouseY = (touch.clientY - rect.top) / (zoom / 100);
        setMousePos({ x: mouseX, y: mouseY });
      }
    }
  };

  const handleCanvasMouseUp = () => {
    setDraggedNodeId(null);
  };

  const handlePortClick = (nodeId: string, portId: string, isInput: boolean, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!activeWiring) {
      setActiveWiring({ nodeId, portId, isInput });
      const node = canvasNodes.find(n => n.id === nodeId);
      if (node) {
        const coords = getPortAbsoluteCoords(node, portId);
        setMousePos(coords);
      }
    } else {
      if (activeWiring.isInput === isInput) {
        showToast("Connect an Output port to an Input port!", "error");
        setActiveWiring(null);
        return;
      }

      if (activeWiring.nodeId === nodeId) {
        showToast("Cannot connect component to itself!", "error");
        setActiveWiring(null);
        return;
      }

      const fromNode = isInput ? activeWiring.nodeId : nodeId;
      const fromPort = isInput ? activeWiring.portId : portId;
      const toNode = isInput ? nodeId : activeWiring.nodeId;
      const toPort = isInput ? portId : activeWiring.portId;

      const exists = connections.some(c => c.fromNode === fromNode && c.fromPort === fromPort && c.toNode === toNode && c.toPort === toPort);
      if (exists) {
        showToast("Connection already exists!", "info");
        setActiveWiring(null);
        return;
      }

      const targetNode = canvasNodes.find(n => n.id === toNode);
      if (targetNode?.id === 'node-engine') {
        const sourceNode = canvasNodes.find(n => n.id === fromNode);
        if (sourceNode) {
          let isValid = false;
          if (toPort === 'air-in') {
            isValid = sourceNode.category === 'Forced Induction' || sourceNode.category === 'Cooling System';
          } else if (toPort === 'fuel-in') {
            isValid = sourceNode.category === 'Fuel System';
          } else if (toPort === 'ecu-in') {
            isValid = sourceNode.category === 'Electronics';
          } else if (toPort === 'internals-in') {
            isValid = sourceNode.category === 'Engine Internals';
          }

          if (!isValid) {
            showToast(`Mechanics error: Cannot plug ${sourceNode.category} output into Engine ${toPort.replace('-in', '')} input!`, "error");
            setActiveWiring(null);
            return;
          }
        }
      }

      const newConn: Connection = {
        id: `conn-${Math.random().toString(36).substring(2, 6)}`,
        fromNode,
        fromPort,
        toNode,
        toPort
      };

      setConnections(prev => [...prev, newConn]);
      showToast("Pipes and telemetry wires connected! System online.", "success");
      setActiveWiring(null);
    }
  };

  // Load a historic layout
  const handleLoadHistoricBuild = (build: any) => {
    setBuildName(build.name || 'Custom Build');
    setBuildDescription(build.description || '');
    if (build.components) {
      syncCanvasFromSelection(build.components);
    }
    if (build.tuning) {
      setBoostLimit(build.tuning.boostLimit ?? 1.2);
      setFuelMapOffset(build.tuning.fuelMapOffset ?? 0);
      setIgnitionTimingOffset(build.tuning.ignitionTimingOffset ?? 0);
    }
    if (build.subParts) {
      setSubParts(build.subParts);
    }
    if (build.activeVehicle) {
      setActiveVehicle(build.activeVehicle);
    }
    showToast(`Loaded layout "${build.name}"`, 'success');
  };

  // Delete a historic build
  const handleDeleteHistoricBuild = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await fetch(`/api/builds/${id}`, { method: 'DELETE' });
    } catch (err) {}
    setSavedBuilds(prev => prev.filter(b => b.id !== id));
    showToast("Build deleted from history", "info");
  };

  // Handle single component additions as nodes on the canvas
  const handleToggleComponent = (item: ComponentItem) => {
    if (item.category === 'Engine Block') {
      setCanvasNodes(prev => prev.map(n => n.id === 'node-engine' ? {
        ...n,
        componentId: item.id,
        brand: item.brand,
        name: item.name,
        model: item.model
      } : n));
      showToast(`Swapped block to ${item.name}!`, 'success');
      return;
    }

    const existingNode = canvasNodes.find(n => n.componentId === item.id);
    if (existingNode) {
      setCanvasNodes(prev => prev.filter(n => n.id !== existingNode.id));
      setConnections(prev => prev.filter(c => c.fromNode !== existingNode.id && c.toNode !== existingNode.id));
      showToast(`Removed node ${item.name} from canvas workspace.`, 'info');
    } else {
      let nodesToKeep = [...canvasNodes];
      let connsToKeep = [...connections];

      if (item.category === 'Forced Induction') {
        const prevTurboNode = canvasNodes.find(n => n.category === 'Forced Induction');
        if (prevTurboNode) {
          nodesToKeep = nodesToKeep.filter(n => n.id !== prevTurboNode.id);
          connsToKeep = connsToKeep.filter(c => c.fromNode !== prevTurboNode.id && c.toNode !== prevTurboNode.id);
        }
      } else if (item.category === 'Electronics' && item.id.includes('ecu')) {
        const prevEcuNode = canvasNodes.find(n => n.category === 'Electronics' && n.componentId.includes('ecu'));
        if (prevEcuNode) {
          nodesToKeep = nodesToKeep.filter(n => n.id !== prevEcuNode.id);
          connsToKeep = connsToKeep.filter(c => c.fromNode !== prevEcuNode.id && c.toNode !== prevEcuNode.id);
        }
      }

      const newNodeId = `node-${item.category.toLowerCase().replace(/ /g, '-')}-${Math.random().toString(36).substring(2, 6)}`;
      
      let spawnX = 120 + Math.random() * 80;
      let spawnY = 80 + Math.random() * 100;
      
      switch (item.category) {
        case 'Forced Induction':
          spawnX = 60; spawnY = 50;
          break;
        case 'Cooling System':
          spawnX = 200; spawnY = 50;
          break;
        case 'Fuel System':
          spawnX = 60; spawnY = 220;
          break;
        case 'Electronics':
          spawnX = 200; spawnY = 410;
          break;
        case 'Engine Internals':
          spawnX = 500; spawnY = 360;
          break;
        case 'Exhaust System':
          spawnX = 680; spawnY = 180;
          break;
      }

      const newNode: CanvasNode = {
        id: newNodeId,
        componentId: item.id,
        x: Math.round(spawnX),
        y: Math.round(spawnY),
        category: item.category,
        brand: item.brand,
        name: item.name,
        model: item.model
      };

      setCanvasNodes([...nodesToKeep, newNode]);
      setConnections(connsToKeep);
      showToast(`Spawned ${item.name} node. Connect its port nodes on the canvas to activate!`, 'success');
    }
  };

  // Left sidebar category structure
  const categories = [
    { title: 'Engine Block', icon: <Layers size={15} className="text-cyan-400" /> },
    { title: 'Forced Induction', icon: <Flame size={15} className="text-emerald-400" /> },
    { title: 'Fuel System', icon: <Fuel size={15} className="text-violet-400" /> },
    { title: 'Engine Internals', icon: <Wrench size={15} className="text-pink-400" /> },
    { title: 'Electronics', icon: <Cpu size={15} className="text-red-400" /> },
    { title: 'Cooling System', icon: <Activity size={15} className="text-teal-400" /> },
    { title: 'Exhaust System', icon: <TrendingUp size={15} className="text-orange-400" /> },
  ];

  // Search filtered components catalog
  const filteredCatalog = COMPONENT_CATALOG.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  return (
    <div className="min-h-screen text-slate-100 flex flex-col select-none" style={{ backgroundColor: THEME_COLORS.background }}>
      {/* Dynamic Toast Notification */}
      {toastMessage && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-xl border flex items-center gap-3 shadow-2xl transition-all duration-300 transform translate-y-0 ${
          toastMessage.type === 'success' ? 'bg-emerald-950/90 border-emerald-500 text-emerald-300 shadow-emerald-500/10' :
          toastMessage.type === 'error' ? 'bg-rose-950/90 border-rose-500 text-rose-300 shadow-rose-500/10' :
          'bg-cyan-950/90 border-cyan-500 text-cyan-300 shadow-cyan-500/10'
        }`}>
          {toastMessage.type === 'success' && <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />}
          {toastMessage.type === 'error' && <div className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />}
          {toastMessage.type === 'info' && <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />}
          <span className="font-medium text-xs tracking-wide">{toastMessage.text}</span>
        </div>
      )}

      {/* Shared Build Overlay */}
      {loadingShared && (
        <div className="fixed inset-0 z-50 bg-black/80 flex flex-col items-center justify-center gap-4 backdrop-blur-sm">
          <Loader2 className="animate-spin text-purple-500" size={50} />
          <p className="text-slate-300 text-sm tracking-widest font-mono">SYNCHRONIZING TELEMETRY MAPS...</p>
        </div>
      )}

      {/* 🚗 Tuning Bay Garage Selection & Custom Vehicle Builder Modal */}
      {showVehicleGarage && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 flex items-center justify-center p-4 md:p-6 backdrop-blur-md overflow-y-auto font-sans">
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-purple-500/30 p-6 md:p-8 rounded-3xl max-w-4xl w-full text-slate-100 shadow-2xl relative max-h-[95vh] overflow-y-auto">
            <button 
              className="absolute top-5 right-5 text-slate-400 hover:text-slate-100 p-2 hover:bg-slate-800 rounded-full transition duration-150 cursor-pointer text-sm font-bold" 
              onClick={() => setShowVehicleGarage(false)}
            >
              ✕ CLOSE
            </button>
            
            <div className="border-b border-purple-500/20 pb-5 mb-6">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-3xl">🏎️</span>
                <h1 className="text-xl font-extrabold tracking-wider bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
                  CARLAB PRO TUNING BAY GARAGE
                </h1>
              </div>
              <p className="text-slate-400 text-xs">
                Deploy elite predefined racing blueprints or forge a custom telemetry replication of your real-life project car!
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Presets List */}
              <div className="lg:col-span-5 flex flex-col gap-4">
                <h3 className="text-xs font-bold text-purple-400 tracking-wider uppercase font-mono mb-1">
                  Available Presets
                </h3>
                <div className="space-y-3 overflow-y-auto pr-1 max-h-[50vh]">
                  {VEHICLE_PROFILES.map((profile) => {
                    const isSelected = activeVehicle.id === profile.id;
                    return (
                      <div 
                        key={profile.id}
                        onClick={() => {
                          applyVehicleProfile(profile);
                          setShowVehicleGarage(false);
                        }}
                        className={`p-3.5 rounded-xl border text-left cursor-pointer transition duration-150 transform hover:-translate-y-0.5 ${
                          isSelected 
                            ? 'bg-purple-950/25 border-purple-500 shadow-lg shadow-purple-500/10 text-slate-100' 
                            : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900/90'
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-xs">{profile.brand} {profile.name}</span>
                          <span className="text-[9px] px-2 py-0.5 rounded bg-slate-950 text-amber-400 font-mono text-right uppercase">
                            {profile.difficulty}
                          </span>
                        </div>
                        <p className="text-[10px] text-zinc-400 mt-1 leading-normal line-clamp-2">
                          {profile.description}
                        </p>
                        <div className="flex gap-2 mt-2 py-1 border-t border-slate-800/20 text-[9px] font-mono text-purple-300">
                          <span>{profile.cylinders} Cyl</span>
                          <span>•</span>
                          <span>{profile.displacement}</span>
                          <span>•</span>
                          <span className="text-emerald-400">{profile.baseHP} HP specs</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Forge Custom Vehicle Form */}
              <div className="lg:col-span-7 border-t lg:border-t-0 lg:border-l border-slate-800 pt-6 lg:pt-0 lg:pl-8">
                <h3 className="text-xs font-bold text-cyan-400 tracking-wider uppercase font-mono mb-4">
                  🔨 Custom project car forge (Melt & Cast Specs)
                </h3>
                
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!customCarForm.name || !customCarForm.brand) {
                      showToast("Please enter both car brand and model name!", "error");
                      return;
                    }
                    const customProfile: VehicleProfile = {
                      id: 'user-custom-' + Math.random().toString(36).substring(2, 6),
                      name: customCarForm.name,
                      brand: customCarForm.brand,
                      year: customCarForm.year || '2026',
                      displacement: customCarForm.displacement || '2.0L',
                      cylinders: Number(customCarForm.cylinders) || 4,
                      baseHP: Number(customCarForm.baseHP) || 150,
                      baseTorque: Number(customCarForm.baseTorque) || 200,
                      baseWeight: Number(customCarForm.baseWeight) || 1300,
                      baseRedline: Number(customCarForm.cylinders) === 8 ? 6500 : Number(customCarForm.cylinders) === 6 ? 6800 : 7000,
                      difficulty: 'Unrestricted Custom',
                      description: `Custom calibrated replica of ${customCarForm.year} ${customCarForm.brand} ${customCarForm.name}. Fully open schema pipeline.`
                    };
                    applyVehicleProfile(customProfile);
                    setShowVehicleGarage(false);
                  }}
                  className="space-y-4 text-xs"
                >
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1 font-semibold uppercase tracking-wider text-[10px]">Brand / Manufacturer</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Honda, BMW, Nissan"
                        value={customCarForm.brand}
                        onChange={(e) => setCustomCarForm(prev => ({ ...prev, brand: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-2.5 outline-none text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1 font-semibold uppercase tracking-wider text-[10px]">Model Name</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Civic VTEC, M3, Silvia S15"
                        value={customCarForm.name}
                        onChange={(e) => setCustomCarForm(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-2.5 outline-none text-slate-100"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-slate-400 mb-1 font-semibold uppercase tracking-wider text-[10px]">Release Year</label>
                      <input 
                        type="text" 
                        value={customCarForm.year}
                        onChange={(e) => setCustomCarForm(prev => ({ ...prev, year: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-2.5 outline-none text-slate-100 font-mono text-center"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1 font-semibold uppercase tracking-wider text-[10px]">Engine displacement</label>
                      <input 
                        type="text" 
                        placeholder="e.g. 2.0L, 1.8L"
                        value={customCarForm.displacement}
                        onChange={(e) => setCustomCarForm(prev => ({ ...prev, displacement: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-2.5 outline-none text-slate-100 font-mono text-center"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1 font-semibold uppercase tracking-wider text-[10px]">Cylinder Count</label>
                      <select 
                        value={customCarForm.cylinders}
                        onChange={(e) => setCustomCarForm(prev => ({ ...prev, cylinders: Number(e.target.value) }))}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-2.5 outline-none text-slate-100 font-mono text-center"
                      >
                        <option value={4}>4 Cylinders</option>
                        <option value={6}>6 Cylinders</option>
                        <option value={8}>8 Cylinders</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 pt-1">
                    <div>
                      <label className="block text-slate-400 mb-1 font-semibold uppercase tracking-wider text-[10px]">Baseline Power</label>
                      <input 
                        type="number" 
                        value={customCarForm.baseHP}
                        onChange={(e) => setCustomCarForm(prev => ({ ...prev, baseHP: Number(e.target.value) }))}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-2.5 outline-none text-slate-100 font-mono text-center"
                      />
                      <span className="text-[10px] text-zinc-500 text-center block mt-1">HP</span>
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1 font-semibold uppercase tracking-wider text-[10px]">Baseline Torque</label>
                      <input 
                        type="number" 
                        value={customCarForm.baseTorque}
                        onChange={(e) => setCustomCarForm(prev => ({ ...prev, baseTorque: Number(e.target.value) }))}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-2.5 outline-none text-slate-100 font-mono text-center"
                      />
                      <span className="text-[10px] text-zinc-500 text-center block mt-1">NM</span>
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1 font-semibold uppercase tracking-wider text-[10px]">Curb Weight</label>
                      <input 
                        type="number" 
                        value={customCarForm.baseWeight}
                        onChange={(e) => setCustomCarForm(prev => ({ ...prev, baseWeight: Number(e.target.value) }))}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-lg p-2.5 outline-none text-slate-100 font-mono text-center"
                      />
                      <span className="text-[10px] text-zinc-500 text-center block mt-1">KG</span>
                    </div>
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold rounded-xl shadow-lg shadow-cyan-500/10 transition flex items-center justify-center gap-2 uppercase tracking-wide cursor-pointer mt-4"
                  >
                    ⚡ Spawn Project Car Setup
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Print telemetry certificate popup */}
      {showPrintCertificate && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-6 backdrop-blur-md overflow-y-auto">
          <div className="bg-slate-900 border border-purple-500/40 p-8 rounded-2xl max-w-2xl w-full text-slate-100 shadow-2xl print:shadow-none print:border-none relative">
            <button className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 print:hidden text-lg font-bold" onClick={() => setShowPrintCertificate(false)}>✕</button>
            <div className="text-center border-b border-purple-500/20 pb-6 mb-6">
              <div className="flex justify-center gap-2 mb-2">
                <span className="text-3xl">🏎️</span>
                <h1 className="text-2xl font-bold tracking-wider text-purple-400 font-mono">CARLAB PRO SPECIALIST</h1>
              </div>
              <p className="text-slate-400 text-xs tracking-widest">OFFICIAL ENGINE TELEMETRY SHEET & PROFILE</p>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm mb-6">
              <div>
                <span className="text-slate-400 text-xs">BUILD CONFIG</span>
                <h3 className="font-bold text-slate-200 mt-1">{buildName}</h3>
                <p className="text-slate-400 text-xs mt-1 italic">{buildDescription}</p>
              </div>
              <div className="text-right">
                <span className="text-slate-400 text-xs">DIAGNOSTIC STAMP</span>
                <p className="text-slate-200 font-mono text-xs mt-1">{new Date().toISOString().split('T')[0]} @ CarLab PRO</p>
                <div className={`mt-2 inline-block px-3 py-1 rounded bg-slate-800 text-xs font-bold border ${reliability >= 80 ? 'border-emerald-500 text-emerald-400' : 'border-amber-500 text-amber-400'}`}>
                  RELIABILITY: {reliability}%
                </div>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl mb-6">
              <h4 className="text-xs font-bold text-cyan-400 tracking-wider mb-2 font-mono">INSTALLED SPECIFICATIONS SHEET</h4>
              <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-xs">
                <div className="flex justify-between border-b border-slate-800 pb-1">
                  <span className="text-slate-400">Engine block:</span>
                  <span className="font-semibold">{engineItem.name}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-1">
                  <span className="text-slate-400">Forced Induction:</span>
                  <span className="font-semibold text-emerald-400">{turboItem?.name || 'Naturally Aspirated'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-1">
                  <span className="text-slate-400">Fuel Setup:</span>
                  <span className="font-semibold text-violet-400">{injectorItem?.name || 'Stock'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-1">
                  <span className="text-slate-400">ECU mapping:</span>
                  <span className="font-semibold text-rose-400">{ecuItem?.name || 'Stock'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-1">
                  <span className="text-slate-400">Operating Boost:</span>
                  <span className="font-semibold font-mono">{selectedTurbo ? `${boostLimit.toFixed(1)} Bar` : 'Unboosted'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800 pb-1">
                  <span className="text-slate-400">Timing Advance:</span>
                  <span className="font-semibold font-mono">{ignitionTimingOffset > 0 ? `+${ignitionTimingOffset}°` : `${ignitionTimingOffset}°`}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 text-center mb-6">
              <div className="bg-slate-950 p-3 rounded-lg border border-cyan-500/20">
                <span className="text-[10px] text-slate-400 font-mono">DYNAMIC POWER</span>
                <p className="text-xl font-bold font-mono text-cyan-400">{calculatedHP} HP</p>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-purple-500/20">
                <span className="text-[10px] text-slate-400 font-mono">PEAK TORQUE</span>
                <p className="text-xl font-bold font-mono text-purple-400">{calculatedTorque} NM</p>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-orange-500/20">
                <span className="text-[10px] text-slate-400 font-mono">0-100 KM/H</span>
                <p className="text-xl font-bold font-mono text-orange-400">{calculatedAccel} s</p>
              </div>
            </div>

            <div className="text-xs text-slate-400 border-t border-purple-500/10 pt-4 flex justify-between items-center print:hidden">
              <span>Print report as PDF to share with automotive developers.</span>
              <button 
                className="bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 px-4 rounded-lg flex items-center gap-2 transition"
                onClick={() => window.print()}
              >
                <Printer size={15} /> Confirm Print
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Header Navigation Strip */}
      <header className="border-b border-purple-500/20 px-4 md:px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-950 relative z-10 w-full">
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-orange-500 flex items-center justify-center shadow-lg shadow-purple-500/20 shrink-0">
            <span className="text-xl">🏎️</span>
          </div>
          <div className="text-left">
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold font-mono tracking-wider bg-gradient-to-r from-purple-400 via-orange-400 to-amber-300 bg-clip-text text-transparent">CARLAB</span>
              <span className="text-xs px-2 py-0.5 rounded bg-gradient-to-r from-purple-600 to-orange-500 font-bold uppercase tracking-widest text-[10px]">PRO</span>
            </div>
            <p className="text-[10px] text-slate-400 tracking-widest uppercase">Engine Simulator & Dyno Grid</p>
          </div>
        </div>

        {/* Builder View Tabs - Touch Scrollable on Mobile/Tablets */}
        <nav className="flex bg-slate-900 border border-purple-500/10 p-1 rounded-xl overflow-x-auto max-w-full whitespace-nowrap no-scrollbar shrink-0 scroll-smooth my-1 md:my-0">
          <button 
            onClick={() => setActiveTab('builder')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-semibold tracking-wider transition-all duration-200 flex items-center gap-1.5 sm:gap-2 shrink-0 ${
              activeTab === 'builder' ? 'bg-purple-600 text-white shadow shadow-purple-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers size={13} />
            <span>Builder</span>
          </button>
          <button 
            onClick={() => setActiveTab('tuning')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-semibold tracking-wider transition-all duration-200 flex items-center gap-1.5 sm:gap-2 shrink-0 ${
              activeTab === 'tuning' ? 'bg-purple-600 text-white shadow shadow-purple-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings size={13} />
            <span>Tuning</span>
          </button>
          <button 
            onClick={() => setActiveTab('mods')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-semibold tracking-wider transition-all duration-200 flex items-center gap-1.5 sm:gap-2 shrink-0 ${
              activeTab === 'mods' ? 'bg-purple-600 text-white shadow shadow-purple-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles size={13} />
            <span>Mods Sandbox</span>
          </button>
          <button 
            onClick={() => setActiveTab('test')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-semibold tracking-wider transition-all duration-200 flex items-center gap-1.5 sm:gap-2 shrink-0 ${
              activeTab === 'test' ? 'bg-purple-600 text-white shadow shadow-purple-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Play size={13} />
            <span>Test Drive</span>
          </button>
          <button 
            onClick={() => setActiveTab('ai')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-semibold tracking-wider transition-all duration-200 flex items-center gap-1.5 sm:gap-2 shrink-0 ${
              activeTab === 'ai' ? 'bg-purple-600 text-white shadow shadow-purple-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bot size={13} />
            <span>AI Advisor</span>
          </button>
          <button 
            onClick={() => setActiveTab('manual')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-[10px] sm:text-xs font-semibold tracking-wider transition-all duration-200 flex items-center gap-1.5 sm:gap-2 shrink-0 ${
              activeTab === 'manual' ? 'bg-purple-600 text-white shadow shadow-purple-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Wrench size={13} />
            <span>Swap Manual</span>
          </button>
        </nav>

        {/* Global Toolbar */}
        <div className="flex gap-2 shrink-0">
          <button 
            onClick={handleSaveBuild}
            className="p-2 sm:p-2.5 rounded-xl border border-purple-500/20 bg-purple-950/10 hover:bg-purple-950/30 text-purple-400 hover:text-purple-300 transition-all flex items-center gap-1.5 text-[10px] sm:text-xs font-medium"
            title="Save custom build"
          >
            <Save size={14} />
            <span className="hidden sm:inline">Save</span>
          </button>
          <button 
            onClick={handleShareBuildLink}
            className="p-2 sm:p-2.5 rounded-xl border border-orange-500/20 bg-orange-950/10 hover:bg-orange-950/30 text-orange-400 hover:text-orange-300 transition-all flex items-center gap-1.5 text-[10px] sm:text-xs font-medium"
            title="Generate share link"
          >
            <Share2 size={14} />
            <span className="hidden sm:inline">Share</span>
          </button>
          <button 
            onClick={() => setShowPrintCertificate(true)}
            className="p-2 sm:p-2.5 rounded-xl border border-cyan-500/20 bg-cyan-950/10 hover:bg-cyan-950/30 text-cyan-400 hover:text-cyan-300 transition-all flex items-center gap-1.5 text-[10px] sm:text-xs font-medium"
            title="Export build as PDF certificate"
          >
            <Printer size={14} />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </header>

      {/* Main Container Area */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 min-h-0 bg-slate-950">
        
        {/* ==========================================
            LEFT SIDEBAR: CATEGORY SELECTION IN BULK
            ========================================== */}
        <aside className={`lg:col-span-3 border-r border-purple-500/10 flex flex-col bg-slate-900/60 overflow-hidden ${activeTab === 'builder' ? 'h-[300px] lg:h-auto' : 'hidden lg:flex lg:h-auto'}`}>
          {/* Real-time search */}
          <div className="p-4 border-b border-purple-500/10 bg-slate-950/20">
            <span className="text-[10px] text-purple-400 font-bold uppercase tracking-wider block mb-2">FILTER COMPONENT STORES</span>
            <input 
              type="text" 
              placeholder="Search turbos, manifolds, ECUs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs py-2.5 px-3 rounded-lg bg-slate-950 border border-purple-500/15 focus:border-purple-500/50 outline-none text-slate-100 placeholder-slate-500 transition font-sans"
            />
          </div>

          {/* Catalog Selection Accordion */}
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {searchQuery ? (
              // Search view
              <div className="p-2">
                <span className="text-[10px] text-slate-400 font-mono block mb-2">{filteredCatalog.length} Matching components</span>
                {filteredCatalog.map(item => {
                  const isSelected = selectedEngine === item.id ||
                                     selectedTurbo === item.id ||
                                     selectedFuelInjector === item.id ||
                                     selectedFuelPump === item.id ||
                                     selectedFuelRail === item.id ||
                                     selectedECU === item.id ||
                                     selectedIgnitionCoils === item.id ||
                                     selectedInternals.includes(item.id) ||
                                     selectedCooling.includes(item.id) ||
                                     selectedExhaust.includes(item.id);

                  return (
                    <div 
                      key={item.id}
                      onClick={() => handleToggleComponent(item)}
                      className={`p-2.5 rounded-lg border text-left cursor-pointer transition mb-1.5 ${
                        isSelected 
                          ? 'bg-purple-950/40 border-purple-500/70 text-purple-200' 
                          : 'bg-slate-950/50 border-purple-500/5 hover:border-purple-500/20 text-slate-300'
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <span className="text-[9px] uppercase tracking-wider font-bold block mb-1" style={{ color: COMPONENT_COLORS[item.category as keyof typeof COMPONENT_COLORS] || '#fff' }}>
                          {item.category}
                        </span>
                        {item.powerBonus > 0 && (
                          <span className="text-[10px] font-mono font-bold text-emerald-400">+{item.powerBonus} HP</span>
                        )}
                      </div>
                      <h4 className="text-xs font-bold font-sans">{item.name}</h4>
                      <p className="text-[10px] text-slate-400 mt-1 line-clamp-1">{item.description}</p>
                    </div>
                  );
                })}
              </div>
            ) : (
              // Categories grouped accordion
              categories.map(cat => {
                const isExpanded = expandedSection === cat.title;
                const catComponents = COMPONENT_CATALOG.filter(c => c.category === cat.title);

                return (
                  <div key={cat.title} className="border border-purple-500/5 rounded-xl bg-slate-950/30 overflow-hidden mb-1.5">
                    <button 
                      onClick={() => setExpandedSection(isExpanded ? null : cat.title)}
                      className="w-full flex items-center justify-between p-3.5 text-xs font-bold text-slate-200 hover:bg-slate-900/50 transition duration-150"
                    >
                      <div className="flex items-center gap-2">
                        {cat.icon}
                        <span>{cat.title}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-slate-500 font-mono">{catComponents.length}</span>
                        {isExpanded ? <ChevronDown size={14} className="text-slate-500" /> : <ChevronRight size={14} className="text-slate-500" />}
                      </div>
                    </button>

                    {isExpanded && (
                      <div className="p-2 border-t border-purple-500/5 bg-slate-950/50 space-y-1.5">
                        {catComponents.map(item => {
                          const isSelected = selectedEngine === item.id ||
                                             selectedTurbo === item.id ||
                                             selectedFuelInjector === item.id ||
                                             selectedFuelPump === item.id ||
                                             selectedFuelRail === item.id ||
                                             selectedECU === item.id ||
                                             selectedIgnitionCoils === item.id ||
                                             selectedInternals.includes(item.id) ||
                                             selectedCooling.includes(item.id) ||
                                             selectedExhaust.includes(item.id);

                          return (
                            <div 
                              key={item.id}
                              onClick={() => handleToggleComponent(item)}
                              className={`p-2.5 rounded-lg border text-left cursor-pointer transition flex items-center justify-between ${
                                isSelected 
                                  ? 'bg-purple-950/40 border-purple-500/60 text-slate-100 shadow-sm shadow-purple-950' 
                                  : 'bg-slate-900/40 border-transparent hover:border-purple-500/10 text-slate-300 hover:text-white'
                              }`}
                            >
                              <div className="flex-1 pr-2 min-w-0">
                                <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                                  <span className="text-[9px] text-slate-500 font-mono">{item.brand}</span>
                                  {isSelected && <span className="text-[8px] bg-purple-900 text-purple-300 font-bold px-1 rounded uppercase tracking-wider">Installed</span>}
                                </div>
                                <h4 className="text-xs font-bold line-clamp-1">{item.name}</h4>
                                <span className="text-[9px] text-slate-400 line-clamp-1">{item.model}</span>
                              </div>
                              <div className="text-right flex flex-col justify-between items-end gap-1.5">
                                {item.powerBonus > 0 ? (
                                  <span className="text-[10px] font-mono font-bold text-emerald-400">+{item.powerBonus} HP</span>
                                ) : item.tempIncrease < 0 ? (
                                  <span className="text-[10px] font-mono font-bold text-cyan-400">{item.tempIncrease}°C Cooling</span>
                                ) : (
                                  <span className="text-[10px] text-slate-500 font-mono">Heavy Duty</span>
                                )}
                                <span className="text-[10px] text-amber-500 font-mono font-semibold">${item.cost.toLocaleString()}</span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Quick Stats Summary Footer inside sidebar */}
          <div className="p-4 border-t border-purple-500/10 bg-slate-950/80">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Total Build Budget:</span>
              <span className="font-bold text-amber-400 font-mono">
                ${(
                  engineItem.cost +
                  (turboItem?.cost || 0) +
                  (injectorItem?.cost || 0) +
                  (pumpItem?.cost || 0) +
                  (railItem?.cost || 0) +
                  (ecuItem?.cost || 0) +
                  (coilsItem?.cost || 0) +
                  internalsItems.reduce((acc, curr) => acc + curr.cost, 0) +
                  coolingItems.reduce((acc, curr) => acc + curr.cost, 0) +
                  exhaustItems.reduce((acc, curr) => acc + curr.cost, 0) +
                  subPartsCostAdd
                ).toLocaleString()}
              </span>
            </div>
          </div>
        </aside>

        {/* ==========================================
            CENTER AREA: INTERACTIVE SVG FLOW WORKSPACE
            ========================================== */}
        <section className="lg:col-span-6 flex flex-col bg-slate-950 min-w-0 relative">
          
          {/* Sub menu: Zoom & fit control view */}
          <div className="p-3 border-b border-purple-500/10 flex items-center justify-between bg-slate-900/30 gap-4">
            <div className="flex items-center gap-1 text-xs">
              <span className="text-slate-400">Tuning Active Tab:</span>
              <span className="px-2 py-0.5 rounded bg-purple-950 border border-purple-500/30 text-purple-300 font-mono font-semibold tracking-wider uppercase text-[10px]">
                {activeTab} Workspace
              </span>
            </div>

            {activeTab === 'builder' && (
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-slate-900 border border-purple-500/10 rounded-lg p-0.5">
                  <button onClick={() => setZoom(prev => Math.max(50, prev - 25))} className="p-1 px-2.5 text-slate-400 hover:text-slate-200 transition" title="Zoom out"><ZoomOut size={13}/></button>
                  <span className="text-[10px] font-mono px-2 text-slate-400">{zoom}%</span>
                  <button onClick={() => setZoom(prev => Math.min(200, prev + 25))} className="p-1 px-2.5 text-slate-400 hover:text-slate-200 transition" title="Zoom In"><ZoomIn size={13}/></button>
                </div>
                <button onClick={() => setZoom(100)} className="text-[10px] border border-purple-500/10 px-2.5 py-1.5 rounded-lg text-slate-400 hover:text-slate-300 hover:bg-slate-900 transition">Fit View</button>
              </div>
            )}

            <div>
              <button 
                onClick={triggerDynoSimulation}
                className="bg-gradient-to-r from-purple-600 to-orange-500 text-white font-bold py-1.5 px-4 rounded-lg flex items-center gap-1.5 text-xs tracking-wider uppercase hover:shadow-lg hover:shadow-purple-500/10 transition"
              >
                <Play size={12} /> Launch dyno runs
              </button>
            </div>
          </div>

          <div className="flex-1 relative overflow-auto p-4 flex flex-col justify-between">
            {/* ---------------------------------
                IF ACTIVE TAB IS BUILDER (SCHEMA VIEW)
                --------------------------------- */}
            {activeTab === 'builder' && (
              <>
                {/* 🚗 Tuning Bay Garage Banner */}
                <div className="mb-4 bg-slate-900/80 border border-purple-500/20 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-4 shadow-xl backdrop-blur-md">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-purple-950/50 border border-purple-500/30 rounded-xl text-purple-400">
                      <Car size={24} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2 py-0.5 rounded text-[9px] bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono font-semibold uppercase">{activeVehicle.difficulty}</span>
                        <h2 className="text-base font-bold text-slate-100 tracking-tight leading-tight">
                          {activeVehicle.year} {activeVehicle.brand} {activeVehicle.name}
                        </h2>
                      </div>
                      <p className="text-xs text-slate-400 mt-1 max-w-xl line-clamp-1">
                        {activeVehicle.description}
                      </p>
                      <div className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-slate-400 font-mono mt-1.5">
                        <span className="text-cyan-400 font-semibold">⚙️ Block: {activeVehicle.cylinders} Cylinders ({activeVehicle.displacement})</span>
                        <span className="text-slate-600">|</span>
                        <span>HP Baseline: <strong className="text-emerald-400">{activeVehicle.baseHP} HP</strong></span>
                        <span className="text-slate-600">|</span>
                        <span>Torque Baseline: <strong className="text-violet-400">{activeVehicle.baseTorque} NM</strong></span>
                        <span className="text-slate-600">|</span>
                        <span>Curb Weight: <strong>{activeVehicle.baseWeight} KG</strong></span>
                      </div>
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => setShowVehicleGarage(true)}
                    className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold py-2.5 px-4 rounded-xl text-xs tracking-wider uppercase shadow-lg shadow-purple-500/15 border border-purple-400/20 transition duration-150 transform hover:-translate-y-0.5 cursor-pointer"
                  >
                    <Wrench size={14} /> Swapping Node Garage
                  </button>
                </div>

                <div id="builder-canvas-view" className="flex-1 flex flex-col h-full bg-[#03040e] overflow-hidden select-none rounded-2xl border border-purple-500/10 min-h-[480px]">
                
                {/* Canvas Interaction Header Controls */}
                <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900 border-b border-purple-500/10 shrink-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-purple-400 bg-purple-950/40 px-2.5 py-1 rounded border border-purple-500/10">
                      Nodes: {canvasNodes.length}
                    </span>
                    <span className="text-xs font-mono text-cyan-400 bg-cyan-950/40 px-2.5 py-1 rounded border border-cyan-500/10">
                      Pipes: {connections.length}
                    </span>
                    <span className="text-[10px] text-slate-400 hidden md:inline">
                      Drag cards to reposition, click port nodes to connect pipeline flows!
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-1.5">
                    <button 
                      onClick={() => setZoom(prev => Math.max(50, prev - 10))}
                      className="p-1 px-2.5 rounded bg-slate-950 border border-slate-800 hover:border-purple-500 text-slate-300 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                      title="Zoom Out"
                    >
                      <ZoomOut size={12} /> <span className="text-[10px]">{zoom}%</span>
                    </button>
                    <button 
                      onClick={() => setZoom(prev => Math.min(150, prev + 10))}
                      className="p-1 px-2.5 rounded bg-slate-950 border border-slate-800 hover:border-purple-500 text-slate-300 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                      title="Zoom In"
                    >
                      <ZoomIn size={12} />
                    </button>
                    <button 
                      onClick={() => { setZoom(100); }}
                      className="p-1 px-2 text-xs text-slate-400 hover:text-white transition cursor-pointer"
                    >
                      Reset
                    </button>
                    <div className="h-4 w-px bg-slate-800" />
                    <button 
                      onClick={() => {
                        setCanvasNodes([
                          { id: 'node-engine', componentId: 'inline4-stock', x: 380, y: 150, category: 'Engine Block', brand: 'OEM Spec', name: '2.0L I4 Stock Block', model: 'Standard 2.0L' },
                          { id: 'node-turbo', componentId: 'gt2560-turbo', x: 40, y: 30, category: 'Forced Induction', brand: 'Garrett', name: 'Garrett GT2560 Turbocharger', model: 'GT2560R Ball-Bearing' },
                          { id: 'node-cooling', componentId: 'cooling-intercooler-stock', x: 200, y: 30, category: 'Cooling System', brand: 'OEM Spec', name: 'OEM Standard Intercooler', model: 'Factory Core V1' },
                          { id: 'node-fuel', componentId: 'injector-440', x: 40, y: 220, category: 'Fuel System', brand: 'Deatschwerks', name: 'High-Flow Fuel Injector Set (440cc)', model: 'DW 440cc Flow-Matched' },
                          { id: 'node-ecu', componentId: 'ecu-stock', x: 200, y: 410, category: 'Electronics', brand: 'OEM Spec', name: 'Factory OEM Restricted ECU', model: 'ECU-OEM Standard Version' },
                          { id: 'node-exhaust', componentId: 'exhaust-manifold-headers', x: 680, y: 180, category: 'Exhaust System', brand: 'Tomei Powered', name: 'Equal-Length Tubular Exhaust Headers', model: 'Expreme Equal-Length Headers' }
                        ]);
                        setConnections([
                          { id: 'conn-1', fromNode: 'node-turbo', fromPort: 'out', toNode: 'node-cooling', toPort: 'in' },
                          { id: 'conn-2', fromNode: 'node-cooling', fromPort: 'out', toNode: 'node-engine', toPort: 'air-in' },
                          { id: 'conn-3', fromNode: 'node-fuel', fromPort: 'out', toNode: 'node-engine', toPort: 'fuel-in' },
                          { id: 'conn-4', fromNode: 'node-ecu', fromPort: 'out', toNode: 'node-engine', toPort: 'ecu-in' },
                          { id: 'conn-5', fromNode: 'node-engine', fromPort: 'exhaust-out', toNode: 'node-exhaust', toPort: 'in' }
                        ]);
                        showToast("Restored default factory pipeline!", "info");
                      }}
                      className="p-1 px-2.5 rounded bg-slate-950 border border-purple-500/25 hover:bg-purple-900/10 text-purple-400 hover:text-purple-300 text-[11px] font-bold transition cursor-pointer"
                    >
                      Default Wires
                    </button>
                    <button 
                      onClick={() => {
                        setCanvasNodes(prev => prev.filter(n => n.id === 'node-engine'));
                        setConnections([]);
                        showToast("Cleared canvas workbench. Isolated standard block.", "info");
                      }}
                      className="p-1 px-2.5 rounded bg-slate-950 border border-red-500/25 hover:bg-red-900/10 text-red-400 hover:text-red-300 text-[11px] font-bold transition cursor-pointer"
                    >
                      Purge
                    </button>
                  </div>
                </div>

                {/* The Interactive Infinite Blueprint Grid Workspace */}
                <div 
                  ref={canvasRef}
                  className="flex-1 relative overflow-hidden bg-[#03040e] select-none cursor-grab active:cursor-grabbing h-full"
                  style={{
                    backgroundImage: 'radial-gradient(#1e1544 1.5px, transparent 1.5px), radial-gradient(#120c2e 1.5px, #040511 1.5px)',
                    backgroundSize: '28px 28px',
                    backgroundPosition: '0 0, 14px 14px',
                  }}
                  onMouseMove={handleCanvasMouseMove}
                  onMouseUp={handleCanvasMouseUp}
                  onMouseLeave={handleCanvasMouseUp}
                  onTouchMove={handleCanvasTouchMove}
                  onTouchEnd={handleCanvasMouseUp}
                  onTouchCancel={handleCanvasMouseUp}
                >
                  
                  {/* Stage Zoomable Sheet */}
                  <div 
                    className="absolute inset-0 w-full h-full origin-top-left transition-transform duration-75"
                    style={{ transform: `scale(${zoom / 100})` }}
                  >
                    
                    {/* SVG Pipeline Connection Layer */}
                    <svg className="absolute inset-0 w-full h-full pointer-events-none z-10 overflow-visible" xmlns="http://www.w3.org/2000/svg">
                      <defs>
                        <linearGradient id="glowingWire" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#c084fc" />
                          <stop offset="50%" stopColor="#818cf8" />
                          <stop offset="100%" stopColor="#38bdf8" />
                        </linearGradient>
                        
                        <linearGradient id="activeEnergyAir" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#10b981" />
                          <stop offset="100%" stopColor="#06b6d4" />
                        </linearGradient>
                        <linearGradient id="activeEnergyFuel" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#a855f7" />
                          <stop offset="100%" stopColor="#ec4899" />
                        </linearGradient>
                        <linearGradient id="activeEnergyECU" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#ef4444" />
                          <stop offset="100%" stopColor="#fb7185" />
                        </linearGradient>
                        <linearGradient id="activeEnergyExhaust" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#f97316" />
                          <stop offset="100%" stopColor="#ef4444" />
                        </linearGradient>
                        <linearGradient id="activeEnergyInternals" x1="0%" y1="0%" x2="100%" y2="0%">
                          <stop offset="0%" stopColor="#f472b6" />
                          <stop offset="100%" stopColor="#d946ef" />
                        </linearGradient>
                        
                        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                          <feGaussianBlur stdDeviation="3.5" result="blur" />
                          <feComposite in="SourceGraphic" in2="blur" operator="over" />
                        </filter>
                      </defs>

                      {/* Render wires */}
                      {connections.map(conn => {
                        const fromNode = canvasNodes.find(n => n.id === conn.fromNode);
                        const toNode = canvasNodes.find(n => n.id === conn.toNode);
                        if (!fromNode || !toNode) return null;

                        const fromCoords = getPortAbsoluteCoords(fromNode, conn.fromPort);
                        const toCoords = getPortAbsoluteCoords(toNode, conn.toPort);

                        const activeIds = getActiveConnectedIds();
                        const isWireActive = activeIds.includes(fromNode.id) && activeIds.includes(toNode.id);

                        let strokeColor = "url(#glowingWire)";
                        if (isWireActive) {
                          if (conn.toPort === 'air-in' || (conn.fromPort === 'out' && fromNode.category === 'Cooling System')) {
                            strokeColor = "url(#activeEnergyAir)";
                          } else if (conn.toPort === 'fuel-in') {
                            strokeColor = "url(#activeEnergyFuel)";
                          } else if (conn.toPort === 'ecu-in') {
                            strokeColor = "url(#activeEnergyECU)";
                          } else if (conn.fromPort === 'exhaust-out' || conn.toNode.includes('exhaust')) {
                            strokeColor = "url(#activeEnergyExhaust)";
                          } else if (conn.toPort === 'internals-in') {
                            strokeColor = "url(#activeEnergyInternals)";
                          }
                        } else {
                          strokeColor = "#334155";
                        }

                        const pathD = getBezierPath(fromCoords.x, fromCoords.y, toCoords.x, toCoords.y);

                        return (
                          <g key={conn.id} className="group/wire pointer-events-auto">
                            <path 
                              d={pathD} 
                              fill="none" 
                              stroke="transparent" 
                              strokeWidth="10" 
                              className="cursor-pointer"
                            />
                            <path 
                              d={pathD} 
                              fill="none" 
                              stroke={strokeColor} 
                              strokeWidth={isWireActive ? "3.5" : "1.8"} 
                              filter={isWireActive ? "url(#glow)" : ""}
                              className="transition-all duration-300"
                            />
                            {isWireActive && (
                              <path 
                                d={pathD} 
                                fill="none" 
                                stroke="#ffffff" 
                                strokeWidth="1" 
                                strokeDasharray="5 7"
                                className="animate-[dash_6s_linear_infinite]"
                              />
                            )}
                          </g>
                        );
                      })}

                      {/* Wiring drag preview lines */}
                      {activeWiring && (
                        <path 
                          d={getBezierPath(
                            getPortAbsoluteCoords(canvasNodes.find(n => n.id === activeWiring.nodeId)!, activeWiring.portId).x,
                            getPortAbsoluteCoords(canvasNodes.find(n => n.id === activeWiring.nodeId)!, activeWiring.portId).y,
                            mousePos.x,
                            mousePos.y
                          )}
                          fill="none"
                          stroke="#fbbf24"
                          strokeWidth="2.5"
                          strokeDasharray="5 5"
                        />
                      )}
                    </svg>

                    {/* HTML Layer */}
                    <div className="absolute inset-0 w-full h-full pointer-events-none z-20">
                      
                      {/* Midpoint deletion overlays */}
                      {connections.map(conn => {
                        const fromNode = canvasNodes.find(n => n.id === conn.fromNode);
                        const toNode = canvasNodes.find(n => n.id === conn.toNode);
                        if (!fromNode || !toNode) return null;

                        const fromCoords = getPortAbsoluteCoords(fromNode, conn.fromPort);
                        const toCoords = getPortAbsoluteCoords(toNode, conn.toPort);

                        const mx = (fromCoords.x + toCoords.x) / 2;
                        const my = (fromCoords.y + toCoords.y) / 2;

                        return (
                          <button
                            key={`btn-del-${conn.id}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              setConnections(prev => prev.filter(c => c.id !== conn.id));
                              showToast("Wire disconnected.", "info");
                            }}
                            className="absolute w-5 h-5 rounded-full bg-slate-950 border border-slate-700 hover:border-red-500 text-slate-400 hover:text-red-400 font-extrabold text-[9px] flex items-center justify-center shadow-lg transition-transform hover:scale-125 cursor-pointer pointer-events-auto"
                            style={{ left: `${mx - 10}px`, top: `${my - 10}px` }}
                            title="Disconnect line"
                          >
                            ✕
                          </button>
                        );
                      })}

                      {/* Render cards */}
                      {canvasNodes.map(node => {
                        const ports = getPortsForCategory(node.category);
                        const activeIds = getActiveConnectedIds();
                        const isConnected = activeIds.includes(node.id);
                        const isEngine = node.id === 'node-engine';

                        const cardWidth = isEngine ? 220 : 200;
                        const cardHeight = isEngine ? 150 : 130;
                        const themeColor = COMPONENT_COLORS[node.category as keyof typeof COMPONENT_COLORS] || '#a855f7';

                        return (
                          <div
                            key={node.id}
                            className={`absolute rounded-xl border-2 bg-slate-900/95 p-3 flex flex-col justify-between transition-shadow select-none shadow-2xl pointer-events-auto group/node ${
                              selectedCanvasNode === node.id 
                                ? 'shadow-purple-500/10' 
                                : 'hover:shadow-lg'
                            }`}
                            style={{
                              left: `${node.x}px`,
                              top: `${node.y}px`,
                              width: `${cardWidth}px`,
                              height: `${cardHeight}px`,
                              borderColor: selectedCanvasNode === node.id ? '#a855f7' : `${themeColor}40`,
                              cursor: draggedNodeId === node.id ? 'grabbing' : 'grab'
                            }}
                            onMouseDown={(e) => handleNodeMouseDown(node.id, e)}
                            onTouchStart={(e) => handleNodeTouchStart(node.id, e)}
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedCanvasNode(node.id);
                              const item = COMPONENT_CATALOG.find(c => c.id === node.componentId);
                              if (item) {
                                setInspectComponent(item);
                              }
                            }}
                          >
                            <div>
                              <div className="flex items-center justify-between gap-1 mb-0.5 pointer-events-none">
                                <span 
                                  className="text-[8px] uppercase tracking-wider font-extrabold px-1.5 py-0.5 rounded font-mono"
                                  style={{ backgroundColor: `${themeColor}20`, color: themeColor }}
                                >
                                  {node.category}
                                </span>
                                
                                <div className="flex items-center gap-1 font-mono text-[7px] font-bold">
                                  <span className={`w-1.5 h-1.5 rounded-full inline-block ${
                                    isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                                  }`} />
                                  <span className={isConnected ? 'text-emerald-400' : 'text-amber-400'}>
                                    {isConnected ? 'WIRED' : 'DISCONNECTED'}
                                  </span>
                                </div>
                              </div>
                              
                              <div className="text-xs font-bold text-slate-100 truncate mt-1.5 pointer-events-none">
                                {node.brand}
                              </div>
                              <div className="text-xs font-semibold text-slate-300 truncate pointer-events-none">
                                {node.name}
                              </div>
                              <div className="text-[9px] text-slate-500 truncate mt-0.5 font-mono pointer-events-none">
                                {node.model}
                              </div>
                            </div>

                            <div className="border-t border-slate-800/40 pt-1.5 flex justify-between items-center mt-1 pointer-events-none">
                              <div className="text-[9px] text-purple-300 font-extrabold uppercase tracking-wider">
                                {isEngine ? `${calculatedHP} HP Peak` : (
                                  COMPONENT_CATALOG.find(c => c.id === node.componentId)?.powerBonus 
                                    ? `+${COMPONENT_CATALOG.find(c => c.id === node.componentId)?.powerBonus} HP` 
                                    : 'Utility core'
                                )}
                              </div>
                              
                              {!isEngine && (
                                <button 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setCanvasNodes(prev => prev.filter(n => n.id !== node.id));
                                    setConnections(prev => prev.filter(c => c.fromNode !== node.id && c.toNode !== node.id));
                                    showToast(`Ejected component node from workspace.`, 'info');
                                  }}
                                  className="text-slate-500 hover:text-red-400 transition p-1 cursor-pointer pointer-events-auto"
                                  title="Delete node"
                                >
                                  <Trash size={11} />
                                </button>
                              )}
                            </div>

                            {/* Inputs ports (Left edge) */}
                            {ports.inputs.map((inPort, idx) => {
                              const spacing = cardHeight / (ports.inputs.length + 1);
                              const isPendingLink = activeWiring && activeWiring.nodeId !== node.id && !activeWiring.isInput;
                              const isThisPortWired = connections.some(c => c.toNode === node.id && c.toPort === inPort);

                              return (
                                <div
                                  key={`p-in-${inPort}`}
                                  onClick={(e) => handlePortClick(node.id, inPort, true, e)}
                                  className={`absolute -left-2 w-4 h-4 rounded-full border bg-slate-950 flex items-center justify-center hover:scale-125 cursor-crosshair transition-all z-30 group/port ${
                                    isPendingLink 
                                      ? 'border-yellow-400 animate-pulse' 
                                      : isThisPortWired 
                                        ? 'border-cyan-500' 
                                        : 'border-slate-700 hover:border-cyan-400'
                                  }`}
                                  style={{ top: `${spacing * (idx + 1) - 8}px` }}
                                >
                                  <span className={`w-1.5 h-1.5 rounded-full ${
                                    isPendingLink 
                                      ? 'bg-yellow-400' 
                                      : isThisPortWired 
                                        ? 'bg-cyan-400' 
                                        : 'bg-slate-700 group-hover/port:bg-cyan-400'
                                  }`} />
                                  <span className="opacity-0 group-hover/port:opacity-100 absolute left-6 py-0.5 px-1.5 rounded bg-slate-900 border border-slate-700 text-[8px] font-mono text-slate-300 uppercase pointer-events-none whitespace-nowrap tracking-wider">
                                    Plug: {inPort.replace('-in', '')}
                                  </span>
                                </div>
                              );
                            })}

                            {/* Outputs ports (Right edge) */}
                            {ports.outputs.map((outPort, idx) => {
                              const spacing = cardHeight / (ports.outputs.length + 1);
                              const isPendingLink = activeWiring && activeWiring.nodeId !== node.id && activeWiring.isInput;
                              const isThisPortWired = connections.some(c => c.fromNode === node.id && c.fromPort === outPort);

                              return (
                                <div
                                  key={`p-out-${outPort}`}
                                  onClick={(e) => handlePortClick(node.id, outPort, false, e)}
                                  className={`absolute -right-2 w-4 h-4 rounded-full border bg-slate-950 flex items-center justify-center hover:scale-125 cursor-crosshair transition-all z-30 group/port ${
                                    isPendingLink 
                                      ? 'border-yellow-400 animate-pulse' 
                                      : isThisPortWired 
                                        ? 'border-orange-500' 
                                        : 'border-slate-700 hover:border-orange-400'
                                  }`}
                                  style={{ top: `${spacing * (idx + 1) - 8}px` }}
                                >
                                  <span className={`w-1.5 h-1.5 rounded-full ${
                                    isPendingLink 
                                      ? 'bg-yellow-400' 
                                      : isThisPortWired 
                                        ? 'bg-orange-400' 
                                        : 'bg-slate-700 group-hover/port:bg-orange-400'
                                  }`} />
                                  <span className="opacity-0 group-hover/port:opacity-100 absolute right-6 py-0.5 px-1.5 rounded bg-slate-900 border border-slate-700 text-[8px] font-mono text-slate-300 uppercase pointer-events-none whitespace-nowrap tracking-wider">
                                    Output Flow
                                  </span>
                                </div>
                              );
                            })}

                          </div>
                        );
                      })}

                    </div>

                  </div>

                  {/* Absolute watermark inside grid */}
                  <div className="absolute bottom-4 right-4 pointer-events-none flex flex-col items-end opacity-20 select-none">
                    <span className="text-[10px] font-mono tracking-widest text-[#a855f7]">CARLAB PRO GRID CONTROLLER v2</span>
                    <span className="text-[8px] font-mono text-slate-500 uppercase mt-0.5">Real-Time Power & Connection Mapping</span>
                  </div>

                </div>

              </div>

              {/* ⚙️ IMMERSIVE ACTIVE NODE INTERNALS STATION */}
              <div className="mt-5 bg-gradient-to-b from-slate-900 to-slate-950 border border-purple-500/15 rounded-2xl p-5 shadow-2xl relative shrink-0">
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-500 rounded-t-2xl"></div>
                
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-purple-500/10 pb-4 mb-4">
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-100 tracking-wider flex items-center gap-2 font-sans uppercase">
                      <Wrench className="text-purple-400 animate-pulse" size={16} /> 
                      {selectedCanvasNode ? `INTERNAL DIAGNOSTIC WORKBENCH: ${
                        canvasNodes.find(n => n.id === selectedCanvasNode)?.name
                      }` : "INTERNAL REASSEMBLY DIAGNOSTICS"}
                    </h3>
                    <p className="text-[11.5px] text-zinc-400 mt-1">
                      {selectedCanvasNode 
                        ? "Configure custom core compounds, wiring harnesses, and high-fidelity internal tolerances." 
                        : "Click any node on the graphical pipeline layout above to disassemble and customize its sub-elements in real-time."
                      }
                    </p>
                  </div>
                  {selectedCanvasNode && (
                    <span className="px-3 py-1 text-[10px] font-mono rounded bg-purple-950/50 text-purple-300 border border-purple-500/25">
                      ACTIVE: {canvasNodes.find(n => n.id === selectedCanvasNode)?.category}
                    </span>
                  )}
                </div>

                {!selectedCanvasNode ? (
                  <div className="flex flex-col items-center justify-center py-10 px-4 text-center border border-dashed border-slate-800 rounded-xl bg-slate-950/40">
                    <div className="p-3.5 bg-slate-900 rounded-full text-zinc-500 mb-3 animate-bounce">
                      <MousePointerClick size={22} />
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed max-w-lg">
                      No active pipeline node selected. Click on <strong className="text-purple-400">Engine Block, forced induction, electronics, cooling, or fuel nodes</strong> above to recalibrate internal pistons, spark plugs, flow meters, or mil-spec wiring.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    {(() => {
                      let activeSubGroup: { key: string; label: string; options: { val: string; title: string; stats: string }[] }[] = [];

                      if (selectedCanvasNode === 'node-engine') {
                        activeSubGroup = [
                          { key: 'pistons', label: 'Engine Pistons Core', options: [
                            { val: 'stock', title: 'Stock Cast OEM', stats: 'Standard factory' },
                            { val: 'je-forged', title: 'JE Forged 2618', stats: '+15 HP, +8% Boost resilience, Cost $850' },
                            { val: 'wiseco-forged', title: 'Wiseco Forged', stats: '+28 HP, +16% Boost resilience, Cost $1,400' }
                          ]},
                          { key: 'pistonSize', label: 'Piston Bore Size', options: [
                            { val: 'stock', title: 'Stock 85.0mm', stats: 'Standard displacement' },
                            { val: 'overbore-0.5', title: 'Overbore +0.5mm', stats: '+8 HP, +12 NM, Cost $300' },
                            { val: 'overbore-1.0', title: 'Race Overbore +1.0mm', stats: '+16 HP, +24 NM, Cost $600' }
                          ]},
                          { key: 'crankshaft', label: 'Crankshaft Shaft Core', options: [
                            { val: 'stock', title: 'Stock Cast', stats: '7,000 RPM base limit' },
                            { val: 'eagle-forged', title: 'Eagle Forged 4340', stats: '+400 RPM Redline, +15 NM, Cost $950' },
                            { val: 'carrillo-billet', title: 'Carrillo Lightweight', stats: '+900 RPM Redline, +25 HP, Cost $2,200' }
                          ]},
                          { key: 'rods', label: 'Connecting Rods', options: [
                            { val: 'stock', title: 'Stock I-Beam', stats: 'Factory default' },
                            { val: 'manley-hbeam', title: 'Manley H-Beam', stats: '+11% Overpressure, +5 HP, Cost $650' },
                            { val: 'crower-titanium', title: 'Crower Custom Ti', stats: '-10kg Weight, +12 HP, Cost $1,800' }
                          ]},
                          { key: 'camshaft', label: 'Camshaft Cam Profile', options: [
                            { val: 'stock', title: 'Stock OEM Lift', stats: 'Civilian curve' },
                            { val: 'street-stage1', title: 'Street Stage I (264°)', stats: '+14 HP, +10 NM, Cost $550' },
                            { val: 'race-stage2', title: 'Race Stage II (272°)', stats: '+32 HP, High speed, Cost $1,100' }
                          ]},
                          { key: 'sparkPlugs', label: 'Spark Plugs Ionization', options: [
                            { val: 'stock', title: 'OEM Copper', stats: 'Stock spark range' },
                            { val: 'ngk-iridium', title: 'NGK Iridium Cold', stats: 'Blowout spark protection, Cost $120' }
                          ]}
                        ];
                      } else if (selectedCanvasNode === 'node-turbo') {
                        activeSubGroup = [
                          { key: 'wastegate', label: 'Wastegate Actuation', options: [
                            { val: 'internal', title: 'OEM Internal Actuator', stats: 'Basic boost regulation' },
                            { val: 'tial-external', title: 'TiAL 44mm External', stats: 'Eliminates boost creep, Cost $480' }
                          ]},
                          { key: 'boostValve', label: 'Boost Bypass Valve', options: [
                            { val: 'manual', title: 'Standard Manual Valve', stats: 'Basic bleed lines' },
                            { val: 'greddy-bov', title: 'Greddy Blow-Off Valve', stats: 'Protects compressor blades, Cost $350' }
                          ]}
                        ];
                      } else if (selectedCanvasNode === 'node-cooling') {
                        activeSubGroup = [
                          { key: 'intercooler', label: 'Intercooler Volume', options: [
                            { val: 'stock', title: 'OEM Standard Core', stats: 'Normal temperature drop' },
                            { val: 'mishimoto-elite', title: 'Mishimoto J-Line', stats: '-15°C Intake drop, +8 HP, Cost $750' }
                          ]},
                          { key: 'radiator', label: 'Radiator Cooling Surface', options: [
                            { val: 'stock', title: 'OEM Aluminum Radiator', stats: 'Standard thermal threshold' },
                            { val: 'mishimoto-triple', title: 'Mishimoto 3-Row Alloy', stats: '-22°C Coolant drops, Cost $420' }
                          ]},
                          { key: 'thermostat', label: 'Thermostat Valve', options: [
                            { val: 'stock', title: 'Factory 92°C Thermo', stats: 'Stock range transition' },
                            { val: 'lowtemp-78', title: 'Low-Temp 78°C Sports', stats: 'Opens thermostatic ring early, Cost $120' }
                          ]}
                        ];
                      } else if (selectedCanvasNode === 'node-fuel') {
                        activeSubGroup = [
                          { key: 'injectorSize', label: 'Fuel Injector Flow Rate', options: [
                            { val: 'stock', title: 'OEM 220cc Flow Rate', stats: 'Lean risk above 1.2 Bar boost' },
                            { val: 'bosch-440', title: 'Bosch 440cc Flow Set', stats: '+10 HP, supports 1.7 Bar, Cost $380' },
                            { val: 'id-850', title: 'ID 850cc Ultra Flow', stats: '+25 HP, heavy boost support, Cost $780' }
                          ]},
                          { key: 'fuelRail', label: 'Fuel Rail Delivery', options: [
                            { val: 'stock', title: 'OEM Restrictive Rail', stats: 'Standard feed pressure' },
                            { val: 'radium-dual', title: 'Radium High-Volume Dual', stats: '+5 HP, damping technology, Cost $320' }
                          ]},
                          { key: 'fuelLine', label: 'Fuel Lines Shielding', options: [
                            { val: 'stock', title: 'OEM Rubber Hoses', stats: 'Standard fuels only' },
                            { val: 'ptfe-stainless', title: 'PTFE Braided Stainless', stats: 'PTFE lining (Ethanol/E85 safe), Cost $240' }
                          ]},
                          { key: 'fuelPump', label: 'Fuel Pump Flow Capacity', options: [
                            { val: 'stock', title: 'OEM 120 LPH Pump', stats: 'Risk of starving under high duty' },
                            { val: 'walbro-255', title: 'Walbro 255 LPH Flow', stats: '+8 HP, sports feed, Cost $180' }
                          ]}
                        ];
                      } else if (selectedCanvasNode === 'node-ecu') {
                        activeSubGroup = [
                          { key: 'ecuVariant', label: 'Computer Map Variant', options: [
                            { val: 'stock', title: 'Stock OEM sealed', stats: 'Standard parameters' },
                            { val: 'haltech-elite', title: 'Haltech Elite 2500', stats: '+20 HP, real-time closed loop, Cost $1,850' },
                            { val: 'motec-m150', title: 'MoTeC M150 System', stats: '+35 HP, formula-1 logic engine, Cost $3,200' }
                          ]},
                          { key: 'wiringHarness', label: 'Wiring Harness Loom', options: [
                            { val: 'stock', title: 'Standard Factory Loom', stats: 'Fragile electrical lines' },
                            { val: 'milspec-tefzel', title: 'Mil-Spec Tefzel Loom', stats: 'Flame retardant custom loom, Cost $950' }
                          ]},
                          { key: 'ignitionCoils', label: 'Ignition Coils Output', options: [
                            { val: 'stock', title: 'Factory Default Coils', stats: 'Stock spark intensity' },
                            { val: 'okada-plasma', title: 'Okada Plasma Direct', stats: '+8 HP, +4% reliability, Cost $1,100' }
                          ]}
                        ];
                      } else if (selectedCanvasNode === 'node-exhaust') {
                        activeSubGroup = [
                          { key: 'manifoldType', label: 'Manifold Layout Type', options: [
                            { val: 'stock', title: 'Factory Cast Iron', stats: 'Highly restrictive' },
                            { val: 'headersv2', title: 'Tubular Stainless Headers', stats: '+18 HP, race high flow, Cost $820' }
                          ]},
                          { key: 'catbackDiameter', label: 'Catback Piping Diameter', options: [
                            { val: 'stock', title: 'Factory 2.0-inch Pipe', stats: 'Backpressure dampening' },
                            { val: 'stage3-pipe', title: 'Race 3.0-inch Titanium', stats: '+15 HP, -12kg light weight, Cost $1,400' }
                          ]},
                          { key: 'exhaustValve', label: 'Exhaust Valvetronic Cutout', options: [
                            { val: 'stock', title: 'Standard Flow Path', stats: 'Traditional dual mufflers' },
                            { val: 'valvetronic', title: 'Active Valvetronic Valve', stats: '+6 HP, bypass switch, Cost $680' }
                          ]}
                        ];
                      }

                      if (activeSubGroup.length === 0) {
                        return (
                          <div className="col-span-full py-8 text-center text-xs text-slate-500">
                            Selected node does not require advanced micro-sub-part reassembly. Customizing its primary layout in the sidebar covers its total specs.
                          </div>
                        );
                      }

                      return activeSubGroup.map((group) => {
                        const currentVal = subParts[group.key] || 'stock';
                        return (
                          <div key={group.key} className="bg-slate-950 p-4 rounded-xl border border-purple-500/10 hover:border-purple-500/20 transition flex flex-col justify-between">
                            <div>
                              <h4 className="text-xs font-bold text-slate-200 tracking-wide font-mono mb-2 flex items-center justify-between">
                                <span>{group.label}</span>
                                <span className="text-[10px] text-purple-400 capitalize bg-purple-950/20 px-2.5 py-0.5 rounded border border-purple-500/10 font-bold font-mono text-right">
                                  {currentVal}
                                </span>
                              </h4>
                              <div className="flex flex-col gap-2 mt-3">
                                {group.options.map((opt) => {
                                  const isSelected = currentVal === opt.val;
                                  return (
                                    <button
                                      key={opt.val}
                                      onClick={() => {
                                        setSubParts(prev => ({ ...prev, [group.key]: opt.val }));
                                        showToast(`Recalibrated ${group.label} internally to "${opt.title}"`, 'success');
                                      }}
                                      className={`w-full text-left p-2.5 rounded-lg border text-xs transition duration-150 relative overflow-hidden flex flex-col justify-center cursor-pointer ${
                                        isSelected 
                                          ? 'bg-purple-950/30 border-purple-500 text-purple-200 shadow-lg shadow-purple-500/10' 
                                          : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:bg-slate-900/90'
                                      }`}
                                    >
                                      <div className="flex items-center justify-between font-semibold">
                                        <span>{opt.title}</span>
                                        {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-ping absolute right-3 top-3" />}
                                      </div>
                                      <div className="text-[10px] text-zinc-400 mt-1 leading-normal font-sans">
                                        {opt.stats}
                                      </div>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        );
                      });
                    })()}
                  </div>
                )}
              </div>
            </>
          )}

            {/* ---------------------------------
                IF ACTIVE TAB IS TUNING (SLIDERS CHANNELS)
                --------------------------------- */}
            {activeTab === 'tuning' && (
              <div className="flex-1 flex flex-col gap-6 p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Performance Mapping Oscilloscope */}
                  <div className="bg-slate-900 border border-purple-500/10 p-4 rounded-2xl">
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="text-xs font-bold text-slate-300 font-mono tracking-wider flex items-center gap-1.5">
                        <Activity size={14} className="text-cyan-400 animate-pulse" /> Oscilloscope: Compression Waveform
                      </h4>
                      <span className="text-[9px] bg-slate-950 text-cyan-400 font-mono px-2 py-0.5 rounded border border-cyan-500/15 animate-pulse">LIVE TRACKING</span>
                    </div>

                    <div className="h-44 bg-slate-950 rounded-xl flex items-center justify-center p-2 relative overflow-hidden">
                      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#1f2937_1px,transparent_1px),linear-gradient(to_bottom,#1f2937_1px,transparent_1px)] bg-[size:10px_10px]" />
                      
                      {/* Interactive timing curvature */}
                      <svg className="w-full h-full relative" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 100">
                        <path 
                          d={`M 10 70 Q 50 ${40 - (ignitionTimingOffset * 2.2)} 100 ${50 + (fuelMapOffset * 0.8)} T 190 ${50 + (selectedTurbo ? boostLimit * 8 : 0)}`}
                          fill="none" 
                          stroke="#06b6d4" 
                          strokeWidth="2.5" 
                        />
                        <path 
                          d="M 10 70 Q 50 60 100 50 T 190 50" 
                          fill="none" 
                          stroke="#ef4444" 
                          strokeWidth="1" 
                          strokeDasharray="4 4" 
                        />
                        {/* Glowing node pointer */}
                        <circle cx="100" cy={50 + (fuelMapOffset * 0.8)} r="4" fill="#8a2be2" className="animate-ping" />
                      </svg>
                    </div>
                  </div>

                  {/* Engine Danger Level Diagnostics */}
                  <div className="bg-slate-900 border border-purple-500/10 p-4 rounded-2xl flex flex-col justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-slate-300 font-mono tracking-wider mb-3">ECU LIVE AUDIT STATUS</h4>
                      <div className="space-y-2.5 text-xs">
                        <div className="flex justify-between items-center bg-slate-950 p-2 rounded-lg">
                          <span className="text-slate-400">Combustion knock rating:</span>
                          <span className={`font-mono font-bold ${ignitionTimingOffset > 8 ? 'text-rose-400' : 'text-emerald-400'}`}>
                            {ignitionTimingOffset > 8 ? 'DANGEROUS DETONATION KNOCK' : 'STABLE SPARK CYCLE'}
                          </span>
                        </div>
                        <div className="flex justify-between items-center bg-slate-950 p-2 rounded-lg">
                          <span className="text-slate-400">Fuel mixture offset:</span>
                          <span className={`font-mono font-bold ${fuelMapOffset < -5 ? 'text-rose-400' : fuelMapOffset > 10 ? 'text-amber-400' : 'text-emerald-400'}`}>
                            {fuelMapOffset < -5 ? 'LEAN MELTING HAZARD' : fuelMapOffset > 10 ? 'RICH CYLINDER WASH' : 'OPTIMUM PRO STOICHIOMETRIC'}
                          </span>
                        </div>
                        <div className="flex justify-between items-center bg-slate-950 p-2 rounded-lg">
                          <span className="text-slate-400">Block Boost Threshold:</span>
                          <span className="font-mono font-bold text-slate-200">
                            {selectedTurbo ? `${boostLimit.toFixed(2)} Bar Pressure` : 'Atmospheric Intake'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-purple-500/5">
                      <button 
                        onClick={() => {
                          setBoostLimit(1.0);
                          setFuelMapOffset(0);
                          setIgnitionTimingOffset(0);
                          showToast("ECU factory maps loaded", "info");
                        }}
                        className="w-full py-2 bg-slate-950 hover:bg-slate-900 border border-purple-500/10 hover:border-purple-500/30 text-slate-400 hover:text-slate-200 transition text-[11px] font-bold rounded-lg tracking-wider"
                      >
                        RESET ECU TO SAFE FACTORY PRESET
                      </button>
                    </div>
                  </div>

                </div>

                {/* Live Sliders Channels Map */}
                <div className="bg-slate-900 border border-purple-500/10 p-5 rounded-2xl space-y-6">
                  <div className="border-b border-purple-500/10 pb-2">
                    <h3 className="text-xs font-bold text-purple-400 tracking-wider font-mono">MAP CHANNELS INTERFACE</h3>
                    <p className="text-[10px] text-slate-500">Live modify powertrain behavior in code memory cells.</p>
                  </div>

                  {/* Channel A: Boost Limit (Disabled if NA) */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <label className="font-bold flex items-center gap-1">
                        <Gauge size={13} className="text-emerald-400" />
                        <span>Channel A: Comp Forced Boost (Turbo/Supercharger)</span>
                      </label>
                      <span className={`font-mono font-bold ${!selectedTurbo ? 'text-slate-600' : 'text-emerald-400'}`}>
                        {selectedTurbo ? `${boostLimit.toFixed(1)} Bar` : 'DISABLED - Requires turbocharger'}
                      </span>
                    </div>
                    <input 
                      type="range" 
                      min="0.4"
                      max="3.5"
                      step="0.1"
                      value={boostLimit}
                      onChange={(e) => setBoostLimit(parseFloat(e.target.value))}
                      disabled={!selectedTurbo}
                      className="w-full accent-emerald-500 disabled:opacity-20 cursor-pointer h-1.5 bg-slate-950 rounded-lg appearance-none"
                    />
                    <p className="text-[9px] text-slate-500">Increases turbine power output. Warning: Over 1.5 Bar boost limits on OEM pistons yields catastrophic cracking. Upgrades rods & internals.</p>
                  </div>

                  {/* Channel B: Fuel Ratio offset */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <label className="font-bold flex items-center gap-1">
                        <Fuel size={13} className="text-violet-400" />
                        <span>Channel B: Air-Fuel Ratio (AFR) Offset</span>
                      </label>
                      <span className={`font-mono font-bold ${fuelMapOffset < 0 ? 'text-rose-400' : fuelMapOffset > 0 ? 'text-amber-400' : 'text-slate-200'}`}>
                        {fuelMapOffset}% {fuelMapOffset < 0 ? '(LEAN / Power bias)' : fuelMapOffset > 0 ? '(RICH / Thermal cooling bias)' : '(STRICT STOICHIOMETRIC)'}
                      </span>
                    </div>
                    <input 
                      type="range" 
                      min="-20"
                      max="30"
                      step="1"
                      value={fuelMapOffset}
                      onChange={(e) => setFuelMapOffset(parseInt(e.target.value))}
                      className="w-full accent-purple-500 cursor-pointer h-1.5 bg-slate-950 rounded-lg appearance-none"
                    />
                    <p className="text-[9px] text-slate-500">Adjust the stoichiometry. Lean fueling gives minor HP boosts but risks high-RPM combustion melting. Rich fueling cools are-fuel mixtures.</p>
                  </div>

                  {/* Channel C: Ignition Timing */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <label className="font-bold flex items-center gap-1">
                        <Cpu size={13} className="text-red-400" />
                        <span>Channel C: Spark Ignition Timing Advance</span>
                      </label>
                      <span className={`font-mono font-bold ${ignitionTimingOffset > 0 ? 'text-orange-400 animate-pulse' : ignitionTimingOffset < 0 ? 'text-cyan-400' : 'text-slate-200'}`}>
                        {ignitionTimingOffset > 0 ? `+${ignitionTimingOffset}° Advanced` : `${ignitionTimingOffset}° Retarded`}
                      </span>
                    </div>
                    <input 
                      type="range" 
                      min="-10"
                      max="15"
                      step="1"
                      value={ignitionTimingOffset}
                      onChange={(e) => setIgnitionTimingOffset(parseInt(e.target.value))}
                      className="w-full accent-red-500 cursor-pointer h-1.5 bg-slate-950 rounded-lg appearance-none"
                    />
                    <p className="text-[9px] text-slate-500">Advance spark timing for major HP peaks. Excessive timing causes intensive knock pressures which cracks block crowns instant.</p>
                  </div>

                </div>
              </div>
            )}

            {/* ---------------------------------
                IF ACTIVE TAB IS TEST DRIVE (DYNO SIMULATOR)
                --------------------------------- */}
            {activeTab === 'test' && (
              <div className="flex-1 flex flex-col justify-between p-4 gap-6">
                
                {/* Mode Selector Tab segmented bar */}
                <div className="flex bg-slate-950 p-1 rounded-xl border border-purple-500/10 self-start z-10">
                  <button
                    onClick={() => {
                      setDynoRunning(false);
                      setManualRevActive(false);
                      audioEngineRef.current?.stop();
                      audioEngineRef.current = null;
                      setTestMode('auto');
                    }}
                    className={`px-4 py-2 rounded-lg text-xs font-bold font-mono transition duration-150 flex items-center gap-1.5 cursor-pointer ${
                      testMode === 'auto'
                        ? 'bg-purple-600 text-white shadow shadow-purple-950'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    🏆 Drag Strip Dyno Run
                  </button>
                  <button
                    onClick={() => {
                      setDynoRunning(false);
                      setManualRevActive(false);
                      audioEngineRef.current?.stop();
                      audioEngineRef.current = null;
                      setTestMode('manual');
                    }}
                    className={`px-4 py-2 rounded-lg text-xs font-bold font-mono transition duration-150 flex items-center gap-1.5 cursor-pointer ${
                      testMode === 'manual'
                        ? 'bg-purple-600 text-white shadow shadow-purple-950'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    📻 SoundsMap Interactive Rev-Rig
                  </button>
                </div>

                {/* ---------------------------------
                    AUTOMATIC DRAG DYNO MODE 
                    --------------------------------- */}
                {testMode === 'auto' && (
                  <div className="flex flex-col gap-6 w-full flex-1">
                    {/* Dyno runner visuals */}
                    <div className="relative bg-slate-900 border border-purple-500/10 p-6 rounded-2xl flex-1 flex flex-col justify-between overflow-hidden min-h-[350px]">
                      
                      {/* Grid overlay */}
                      <div className="absolute inset-0 opacity-5 bg-[radial-gradient(#8a2be2_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />

                      <div className="flex justify-between items-start relative z-10">
                        <div>
                          <h3 className="text-sm font-bold font-mono text-purple-400 tracking-widest uppercase">VIRTUAL DYNO ROLLER GRID</h3>
                          <p className="text-[10px] text-slate-500 uppercase tracking-wider">Physics-engine simulation based on current airflow maps</p>
                        </div>
                        {dynoRunning ? (
                          <span className="px-3 py-1 rounded bg-rose-950 text-rose-400 border border-rose-500/20 text-xs font-bold font-mono animate-pulse">
                            DYNO FULL LAUNCH: GEAR {dynoGear}
                          </span>
                        ) : (
                          <span className="px-3 py-1 rounded bg-slate-950 text-slate-400 border border-slate-800 text-xs font-bold font-mono">
                            STANDBY
                          </span>
                        )}
                      </div>

                      {/* Live Dials visualization during run */}
                      <div className="my-auto grid grid-cols-3 gap-2 sm:gap-4 text-center py-4 sm:py-6 relative z-10 w-full">
                        <div className="bg-slate-950 p-2 sm:p-4 rounded-xl border border-cyan-500/10 flex flex-col justify-between">
                          <span className="text-[8px] sm:text-[9px] font-mono text-slate-500 uppercase tracking-widest block mb-1">ENGINE SPEED</span>
                          <p className="text-base sm:text-2xl font-bold font-mono text-cyan-400 animate-pulse">{dynoRunning ? dynoRPM.toLocaleString() : '0'} <span className="text-[8px] sm:text-xs font-normal">RPM</span></p>
                          <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden mt-1.5 sm:mt-2">
                            <div className="bg-cyan-400 h-full transition-all duration-100" style={{ width: `${(dynoRPM / updatedRedline) * 100}%` }} />
                          </div>
                        </div>

                        <div className="bg-slate-900 p-2 sm:p-4 rounded-xl border border-purple-500/20 shadow-2xl relative flex flex-col justify-between">
                          <span className="text-[8px] sm:text-[9px] font-mono text-slate-400 uppercase tracking-widest block mb-1">LIVE HP</span>
                          <p className="text-lg sm:text-3xl font-extrabold font-mono text-purple-300 animate-pulse">{dynoRunning ? dynoHP : '0'}</p>
                          <div className="inline-block mt-1 sm:mt-2 px-1 sm:px-2 py-0.5 rounded bg-purple-950 border border-purple-500/20 text-[7px] sm:text-[9px] font-bold font-mono text-purple-400 self-center">
                            SHIFT LIGHT
                          </div>
                        </div>

                        <div className="bg-slate-950 p-2 sm:p-4 rounded-xl border border-orange-500/10 flex flex-col justify-between">
                          <span className="text-[8px] sm:text-[9px] font-mono text-slate-500 uppercase tracking-widest block mb-1">VELOCITY</span>
                          <p className="text-base sm:text-2xl font-bold font-mono text-orange-400 animate-pulse">{dynoRunning ? dynoSpeed : '0'} <span className="text-[8px] sm:text-xs text-slate-500 font-normal">KM/H</span></p>
                          <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden mt-1.5 sm:mt-2">
                            <div className="bg-orange-400 h-full transition-all duration-100" style={{ width: `${(dynoSpeed / calculatedTopSpeed) * 100}%` }} />
                          </div>
                        </div>
                      </div>

                      {/* Dyno Launch Controls */}
                      <div className="flex flex-col items-center justify-center p-4 relative z-10">
                        {dynoCountdown !== null ? (
                          <div className="text-center">
                            <p className="text-[10px] font-mono tracking-widest text-slate-400 mb-1">REVING OIL PUMPS...</p>
                            <span className="text-5xl font-mono text-orange-500 font-black animate-ping block">{dynoCountdown}</span>
                          </div>
                        ) : !dynoRunning ? (
                          <div className="text-center space-y-4">
                            <button 
                              onClick={triggerDynoSimulation}
                              className="px-8 py-3.5 bg-gradient-to-r from-purple-600 via-orange-500 to-amber-500 text-white font-extrabold text-sm tracking-wider rounded-xl uppercase hover:scale-105 active:scale-95 shadow-xl shadow-purple-500/10 hover:shadow-purple-500/20 transition duration-150 cursor-pointer"
                            >
                              LAUNCH FULL PRESSURE DYNO DRIVE RUN
                            </button>
                            <p className="text-[10px] text-slate-400">CarLab PRO physics analyzer locks wheels, spools turbo charges and cycles redlines.</p>
                            
                            {/* Audio Controls */}
                            <div className="flex items-center justify-center pt-2">
                              <button
                                onClick={() => {
                                  const nextMute = !isAudioMuted;
                                  setIsAudioMuted(nextMute);
                                  audioEngineRef.current?.setMuted(nextMute);
                                  showToast(nextMute ? "Exhaust audio muted 🔇" : "Exhaust acoustics online! 🔊", "info");
                                }}
                                className={`flex items-center gap-1.5 px-4 py-2 rounded-lg border text-xs font-mono font-bold transition duration-150 cursor-pointer ${
                                  isAudioMuted
                                    ? 'bg-rose-950/20 border-rose-900/30 text-rose-400 hover:bg-rose-950/40'
                                    : 'bg-cyan-950/20 border-cyan-900/30 text-cyan-400 hover:bg-cyan-950/40'
                                }`}
                              >
                                <span>{isAudioMuted ? '🔇 Exhaust Acoustics: Muted' : '🔊 Exhaust Acoustics: Online'}</span>
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="text-center w-full max-w-sm space-y-4">
                            <div className="flex items-center justify-center gap-1 font-mono text-slate-500 animate-pulse text-xs">
                              <span className="w-2 h-2 rounded bg-rose-500 animate-ping mr-1" />
                              <span>PULLING ACCELERATION STRIP TIMINGS...</span>
                            </div>
                            
                            {/* Audio Controls during active run */}
                            <div className="flex items-center justify-center">
                              <button
                                onClick={() => {
                                  const nextMute = !isAudioMuted;
                                  setIsAudioMuted(nextMute);
                                  audioEngineRef.current?.setMuted(nextMute);
                                  showToast(nextMute ? "Acousics Muted" : "Acoustics Restored", "info");
                                }}
                                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-[11px] font-mono font-bold transition duration-150 cursor-pointer ${
                                  isAudioMuted
                                    ? 'bg-rose-950/25 border-rose-900/40 text-rose-400'
                                    : 'bg-cyan-950/25 border-cyan-900/40 text-cyan-400'
                                }`}
                              >
                                <span>{isAudioMuted ? '🔇 Audio Muted' : '🔊 Audio Active'}</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Final Diagnostic Dyno reports sheet */}
                    {dynoSpecsReport && (
                      <div className="bg-slate-900 border border-purple-500/10 p-5 rounded-2xl animate-fadeIn">
                        <div className="flex justify-between items-center border-b border-purple-500/10 pb-2 mb-4">
                          <h4 className="text-xs font-bold text-slate-200 uppercase tracking-widest font-mono">DYNO TIMESHEET RECORD</h4>
                          <button onClick={() => setDynoSpecsReport(null)} className="text-xs text-slate-500 hover:text-slate-300">Clear timesheet✕</button>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                            <span className="text-[9px] text-slate-500 font-mono">0-100 ACCEL TIMINGS</span>
                            <p className="text-lg font-bold font-mono text-slate-200">{dynoSpecsReport.zeroToHundred} seconds</p>
                          </div>
                          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                            <span className="text-[9px] text-slate-500 font-mono">1/4 MILE ACCURACY TIME</span>
                            <p className="text-lg font-bold font-mono text-slate-200">{dynoSpecsReport.quarterMile} seconds</p>
                          </div>
                          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                            <span className="text-[9px] text-slate-500 font-mono">MAX SPEED ACHIEVED</span>
                            <p className="text-lg font-bold font-mono text-slate-200">{dynoSpecsReport.topSpeedReached} km/h</p>
                          </div>
                          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                            <span className="text-[9px] text-slate-500 font-mono">ENGINE HEALTH MATRIX</span>
                            <p className={`text-xs font-bold font-mono mt-1 ${
                              dynoSpecsReport.engineHealth === 'PRISTINE' ? 'text-emerald-400' :
                              dynoSpecsReport.engineHealth === 'MILD LEAK' ? 'text-yellow-400' : 'text-rose-500'
                            }`}>{dynoSpecsReport.engineHealth}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                    {/* ---------------------------------
                        MANUAL SOUNDSMAP REV-RIG MODE 
                        --------------------------------- */}
                    {testMode === 'manual' && (
                  <div className="w-full flex-1 animate-fadeIn">
                    <EngineControlPanel
                      car={getCarPlatform(activeVehicle.id)}
                      engineState={{
                        hp: calculatedHP,
                        torque: calculatedTorque,
                        rpmLimit: getCarPlatform(activeVehicle.id).limits.maxRPM,
                        boost: selectedTurbo ? getCarPlatform(activeVehicle.id).limits.maxBoost : 0,
                        weight: calculatedWeight,
                        loudness: 1.2,
                        roughness: 1.1,
                        brightness: 1.1,
                        turboIntensity: selectedTurbo ? 1.3 : 0.0,
                        backfireRate: 0.6,
                      }}
                      audioEngine={audioEngineRef.current}
                      isMuted={isAudioMuted}
                      onToggleMute={() => {
                        const nextMute = !isAudioMuted;
                        setIsAudioMuted(nextMute);
                        audioEngineRef.current?.setMuted(nextMute);
                      }}
                      ignitionOn={manualRevActive}
                      onToggleIgnition={() => {
                        if (manualRevActive) {
                           stopManualEngine();
                        } else {
                           startManualEngine();
                        }
                      }}
                      installedModIds={installedModIds}
                      subParts={subParts}
                    />
                  </div>
                )}

              </div>
            )}

            {activeTab === 'mods' && (
              <div className="flex-1 flex flex-col gap-4 animate-fadeIn">
                {/* View switcher toggle */}
                <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-mono font-bold text-purple-400 uppercase tracking-widest">Tuning Rig Layout</span>
                    <h2 className="text-sm font-black font-mono text-slate-100 uppercase tracking-tight">Sandbox Configuration Workspace</h2>
                  </div>
                  <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-850">
                    <button
                      onClick={() => setModsViewMode('categorized')}
                      className={`px-3 py-1.5 rounded-md text-[10px] font-mono tracking-wider font-bold uppercase transition-all duration-200 ${
                        modsViewMode === 'categorized'
                          ? 'bg-purple-600 text-white shadow'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      Categorized Accordion
                    </button>
                    <button
                      onClick={() => setModsViewMode('grid')}
                      className={`px-3 py-1.5 rounded-md text-[10px] font-mono tracking-wider font-bold uppercase transition-all duration-200 ${
                        modsViewMode === 'grid'
                          ? 'bg-purple-600 text-white shadow'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      Searchable Catalog Grid
                    </button>
                  </div>
                </div>

                <div className="flex-1 flex flex-col xl:flex-row gap-6">
                  <div className="flex-1 xl:w-2/3">
                    {modsViewMode === 'categorized' ? (
                      <ErrorBoundary>
                        <AdvancedModificationPanel
                          activeCar={getCarPlatform(activeVehicle.id)}
                          installedModIds={installedModIds}
                          onToggleMod={handleToggleVehicleMod}
                          engineState={{
                            hp: calculatedHP,
                            torque: calculatedTorque,
                            rpmLimit: getCarPlatform(activeVehicle.id)?.limits?.maxRPM ?? 7000,
                            boost: selectedTurbo ? (getCarPlatform(activeVehicle.id)?.limits?.maxBoost ?? 1.5) : 0,
                            weight: calculatedWeight,
                            loudness: 1.0,
                            roughness: 1.0,
                            brightness: 1.0,
                            turboIntensity: selectedTurbo ? 1.0 : 0.0,
                            backfireRate: 0.5,
                          }}
                          availableMods={VEHICLE_MODS_DATABASE}
                          appliedMods={VEHICLE_MODS_DATABASE.filter(m => Array.isArray(installedModIds) && installedModIds.includes(m.id))}
                        />
                      </ErrorBoundary>
                    ) : (
                      <ErrorBoundary>
                        <ModificationBrowser
                          activeCar={getCarPlatform(activeVehicle.id)}
                          installedModIds={installedModIds}
                          onToggleMod={handleToggleVehicleMod}
                          engineState={{
                            hp: calculatedHP,
                            torque: calculatedTorque,
                            rpmLimit: getCarPlatform(activeVehicle.id)?.limits?.maxRPM ?? 7000,
                            boost: selectedTurbo ? (getCarPlatform(activeVehicle.id)?.limits?.maxBoost ?? 1.5) : 0,
                            weight: calculatedWeight,
                            loudness: 1.0,
                            roughness: 1.0,
                            brightness: 1.0,
                            turboIntensity: selectedTurbo ? 1.0 : 0.0,
                            backfireRate: 0.5,
                          }}
                          availableMods={VEHICLE_MODS_DATABASE}
                          appliedMods={VEHICLE_MODS_DATABASE.filter(m => Array.isArray(installedModIds) && installedModIds.includes(m.id))}
                        />
                      </ErrorBoundary>
                    )}
                  </div>
                  <div className="xl:w-1/3 shrink-0">
                    <SelectedBuildSummary
                      activeCar={getCarPlatform(activeVehicle.id)}
                      installedModIds={installedModIds}
                      onRemoveMod={handleToggleVehicleMod}
                      onClearAll={() => {
                        setInstalledModIds([]);
                        showToast("Cleared active hardware configurations", "info");
                      }}
                      subParts={subParts}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* ---------------------------------
                IF ACTIVE TAB IS AI CHAT ASSISTANT WORKSPACE
                --------------------------------- */}
            {activeTab === 'ai' && (
              <div className="flex-1 flex flex-col md:flex-row gap-4 h-[500px] lg:h-auto overflow-hidden">
                
                {/* Active Setup Telemetry Specs Left Column */}
                <div className="md:w-1/3 bg-slate-900/40 border border-purple-500/10 p-4 rounded-2xl flex flex-col gap-4 overflow-y-auto">
                  <div>
                    <span className="text-[9px] font-bold text-purple-400 uppercase tracking-widest font-mono">Active Setup</span>
                    <h4 className="text-xs font-bold font-sans mt-0.5">{buildName}</h4>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800/20">
                      <span className="text-slate-500 block text-[9px] uppercase tracking-wider">displacement displacement block</span>
                      <span className="font-semibold">{engineItem.name}</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800/20">
                      <span className="text-slate-500 block text-[9px] uppercase tracking-wider">charger assembly</span>
                      <span className="font-semibold">{turboItem?.name || 'Naturally Aspirated Atmospheric'}</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800/20 flex justify-between">
                      <span className="text-slate-500">Peak horsepowers:</span>
                      <span className="font-bold text-cyan-400">{calculatedHP} HP</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800/20 flex justify-between">
                      <span className="text-slate-500">Cylinder stability rating:</span>
                      <span className={`font-bold ${reliability > 75 ? 'text-emerald-400' : 'text-rose-400'}`}>{reliability}%</span>
                    </div>
                  </div>

                  <div className="bg-slate-900 border border-purple-500/10 p-3 rounded-xl mt-auto">
                    <p className="text-[10px] text-slate-400 italic">
                      💡 Tip: Ask the AI details like \"How do I reduce intake charges without dropping boost pressure?\" or \"What are the limits of the standard block?\"
                    </p>
                  </div>
                </div>

                {/* Main AI chat thread terminal right column */}
                <div className="flex-1 bg-slate-900 border border-purple-500/10 rounded-2xl flex flex-col overflow-hidden">
                  <div className="bg-slate-950 p-3.5 border-b border-purple-500/10 flex items-center gap-2">
                    <Bot size={15} className="text-purple-400" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-200">INTERACTIVE DIAGNOSTICS CHAT</h4>
                      <p className="text-[9px] text-slate-500">Live conversation connected to full-stack Gemini flash</p>
                    </div>
                  </div>

                  {/* Messages Feed */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-3 font-sans">
                    {chatMessages.map((msg, index) => (
                      <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`p-3 rounded-xl max-w-[85%] text-xs leading-relaxed ${
                          msg.role === 'user' 
                            ? 'bg-purple-600 border border-purple-500 text-white rounded-br-none' 
                            : 'bg-slate-950 border border-slate-800 text-slate-300 rounded-bl-none'
                        }`}>
                          {msg.text}
                        </div>
                      </div>
                    ))}
                    {sendingChat && (
                      <div className="flex justify-start">
                        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-400 flex items-center gap-2">
                          <Loader2 className="animate-spin text-purple-400" size={12} />
                          <span>AI analyzing telemetry cells...</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Inputs keyboard form */}
                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      sendChatMessage();
                    }}
                    className="p-3 border-t border-purple-500/10 bg-slate-950/40 flex gap-2"
                  >
                    <input 
                      type="text"
                      placeholder="Type a tuning question..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      disabled={sendingChat}
                      className="flex-1 text-xs py-2.5 px-3 bg-slate-950 border border-purple-500/15 focus:border-purple-500/50 outline-none text-slate-100 rounded-lg placeholder-slate-500 font-sans"
                    />
                    <button 
                      type="submit"
                      disabled={sendingChat || !chatInput.trim()}
                      className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-30 text-white font-bold text-xs rounded-lg transition"
                    >
                      SEND
                    </button>
                  </form>
                </div>

              </div>
            )}

            {/* ---------------------------------
                IF ACTIVE TAB IS SWAP DIY MANUAL WORKSPACE
                --------------------------------- */}
            {activeTab === 'manual' && (
              <div className="flex-1 flex flex-col lg:flex-row gap-6 animate-fadeIn">
                
                {/* Left hand Category Selector Side Bar */}
                <div className="lg:w-1/3 flex flex-col gap-4">
                  <div className="bg-slate-900/60 border border-purple-500/10 p-4 rounded-2xl">
                    <span className="text-[9px] font-bold text-purple-400 uppercase tracking-widest font-mono">DYNO SWAP COMPANION</span>
                    <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-1.5 mt-0.5">
                      <Wrench size={16} className="text-purple-400 animate-pulse" />
                      Swap & DIY Manual
                    </h3>
                    <p className="text-[10.5px] text-zinc-400 mt-1 leading-relaxed">
                      Interactive tool-checks and physical swap blueprints configured specifically for your tuned parts and local Indian road compliance!
                    </p>
                  </div>

                  {/* Dynamic Upgrade Checklist Menu list */}
                  <div className="flex flex-col gap-2">
                    <button 
                      onClick={() => setSelectedManualCat('engine')}
                      className={`p-3 rounded-xl border text-left transition duration-150 flex items-center justify-between cursor-pointer ${
                        selectedManualCat === 'engine'
                          ? 'bg-purple-950/25 border-purple-500 text-slate-100 shadow-md shadow-purple-500/5'
                          : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:border-slate-750 hover:bg-slate-950/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm">⚙️</span>
                        <div>
                          <p className="text-xs font-bold font-sans">Engine Block & Internals</p>
                          <p className="text-[9px] text-zinc-500 font-mono">
                            {selectedEngine !== 'inline4-stock' ? '🔥 UPGRADED BLOCK' : 'OEM Stock Block'}
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-zinc-500">→</span>
                    </button>

                    <button 
                      onClick={() => setSelectedManualCat('forced_induction')}
                      className={`p-3 rounded-xl border text-left transition duration-150 flex items-center justify-between cursor-pointer ${
                        selectedManualCat === 'forced_induction'
                          ? 'bg-purple-950/25 border-purple-500 text-slate-100 shadow-md shadow-purple-500/5'
                          : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:border-slate-750 hover:bg-slate-950/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm">🌪️</span>
                        <div>
                          <p className="text-xs font-bold font-sans">Forced Induction / Turbo</p>
                          <p className="text-[9px] text-zinc-500 font-mono">
                            {selectedTurbo ? `⚡ ${turboItem?.brand} Active` : 'Naturally Aspirated'}
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-zinc-500">→</span>
                    </button>

                    <button 
                      onClick={() => setSelectedManualCat('exhaust')}
                      className={`p-3 rounded-xl border text-left transition duration-150 flex items-center justify-between cursor-pointer ${
                        selectedManualCat === 'exhaust'
                          ? 'bg-purple-950/25 border-purple-500 text-slate-100 shadow-md shadow-purple-500/5'
                          : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:border-slate-750 hover:bg-slate-950/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm">🎺</span>
                        <div>
                          <p className="text-xs font-bold font-sans">Air-flow & Exhaust Pipes</p>
                          <p className="text-[9px] text-zinc-500 font-mono">
                            {subParts.exhaustValve === 'active-bypass' ? '🔊 VALVETRONIC BYPASS' : 'Closed Loop Pipe'}
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-zinc-500">→</span>
                    </button>

                    <button 
                      onClick={() => setSelectedManualCat('fuel')}
                      className={`p-3 rounded-xl border text-left transition duration-150 flex items-center justify-between cursor-pointer ${
                        selectedManualCat === 'fuel'
                          ? 'bg-purple-950/25 border-purple-500 text-slate-100 shadow-md shadow-purple-500/5'
                          : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:border-slate-750 hover:bg-slate-950/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm">⛽</span>
                        <div>
                          <p className="text-xs font-bold font-sans">Fuel Pump & Injectors</p>
                          <p className="text-[9px] text-zinc-500 font-mono">
                            {subParts.fuelPump !== 'stock' || subParts.injectorSize !== 'stock' ? '⚡ COMPACT HIGH-FLOW' : 'Standard Feed'}
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-zinc-500">→</span>
                    </button>

                    <button 
                      onClick={() => setSelectedManualCat('ecu')}
                      className={`p-3 rounded-xl border text-left transition duration-150 flex items-center justify-between cursor-pointer ${
                        selectedManualCat === 'ecu'
                          ? 'bg-purple-950/25 border-purple-500 text-slate-100 shadow-md shadow-purple-500/5'
                          : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:border-slate-750 hover:bg-slate-950/10'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm">🔌</span>
                        <div>
                          <p className="text-xs font-bold font-sans">ECU Master Electronics</p>
                          <p className="text-[9px] text-zinc-500 font-mono">
                            {subParts.ecuVariant !== 'stock' ? '💻 RACING COMPUTER' : 'OEM Locked Board'}
                          </p>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-zinc-500">→</span>
                    </button>
                  </div>
                </div>

                {/* Right hand rich step by-step documentation hub */}
                <div className="flex-1 bg-slate-900 border border-purple-500/10 rounded-2xl flex flex-col overflow-hidden p-6 gap-6 min-h-[480px]">
                  
                  {/* ENGINE BLOCK SWAP DETAILS */}
                  {selectedManualCat === 'engine' && (
                    <div className="space-y-5">
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-500/10 pb-4">
                        <div>
                          <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest font-mono">GUIDE LEVEL: ADVANCED TUNER</span>
                          <h4 className="text-lg font-bold text-slate-100">Engine block structure & heavy internal swap</h4>
                        </div>
                        <div className="flex gap-2 text-xs font-mono">
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-amber-400 font-bold">⏱️ 14-18 Hours</span>
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-cyan-400 font-bold">🛠️ Heavy Hoist</span>
                        </div>
                      </div>

                      <div className="bg-slate-950/80 p-4 border border-slate-800/60 rounded-xl space-y-2">
                        <p className="text-xs font-bold text-slate-300">Active Setup detected for: <span className="text-purple-400">{activeVehicle.brand} {activeVehicle.name}</span></p>
                        <p className="text-[11px] text-zinc-400 leading-relaxed">
                          Installing pistons (<span className="text-cyan-400 font-semibold">{subParts.pistons === 'wiseco-forged' ? 'Wiseco Forged' : subParts.pistons === 'je-forged' ? 'JE Forged 2618' : 'Stock Cast'}</span>), 
                          crankshaft (<span className="text-cyan-400 font-semibold">{subParts.crankshaft === 'carrillo-billet' ? 'Carrillo Billet Steel' : subParts.crankshaft === 'eagle-forged' ? 'Eagle Forged 4340' : 'Stock Cast'}</span>), and camshaft (<span className="text-cyan-400 font-semibold">{subParts.camshaft === 'tomei-272' ? 'Tomei Procam 272° High-Lift' : 'Standard Duration'}</span>).
                        </p>
                      </div>

                      <div className="space-y-3">
                        <h5 className="text-xs font-bold text-purple-400 tracking-wider font-mono uppercase">Assembly Swap sequence:</h5>
                        <ol className="list-decimal list-inside space-y-2.5 text-xs text-zinc-300 pl-1 leading-relaxed">
                          <li>
                            <strong className="text-slate-100">Disconnection & Fluid Drain:</strong> Place front bumper in service position. Extract absolute engine coolant and motor engine oil completely via the sump drain bolt. Label and carefully tag the OEM harness looms.
                          </li>
                          <li>
                            <strong className="text-slate-100">Engine extraction:</strong> Secure a 2-Ton hydraulic workshop shop floor crane engine hoist to the main block mount hooks. Unbolt the engine blocks mounting arms, transmission bellhousing bolts, and gently telescope the engine unit completely out of the workspace.
                          </li>
                          <li>
                            <strong className="text-slate-100">Sump and head disassembly:</strong> Drop the oil pan oil tray and oil sump element. Remove cylinder head studs in reverse sequence to avoid warping the top plate. Clean grease using premium block cleaners.
                          </li>
                          <li>
                            <strong className="text-slate-100">Swapping heavy internals:</strong> Lubricate the upgraded <span className="text-cyan-300 font-mono">{subParts.pistons !== 'stock' ? 'Forged Pistons' : 'Cast Pistons'}</span> with engine assembly grease. Use a standard cylinder ring clamp sleeve compression tool to gently hammer each piston down the bore without scraping cylinder honing walls. Torque rod cap bolts to exact ARP fastener manufacturer alignment ratings!
                          </li>
                          <li>
                            <strong className="text-slate-100">Camilsh and crank drop:</strong> Set the crankshaft into standard journal shell bearings. Add threadlocker to crank counter-weights and torque to spec. Fit Tomei 272 camshafts onto clean cylinder head journal tracks, ensuring perfect double-overhead-cam marker timing to prevent catastrophic piston-to-valve collisions!
                          </li>
                        </ol>
                      </div>

                      {/* Indian tuning compliance special advice */}
                      <div className="bg-rose-950/15 border border-rose-900/30 p-4 rounded-xl space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">🇮🇳</span>
                          <h6 className="text-xs font-bold text-rose-400 uppercase tracking-widest font-mono">Indian RTO & Street Legal Advisor</h6>
                        </div>
                        <p className="text-[10.5px] text-zinc-400 leading-relaxed">
                          In India, structural engine block replacements (engine swaps) are extremely strict under the Motor Vehicles Act. Unless the new engine has identical displacement and fuel type details registered on the RC book (via form 21/22 and an authorised dealer invoice approval), your vehicle will fail standard fitness tests and can get legally blacklisted!
                          <br />
                          <span className="text-amber-400 font-semibold block mt-1">👨‍🔧 Pro Tuner Sleepers Trick:</span> Most Indian modified Swift and Polo GT enthusiasts prefer utilizing the **Stock Block casing with forged internals (sleeving down internally)**. By maintaining the factory casing outside, the unique OEM engine chassis serial stamps remain intact, maintaining full legality while safely pushing massive 350+ HP boost pressure upgrades under the radar!
                        </p>
                      </div>
                    </div>
                  )}

                  {/* FORCED INDUCTION SWAP DETAILS */}
                  {selectedManualCat === 'forced_induction' && (
                    <div className="space-y-5">
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-500/10 pb-4">
                        <div>
                          <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest font-mono">GUIDE LEVEL: MEDIUM SPEC</span>
                          <h4 className="text-lg font-bold text-slate-100">Forced Induction / Turbocharger swap steps</h4>
                        </div>
                        <div className="flex gap-2 text-xs font-mono">
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-amber-400 font-bold">⏱️ 8-10 Hours</span>
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-cyan-400 font-bold">🛠️ Plumb kit</span>
                        </div>
                      </div>

                      <div className="bg-slate-950/80 p-4 border border-slate-800/60 rounded-xl">
                        <p className="text-xs font-bold text-slate-300">Target Turbo selected: <span className="text-purple-400">{turboItem?.name || 'Bolt-on Turbo assembly'}</span></p>
                        <p className="text-[11px] text-zinc-400 mt-1 leading-relaxed">
                          {selectedTurbo ? (
                            `Fitting a premium high-volume ${turboItem?.brand} unit (${turboItem?.model}) featuring a ${turboItem?.specs?.["Bearing Type"]} and rated to support up to ${turboItem?.specs?.["Max Boost Rating"]} boost threshold pressures.`
                          ) : (
                            "Your vehicle is currently Naturally Aspirated. However, custom Bolt-On Turbo (BOT) conversions on Indian Maruti Swift 1.2L K12 engines and older Honda Civics are highly popular! Below are the physical kit mounting guidelines."
                          )}
                        </p>
                      </div>

                      <div className="space-y-3">
                        <h5 className="text-xs font-bold text-purple-400 tracking-wider font-mono uppercase font-semibold">Turbo Bolt-on physical assembly guide:</h5>
                        <ul className="space-y-2 text-xs text-zinc-300 list-disc list-inside leading-relaxed pl-1">
                          <li>
                            <strong className="text-slate-100">Exhaust Manifold preparation:</strong> Unbolt the standard cast-iron exhaust manifold. Clean debris out of all exhaust studs. Install a heavy-duty gaskets flange designed to align with the turbo's T25 or T4 scroll opening.
                          </li>
                          <li>
                            <strong className="text-slate-100">Pre-lubrication (CRITICAL):</strong> Fill the internal turbo bearing center cartridge with fresh motor oil directly via the top oil-feed inlet before connecting any oil lines. Failing to prime the shaft will instantly destroy turbo bearings upon initial dry-start combustion!
                          </li>
                          <li>
                            <strong className="text-slate-100">Plumbing feed & return lines:</strong> Connect stainless steel oil feed from the oil pressure switch block. Fabricate a 10AN minimum return hose draining directly down to the oil pan sump (must descend vertically with zero bends to avoid oil backup leaks).
                          </li>
                          <li>
                            <strong className="text-slate-100">Charge pipe path:</strong> Route high-strength multi-layer reinforced silicone piping from compressor output to Mishimoto intercooler inlet, and back to throttle body core. Secure joints using T-bolt clamps (do not use cheap worm gear clamps which blow off under high boost pressures).
                          </li>
                          <li>
                            <strong className="text-slate-100">Wastegate setup:</strong> {subParts.wastegate === 'tial-external' ? (
                              "Install TiAL 44mm external wastegate onto dedicated runner path on Tomei exhaust headers. Mount screamer tube pointing raw exhaust direct to atmosphere for terrifying open exhaust fire bursts!"
                            ) : (
                              "Configure physical internal vacuum wastegate spring tension arm. Ensure boost solenoid matches vacuum input tables to prevent violent engine overboosting!"
                            )}
                          </li>
                        </ul>
                      </div>

                      <div className="bg-amber-950/15 border border-amber-900/40 p-4 rounded-xl space-y-2">
                        <div className="flex items-center gap-1.5 font-bold text-amber-400 text-xs">
                          <AlertTriangle size={14} />
                          <span>🇮🇳 Delhi/NCR & Indian High Thermal Mitigation notes</span>
                        </div>
                        <p className="text-[10.5px] text-zinc-400 leading-relaxed">
                          Indian summer temperatures frequently reach **42°C to 47°C** across Delhi/NCR and Central India. Turbocharged cars can suffer severe heat soak within minutes. Always wrap your exhaust downpipe with premium **Titanium Heat Wrap shielding** and install a custom turbo heat-shield blanket to prevent melting wiring looms or boiling brake master cylinder reservoirs adjacent to the exhaust housing!
                        </p>
                      </div>
                    </div>
                  )}

                  {/* EXHAUST & VALVETRONIC SWAP DETAILS */}
                  {selectedManualCat === 'exhaust' && (
                    <div className="space-y-5">
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-500/10 pb-4">
                        <div>
                          <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest font-mono">GUIDE LEVEL: STREET MECHANIC</span>
                          <h4 className="text-lg font-bold text-slate-100">Exhaust headers & Valvetronic bypass swap manual</h4>
                        </div>
                        <div className="flex gap-2 text-xs font-mono">
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-amber-400 font-bold">⏱️ 3-5 Hours</span>
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-cyan-400 font-bold">🛠️ Ramp / Stands</span>
                        </div>
                      </div>

                      <div className="bg-slate-950/80 p-4 border border-slate-800/60 rounded-xl space-y-1">
                        <p className="text-xs font-bold text-slate-300">Selected Setup: <span className="text-purple-400">HEADERS: {subParts.manifoldType === 'tomei-equal' ? 'Tomei Equal-Length' : 'Stock Manifold'} | CATBACK: {subParts.catbackDiameter === 'titanium-3.5' ? 'Akrapovič 3.5" Titanium' : subParts.catbackDiameter === 'edelstahl-3.0' ? 'BBR Edelstahl 3.0"' : 'Stock Catback'}</span></p>
                        <p className="text-[10.5px] text-zinc-400 leading-relaxed">
                          Sound Acoustics Status: <span className="text-emerald-400 font-semibold font-mono">Valvetronic Acoustic Bypass Valve installed ({subParts.exhaustValve === 'active-bypass' ? 'Active remote control' : 'OEM Continuous'})</span>.
                        </p>
                      </div>

                      <div className="space-y-3">
                        <h5 className="text-xs font-bold text-purple-400 tracking-wider font-mono uppercase font-semibold text-slate-100">Step-by-step DIY exhaust installation instruction details:</h5>
                        <ul className="space-y-2 text-xs text-zinc-300 list-decimal list-inside leading-relaxed pl-1">
                          <li>
                            <strong className="text-slate-100">Exhaust manifold removal:</strong> Jack up vehicle on four robust lock stands. Spray WD-40 liberally on standard manifold rusty flange nuts. Gently tap header loose of the block studs.
                          </li>
                          <li>
                            <strong className="text-slate-100">Hanger matching:</strong> slide the lightweight stainless or titanium layout pipeline onto factory rubber exhaust hanger grommets on underside of the chassis. Do not let pipe rub against metal frame to prevent rattling noise.
                          </li>
                          <li>
                            <strong className="text-slate-100">Bypass flanged installation:</strong> Fit Capristo electronic actuator valvetronic chamber segment between the mid-pipe resonator and standard rear exhaust muffler compartment. Ensure gas-tight gasket seal!
                          </li>
                          <li>
                            <strong className="text-slate-100">Valvetronic Remote Receiver wiring:</strong> Route electronic wires along cabin side frames strictly away from direct exhaust heat. Enter interior cabin via rubber firewall grommets in passenger compartment footwell. Connect positive 12V supply pin to local fusebox terminal and anchor ground ring to bare interior chassis metal.
                          </li>
                          <li>
                            <strong className="text-slate-100">Acoustic Testing:</strong> Start engine with remote control bypass closed (Stock civil city mode) to verify near-silent engine idle hum. Click remote bypass button on keyfob to open electronic throttle flaps: direct screaming exhaust flow bypasses baffle chambers, unlocking that raw racetrack acoustics!
                          </li>
                        </ul>
                      </div>

                      <div className="bg-cyan-950/20 border border-cyan-900/30 p-4 rounded-xl space-y-1 text-xs">
                        <p className="font-bold text-cyan-400 flex items-center gap-1">
                          <span>👮</span>
                          <span>Avoid Sound Challans (Indian Regional RTO and Traffic policing rules)</span>
                        </p>
                        <p className="text-[10.5px] text-zinc-400 leading-relaxed">
                          In major Indian cities like Gurugram, Mumbai, Delhi, Bengaluru, and Pune, the traffic police actively deploy decibel noise monitors to arrest vehicles with loud replacement exhausts, issuing hefty heavy challans (Rs. 10,000+). 
                          <br />
                          This is exactly why **Active Remote Valvetronic Bypass Valves** are extremely popular in India! Enthusiasts keep the valve **CLOSED** when driving past police checkpoints or deep in quiet residential streets (retaining quiet standard stock direct tone), then open it instantly on track loops or high-rev highways!
                        </p>
                      </div>
                    </div>
                  )}

                  {/* FUEL INJECTOR & PUMP FUEL SYSTEM SWAP */}
                  {selectedManualCat === 'fuel' && (
                    <div className="space-y-5">
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-500/10 pb-4">
                        <div>
                          <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest font-mono">GUIDE LEVEL: MEDIUM TUNER</span>
                          <h4 className="text-lg font-bold text-slate-100">High-Flow fuel injectors & in-tank fuel pump swap</h4>
                        </div>
                        <div className="flex gap-2 text-xs font-mono">
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-amber-400 font-bold">⏱️ 4-5 Hours</span>
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-cyan-400 font-bold">🛠️ No spark tools</span>
                        </div>
                      </div>

                      <div className="bg-slate-950/80 p-4 border border-slate-800/60 rounded-xl space-y-1">
                        <p className="text-xs font-bold text-slate-300">Installed fuel hardware: <span className="text-purple-400">PUMP: {subParts.fuelPump === 'walbro-255' ? 'Walbro 255 LPH' : subParts.fuelPump === 'bosch-044' ? 'Bosch 044 External' : 'Stock 150 LPH'} | INJECTORS: {subParts.injectorSize !== 'stock' ? 'Upgraded High Fluid Rate' : 'Stock 220cc'}</span></p>
                        <p className="text-[10.5px] text-zinc-400 leading-relaxed">
                          Delivery pressure capability: <span className="text-cyan-400">{subParts.fuelLine === 'ptfe-teflon' ? 'E85 Chemically Immune PTFE Braided' : subParts.fuelLine === 'braided-an' ? 'Braided AN6 Metallic' : 'Stock Rubber'} Fuel lines</span>.
                        </p>
                      </div>

                      <div className="space-y-3">
                        <h5 className="text-xs font-bold text-purple-400 tracking-wider font-mono uppercase font-semibold text-slate-100">Physical fuel hardware installation instructions:</h5>
                        <ul className="space-y-2 text-xs text-zinc-300 list-decimal list-inside leading-relaxed pl-1">
                          <li>
                            <strong className="text-slate-100">Depressurize the fuel lines:</strong> Pull off the fuel pump fuse directly from primary engine fuse relay pane. Crank the engine several times until engine stalls out completely. This evacuates fuel line residual pressure, avoiding highly dangerous high pressure sprays when fuel rails are loosened!
                          </li>
                          <li>
                            <strong className="text-slate-100">Injectors swap:</strong> Unbolt the double-feed Radium fuel rail bracket bolts. Gently pull standard 220cc injector pins from their ports. Lubricate new injector rubber O-rings with silicone grease. Install injectors firmly back into manifold block and secure the rail clips.
                          </li>
                          <li>
                            <strong className="text-slate-100">In-Tank Fuel Pump installation:</strong> Lift block seats inside the passenger compartment to access the circular metal hatch panel cover. Clean absolute dust completely before opening fuel tank rim lock to prevent dirt ingestion in reserve tank. Extract context holder container mechanism.
                          </li>
                          <li>
                            <strong className="text-slate-100">Rewiring Walbro pump:</strong> Swap standard factory fuel pump with Walbro 255 LPH pump core shell. Solder premium heat-shrink connectors onto wiring connections to avoid standard sparks inside gas environment. Reinsert cluster assembly firmly back down tank chamber.
                          </li>
                        </ul>
                      </div>

                      <div className="bg-rose-950/15 border border-rose-900/40 p-4 rounded-xl space-y-1.5">
                        <p className="font-bold text-rose-400 text-xs flex items-center gap-1.5">
                          <span>🚨</span>
                          <span>Crucial Safety Guidelines</span>
                        </p>
                        <p className="text-[10.5px] text-zinc-400 leading-relaxed font-sans">
                          Perform ALL fuel injection operations in an open-air garage layout with zero flame presence. Keep a certified class carbon-dioxide fire extinguisher nearby. Always wear anti-splash safety eyewear and dynamic fuel-resistant nitrile gloves!
                        </p>
                      </div>
                    </div>
                  )}

                  {/* ECU MASTER PROGRAMMING / HARNESS WIRING */}
                  {selectedManualCat === 'ecu' && (
                    <div className="space-y-5">
                      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-purple-500/10 pb-4">
                        <div>
                          <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest font-mono">GUIDE LEVEL: PRO TUNER EXPERT</span>
                          <h4 className="text-lg font-bold text-slate-100">ECU standalone computer & Mil-spec Raychem loom mounting</h4>
                        </div>
                        <div className="flex gap-2 text-xs font-mono">
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-amber-400 font-bold">⏱️ 8-12 Hours</span>
                          <span className="px-2.5 py-1 rounded bg-slate-950 text-cyan-400 font-bold">🛠️ Multimeter</span>
                        </div>
                      </div>

                      <div className="bg-slate-950/80 p-4 border border-slate-800/60 rounded-xl space-y-1">
                        <p className="text-xs font-bold text-slate-300">Selected ECU system: <span className="text-purple-400">{subParts.ecuVariant === 'motec' ? 'MoTeC M130 Champion Clubman' : subParts.ecuVariant === 'haltech' ? 'Haltech Elite 1500 System' : 'OEM Restricted ECU'}</span></p>
                        <p className="text-[10.5px] text-zinc-400 leading-relaxed font-sans">
                          Ignition Coils: <span className="text-cyan-400">{subParts.ignitionCoils === 'okada-plasma' ? 'Okada Projects High-Output Smart Coils' : 'Stock Coils'}</span> | Harness: <span className="text-cyan-400">{subParts.wiringHarness === 'raychem-milspec' ? 'DR-25 Mil-spec Concentric loom' : 'Stock Harness'}</span>
                        </p>
                      </div>

                      <div className="space-y-3 font-sans">
                        <h5 className="text-xs font-bold text-purple-400 tracking-wider font-mono uppercase font-semibold">Standalone engine electronics setup step detail:</h5>
                        <ul className="space-y-2 text-xs text-zinc-350 list-decimal list-inside leading-relaxed pl-1">
                          <li>
                            <strong className="text-slate-100">Disconnect primary battery ground cable:</strong> Avoid potential electrical shorts in complex ECU processor chips before routing pins!
                          </li>
                          <li>
                            <strong className="text-slate-100">Loom layout deployment:</strong> Route Raychem DR-25 concentric twisted braided high-performance engine loom through main bulkhead path. DR-25 shielding is completely immune to electrical interference from performance spark plugs and block induction currents.
                          </li>
                          <li>
                            <strong className="text-slate-100">Plugging ECU Pin connector brackets:</strong> Mount the Haltech Elite or MoTeC unit cleanly on custom mounting plates behind the vehicle cluster or glove compartment compartment to guard from outside humidity/water engine splash mud.
                          </li>
                          <li>
                            <strong className="text-slate-100">Sensors connection matching:</strong> Hook up digital wideband MAP manifold air pressure sensor, air charge temperature probe, and Okada projects Smart coils. Connect target trigger wheel crankshaft reader configuration.
                          </li>
                          <li>
                            <strong className="text-slate-100">Basemap Configuration & Knock thresholds settings:</strong> Open your laptops companion MoTeC/Haltech firmware program. Load the customized target timing map of your car. Ensure to calibrate throttle positions and set conservative ignition timing retards to protect pistons before pushing real boost runs on dyno!
                          </li>
                        </ul>
                      </div>
                    </div>
                  )}

                  {/* INTERACTIVE WORKSHOP EQUIPMENT TOOLCHECK */}
                  <div className="mt-auto pt-5 border-t border-purple-500/10 space-y-3 bg-slate-900">
                    <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest font-mono block">🛠️ Workshop Tool check list (Confirm items before swap):</span>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
                      <label className="flex items-center gap-2 bg-slate-950 p-2 rounded-lg border border-slate-800 text-[10px] text-zinc-400 cursor-pointer hover:bg-slate-900 select-none">
                        <input type="checkbox" className="rounded accent-purple-500 bg-slate-900 outline-none border border-slate-700 w-3 h-3 cursor-pointer" />
                        <span>Torque wrench</span>
                      </label>
                      <label className="flex items-center gap-2 bg-slate-950 p-2 rounded-lg border border-slate-800 text-[10px] text-zinc-400 cursor-pointer hover:bg-slate-900 select-none">
                        <input type="checkbox" className="rounded accent-purple-500 bg-slate-900 outline-none border border-slate-700 w-3 h-3 cursor-pointer" />
                        <span>Hydraulic jack / stands</span>
                      </label>
                      <label className="flex items-center gap-2 bg-slate-950 p-2 rounded-lg border border-slate-800 text-[10px] text-zinc-400 cursor-pointer hover:bg-slate-900 select-none">
                        <input type="checkbox" className="rounded accent-purple-500 bg-slate-900 outline-none border border-slate-700 w-3 h-3 cursor-pointer" />
                        <span>WD40 rust pen</span>
                      </label>
                      <label className="flex items-center gap-2 bg-slate-950 p-2 rounded-lg border border-slate-800 text-[10px] text-zinc-400 cursor-pointer hover:bg-slate-900 select-none">
                        <input type="checkbox" className="rounded accent-purple-500 bg-slate-900 outline-none border border-slate-700 w-3 h-3 cursor-pointer" />
                        <span>Fire Extinguisher</span>
                      </label>
                    </div>
                  </div>

                </div>
              </div>
            )}
          </div>
        </section>

        {/* ==========================================
            RIGHT PANEL: ENGINE POWER GRAPHS & METRICS
            ========================================== */}
        <aside className="lg:col-span-3 border-l border-purple-500/10 flex flex-col bg-slate-900/60 overflow-y-auto p-4 space-y-5">
          
          {/* Build Name details widget */}
          <div className="border-b border-purple-500/10 pb-4">
            <span className="text-[9px] font-bold text-purple-400 uppercase tracking-widest font-mono">Simulated Profile</span>
            <input 
              type="text" 
              value={buildName}
              onChange={(e) => setBuildName(e.target.value)}
              className="w-full text-base font-bold text-slate-100 bg-transparent outline-none focus:border-b focus:border-purple-500 mt-1 cursor-text"
              placeholder="Build layout name"
            />
            <textarea 
              value={buildDescription}
              onChange={(e) => setBuildDescription(e.target.value)}
              className="w-full text-xs text-slate-400 bg-transparent outline-none focus:border focus:border-purple-500/15 rounded p-1 mt-1 font-sans resize-none h-12"
              placeholder="Enter custom specifications description here..."
            />
          </div>

          {/* Quick Stats Panel */}
          <div className="space-y-2">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono block">Performance telemetry</span>
            
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-slate-950 p-3 rounded-xl border border-cyan-500/10 flex flex-col justify-between">
                <span className="text-[8px] text-slate-500 font-mono tracking-wider uppercase">Power Output</span>
                <p className="text-xl font-bold text-cyan-400 font-mono">{calculatedHP} <span className="text-xs text-slate-500">HP</span></p>
                <span className="text-[8px] text-slate-400 mt-1">Base + boost additions</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-purple-500/10 flex flex-col justify-between">
                <span className="text-[8px] text-slate-500 font-mono tracking-wider uppercase">Peak Torque</span>
                <p className="text-xl font-bold text-purple-400 font-mono">{calculatedTorque} <span className="text-xs text-slate-500">NM</span></p>
                <span className="text-[8px] text-slate-400 mt-1">Cylinder torque push</span>
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-purple-500/5 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">0-100 km/h:</span>
                <span className="font-bold text-orange-400 font-mono">{calculatedAccel} seconds</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Top Speed:</span>
                <span className="font-bold text-slate-200 font-mono">{calculatedTopSpeed} km/h</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Redline limit:</span>
                <span className="font-bold text-slate-300 font-mono">{updatedRedline} RPM</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Build Weight:</span>
                <span className="font-bold text-slate-300 font-mono">{calculatedWeight} kg</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Gas Usage Ratio:</span>
                <span className="font-bold text-slate-300 font-mono">{calculatedFuel} L / 100km</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Coolant temp:</span>
                <span className={`font-bold font-mono ${calculatedTemp > 105 ? 'text-rose-500 animate-pulse' : 'text-slate-300'}`}>
                  {calculatedTemp}°C {calculatedTemp > 105 ? '⚠️ COOLANT HOT' : ''}
                </span>
              </div>
            </div>
          </div>

          {/* Recharts Power Curve lines */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono">DYNOMETER CHARTS</span>
              <span className="text-[8px] font-mono text-cyan-400">RPM Grid</span>
            </div>
            
            <div className="h-44 bg-slate-950 p-1.5 rounded-xl border border-purple-500/5">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={powerCurveData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                  <XAxis dataKey="rpm" tick={{ fill: '#64748b', fontSize: 9 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fill: '#64748b', fontSize: 9 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#0c0e25', borderColor: '#8a2be2', borderRadius: 8, fontSize: 10 }} />
                  <Line type="monotone" dataKey="Power (HP)" stroke="#ef4444" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="Torque (NM)" stroke="#06b6d4" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-4 text-[9px] font-mono text-slate-500">
              <span className="flex items-center gap-1"><span className="w-2 h-0.5 bg-red-500 inline-block"/> Power (HP)</span>
              <span className="flex items-center gap-1"><span className="w-2 h-0.5 bg-cyan-400 inline-block"/> Torque (NM)</span>
            </div>
          </div>

          {/* Weight distribution pie chart */}
          <div className="space-y-2">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono">Weight Distribution</span>
            <div className="bg-slate-950 p-2.5 rounded-xl border border-purple-500/5 flex items-center justify-between">
              
              <div className="w-1/2 h-20">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Front Bias', value: frontWeightRatio },
                        { name: 'Rear Bias', value: rearWeightRatio }
                      ]}
                      cx="50%"
                      cy="50%"
                      innerRadius={18}
                      outerRadius={30}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      <Cell fill="#06b6d4" />
                      <Cell fill="#ef4444" />
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="w-1/2 text-xs font-mono space-y-1">
                <div className="flex items-center gap-1.5 justify-between">
                  <span className="flex items-center gap-1 text-[10px] text-slate-400">
                    <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full"/> Front:
                  </span>
                  <span className="font-bold text-cyan-400">{frontWeightRatio}%</span>
                </div>
                <div className="flex items-center gap-1.5 justify-between">
                  <span className="flex items-center gap-1 text-[10px] text-slate-400">
                    <span className="w-1.5 h-1.5 bg-red-500 rounded-full"/> Rear:
                  </span>
                  <span className="font-bold text-red-500">{rearWeightRatio}%</span>
                </div>
              </div>

            </div>
          </div>

          {/* Reliability rating gradient bar */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono">Overall Reliability</span>
              <span className={`font-mono font-bold ${reliability > 85 ? 'text-emerald-400' : reliability > 70 ? 'text-amber-400' : 'text-rose-500 animate-pulse'}`}>{reliability}%</span>
            </div>
            
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-900">
              <div 
                className="h-full transition-all duration-300"
                style={{
                  width: `${reliability}%`,
                  background: reliability > 85 ? 'linear-gradient(90deg, #10b981, #34d399)' :
                             reliability > 70 ? 'linear-gradient(90deg, #f59e0b, #fbbf24)' :
                             'linear-gradient(90deg, #ef4444, #f87171)'
                }}
              />
            </div>
          </div>

          {/* AI Advisor Panel */}
          <div className="border border-purple-500/25 p-4 rounded-xl bg-gradient-to-br from-purple-950/20 via-slate-950 to-slate-950/45 text-slate-300 space-y-3 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-12 bg-purple-500/5 rounded-full blur-xl pointer-events-none" />
            
            <div className="flex justify-between items-center border-b border-purple-500/10 pb-1.5">
              <div className="flex items-center gap-1 text-xs">
                <Sparkles size={13} className="text-purple-400 animate-pulse" />
                <span className="font-bold text-slate-200">✨ AI Advisor Panel</span>
              </div>
              <button 
                onClick={executeAIAdvisorCall}
                disabled={loadingAI}
                className="text-[9px] bg-purple-900/30 hover:bg-purple-900/50 border border-purple-500/30 font-bold px-2 py-0.5 rounded tracking-wide text-purple-300 disabled:opacity-30 self-start transition"
              >
                {loadingAI ? 'DIAGNOSING...' : 'RUN AUDIT'}
              </button>
            </div>

            <p className="text-[11px] leading-relaxed text-slate-300 italic">{aiAnalysis}</p>

            {aiWarnings.length > 0 && (
              <div className="space-y-1 bg-rose-950/20 border border-rose-500/10 p-2 rounded-lg text-[10px]">
                <span className="font-extrabold text-rose-400 flex items-center gap-1 uppercase tracking-widest"><AlertTriangle size={10}/> Bottlenecks detected:</span>
                {aiWarnings.map((warn, i) => (
                  <p key={i} className="text-slate-400">• {warn}</p>
                ))}
              </div>
            )}

            {aiSuggestions.length > 0 && (
              <div className="space-y-1 bg-cyan-950/20 border border-cyan-500/10 p-2 rounded-lg text-[10px]">
                <span className="font-extrabold text-cyan-400 flex items-center gap-1 uppercase tracking-widest"><Wrench size={10}/> Recommendation channels:</span>
                {aiSuggestions.map((sug, i) => (
                  <p key={i} className="text-slate-400">• {sug}</p>
                ))}
              </div>
            )}

            <div className="text-[10px] text-purple-400 font-mono flex items-center gap-1 pt-1">
              <Check size={12}/> {aiTip}
            </div>
          </div>

          {/* Builds History List Box */}
          <div className="space-y-2.5">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest font-mono block">Build history shelf</span>
            
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {savedBuilds.length === 0 ? (
                <div className="text-center p-4 border border-dashed border-slate-800 rounded bg-slate-950/20 text-slate-500 text-[10px]">
                  No saved setups on local index shelf yet.
                </div>
              ) : (
                savedBuilds.map(b => (
                  <div 
                    key={b.id} 
                    onClick={() => handleLoadHistoricBuild(b)}
                    className="p-2 rounded-lg bg-slate-950 border border-purple-500/5 hover:border-purple-500/20 hover:bg-slate-900/50 cursor-pointer flex justify-between items-center transition"
                  >
                    <div className="min-w-0 pr-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold font-sans text-slate-200 line-clamp-1">{b.name}</span>
                        <span className="text-[8px] bg-slate-900 border border-slate-700 font-mono px-1 rounded uppercase">{b.id}</span>
                      </div>
                      <span className="text-[10px] text-cyan-400 font-mono">{b.stats?.hp || '320'} HP • {b.stats?.reliability || '85'}% Rel</span>
                    </div>
                    <button 
                      onClick={(e) => handleDeleteHistoricBuild(b.id, e)}
                      className="p-1 hover:bg-rose-950/20 rounded text-slate-500 hover:text-rose-400 transition"
                      title="Delete build"
                    >
                      <Trash size={12} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

        </aside>

      </div>
    </div>
  );
}
