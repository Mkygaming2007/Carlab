export interface EngineHealth {
  temperature: number;      // Celsius (default / optimal is ~85°C)
  wear: number;             // 0% (pristine) to 100% (worn out)
  damage: number;           // 0% (healthy) to 100% (destroyed)
  isEngineBlown: boolean;   // true if damage >= 100%
  warningLights: {
    checkEngine: boolean;
    overheating: boolean;
    highBoost: boolean;
    oilPressure: boolean;
  };
}

// Initial engine health state factory
export function createInitialHealth(): EngineHealth {
  return {
    temperature: 70.0, // starts warmish, warms up to ~85°C base
    wear: 0,
    damage: 0,
    isEngineBlown: false,
    warningLights: {
      checkEngine: false,
      overheating: false,
      highBoost: false,
      oilPressure: false,
    },
  };
}

// Safe limits configuration
export const HEALTH_LIMITS = {
  optimalTemp: 85.0,
  overheatThreshold: 105.0,
  blownTempThreshold: 125.0,
  safeBoostLimit: 1.8, // in bar (beyond this causes cylinder block stress)
  wearDamageThreshold: 80.0, // 80% wear starts causing spontaneous structural damage
};

// Task 2 & 3 & 4 & 5: Health & Temperature Model Simulation
export function updateEngineHealth(
  health: EngineHealth,
  rpm: number,
  maxRPM: number,
  boost: number,
  throttle: number,
  speedKmh: number,
  dt: number
): EngineHealth {
  if (health.isEngineBlown) {
    // Blown engine is dead and cools down to ambient (25°C)
    const currentTemp = health.temperature;
    const nextTemp = currentTemp + (25.0 - currentTemp) * (1.0 - Math.exp(-0.05 * dt));
    return {
      ...health,
      temperature: nextTemp,
      warningLights: {
        checkEngine: true,
        overheating: false,
        highBoost: false,
        oilPressure: true, // Loss of oil pressure
      },
    };
  }

  // Task 2: Temperature model calculation
  let temperature = health.temperature;

  // Heat generation: proportional to throttle load, high RPM index, and forced turbo boost induction
  const rpmLoad = rpm / maxRPM;
  const combustionHeat = throttle * rpmLoad * 9.5 * dt;
  const turboHeat = boost * 7.5 * dt;
  const totalHeatGen = combustionHeat + turboHeat;

  // Cooling: active radiator thermo-fan + fast speed ambient dynamic airflow
  const baseCoolingRate = 0.08; // static thermostat/water pump loop
  const airCoolingFactor = speedKmh / 160.0; // dynamic frontal ram air
  const coolingPower = (baseCoolingRate + airCoolingFactor) * (temperature - 25.0) * dt;

  temperature = temperature + totalHeatGen - coolingPower;
  // Always restrict engine temperature to look realistic (minimum ambient, max safety melt limit)
  temperature = Math.max(25.0, Math.min(135.0, temperature));

  // Task 3: Damage and Wear logic accumulation
  let wear = health.wear;
  let damage = health.damage;

  // 1. Wear accumulation (standard running deterioration)
  // Reving near redline increases wear speed
  const highRpmWearRate = rpm > maxRPM * 0.85 ? 0.05 * dt : 0.005 * dt;
  wear = Math.min(100, wear + highRpmWearRate);

  // 2. High Temperature damage
  if (temperature > HEALTH_LIMITS.overheatThreshold) {
    const overheatSeverity = (temperature - HEALTH_LIMITS.overheatThreshold) / 20.0;
    damage = Math.min(100, damage + overheatSeverity * 1.5 * dt);
    wear = Math.min(100, wear + overheatSeverity * 2.0 * dt);
  }

  // 3. High Boost damage
  if (boost > HEALTH_LIMITS.safeBoostLimit) {
    const boostOverload = boost - HEALTH_LIMITS.safeBoostLimit;
    damage = Math.min(100, damage + boostOverload * 3.5 * dt);
  }

  // 4. Overrev/Inertial stress damage (e.g. Money shift or bouncing too long)
  if (rpm > maxRPM) {
    const mechanicalOverspeed = (rpm - maxRPM) / 1000.0;
    damage = Math.min(100, damage + (mechanicalOverspeed + 0.5) * 8.0 * dt);
  }

  // 5. Advanced severe wear leakage (extremely high wear starts spontaneous structural failure)
  if (wear > HEALTH_LIMITS.wearDamageThreshold) {
    const structuralFatigue = (wear - HEALTH_LIMITS.wearDamageThreshold) / 20.0;
    damage = Math.min(100, damage + structuralFatigue * 0.2 * dt);
  }

  // Engine blown failure check
  const isEngineBlown = damage >= 100;

  // Warning light telemetry updates
  const warningLights = {
    checkEngine: damage > 20 || wear > 60 || isEngineBlown,
    overheating: temperature >= HEALTH_LIMITS.overheatThreshold,
    highBoost: boost > HEALTH_LIMITS.safeBoostLimit,
    oilPressure: temperature >= 118 || isEngineBlown,
  };

  return {
    temperature,
    wear,
    damage,
    isEngineBlown,
    warningLights,
  };
}

// Task 4: ECU system evaluation holding state limits
export interface ECULimits {
  softLimitRPM: number;
  hardLimitRPM: number;
}

export function getECUPreset(maxRPM: number): ECULimits {
  return {
    softLimitRPM: maxRPM,
    hardLimitRPM: maxRPM + 180,
  };
}
