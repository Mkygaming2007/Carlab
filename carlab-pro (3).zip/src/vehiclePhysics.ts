import { EngineState } from "./data/modificationRules";

// Vehicle Physics State Type (Task 1)
export interface VehicleState {
  speed: number;            // in km/h
  acceleration: number;     // in m/s^2
  wheelForce: number;       // in Newtons (N)
  dragForce: number;        // in Newtons (N)
  rollingResistance: number; // in Newtons (N)
}

// Gearbox configuration with standard sports gear ratios (Task 6)
export const VEHICLE_GEAR_RATIOS = [0, 3.45, 2.12, 1.45, 1.10, 0.89, 0.72]; // index 0 = Neutral
export const VEHICLE_FINAL_DRIVE = 3.9;
export const VEHICLE_WHEEL_RADIUS = 0.32; // In meters

// Torque to linear wheel force conversion (Task 2)
export function calculateWheelForce(
  engineState: EngineState,
  gearRatio: number,
  finalDrive: number,
  wheelRadius: number,
  throttle: number,
  rpm: number,
  maxRPM: number
): number {
  if (gearRatio === 0) return 0;
  
  // Parabolic torque output efficiency representing torque curve peaked at 4000 RPM
  const torqueEfficiency = Math.max(0.3, 1.0 - Math.pow((rpm - 4000) / (maxRPM * 0.55), 2));
  const engineTorque = engineState.torque * torqueEfficiency * throttle;
  
  // Convert Engine Torque to Wheel Torque via active gear ratio & final drive ratio
  const wheelTorque = engineTorque * gearRatio * finalDrive * 0.94; // 94% transmission mechanical efficiency
  
  // Linear Force (F = Torque / Radius)
  return wheelTorque / wheelRadius;
}

// Calculate resistance forces: Aerodynamic Drag & Rolling Resistance (Task 3)
export function calculateResistanceForces(
  speedKmh: number,
  weight: number,
  dragCoefficient: number = 0.32,
  frontalArea: number = 2.1
) {
  const speedMs = speedKmh / 3.6;
  
  // Aero drag force: F_drag = 0.5 * Cd * A * rho * v^2
  const airDensity = 1.225; // kg/m^3
  const k = 0.5 * dragCoefficient * frontalArea * airDensity;
  const dragForce = k * speedMs * speedMs;
  
  // Rolling resistance force: F_rolling = Cr * m * g
  const rollingCoefficient = 0.015; // standard tire on asphalt
  const rollingResistance = rollingCoefficient * weight * 9.81;

  return { dragForce, rollingResistance };
}

// Update vehicle speed and physics state (Task 4 & 5)
export function updateVehicle(
  currentState: VehicleState,
  dt: number,
  wheelForce: number,
  dragForce: number,
  rollingResistance: number,
  mass: number,
  brakingForce: number = 0
): VehicleState {
  const currentSpeedMs = currentState.speed / 3.6;
  const isMoving = currentSpeedMs > 0.01;

  // Resistance forces are active only when vehicle is in motion
  const activeDrag = isMoving ? dragForce : 0;
  const activeRolling = isMoving ? rollingResistance : 0;
  const activeBraking = isMoving ? brakingForce : 0;

  // Sum of linear forces (Task 4)
  const totalNetForce = wheelForce - activeDrag - activeRolling - activeBraking;
  const acceleration = totalNetForce / mass;

  // Integration to update velocity
  let nextSpeedMs = currentSpeedMs + acceleration * dt;
  if (nextSpeedMs < 0) {
    nextSpeedMs = 0;
  }

  // Convert speed back to km/h with terminal velocity clamp of 380 km/h
  const nextSpeedKmh = Math.min(380, nextSpeedMs * 3.6);

  return {
    speed: nextSpeedKmh,
    acceleration,
    wheelForce,
    dragForce,
    rollingResistance,
  };
}

// Calculate mechanical engine RPM locked with wheel speed (Task 6)
export function calculateRPMFromSpeed(
  speedKmh: number,
  gearRatio: number,
  finalDrive: number,
  wheelRadius: number,
  idleRPM: number = 850
): number {
  if (gearRatio === 0) return idleRPM;
  
  const speedMs = speedKmh / 3.6;
  const wheelRps = speedMs / (2 * Math.PI * wheelRadius);
  const rpm = wheelRps * gearRatio * finalDrive * 60;
  
  return Math.max(idleRPM, rpm);
}
