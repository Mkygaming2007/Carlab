import { useEffect, useRef, useState } from "react";
import { CarPlatform } from "./data/carDatabase";
import { EngineState } from "./data/modificationRules";
import { ExhaustSynthEngine } from "./data/ExhaustSynthEngine";
import {
  VehicleState,
  VEHICLE_GEAR_RATIOS,
  VEHICLE_FINAL_DRIVE,
  VEHICLE_WHEEL_RADIUS,
  calculateWheelForce,
  calculateResistanceForces,
  updateVehicle,
  calculateRPMFromSpeed,
} from "./vehiclePhysics";
import {
  AccelerationRun,
  QuarterMileRun,
  updateAccelerationRun,
  updateQuarterMile,
} from "./dynoSystem";
import {
  EngineHealth,
  createInitialHealth,
  updateEngineHealth,
} from "./engineHealth";

// Maintain backward compatibility for exports
export const GEAR_RATIOS = VEHICLE_GEAR_RATIOS;

export function useEngineController(
  car: CarPlatform,
  engineState: EngineState,
  audioEngine: ExhaustSynthEngine | null,
  parentIgnition?: boolean,
  onToggleIgnition?: () => void
) {
  // State variables for react UI binding
  const [rpm, setRpm] = useState(parentIgnition !== undefined ? (parentIgnition ? 850 : 0) : 850);
  const [throttle, setThrottleState] = useState(0);
  const [gear, setGear] = useState(1); // 1-6, 0 = Neutral
  const [speed, setSpeed] = useState(0); // km/h
  const [isClipped, setIsClipped] = useState(false); // limiter bounce spark cut
  const [isShifting, setIsShifting] = useState(false);
  const [clutchActive, setClutchActive] = useState(false);
  const [ignitionOn, setIgnitionOn] = useState(parentIgnition !== undefined ? parentIgnition : true);
  const [boost, setBoost] = useState(0);

  // Performance runs state
  const [accelerationRun, setAccelerationRun] = useState<AccelerationRun>({
    startTime: null,
    endTime: null,
    timeTo100: null,
    isActive: false,
  });

  const [quarterMileRun, setQuarterMileRun] = useState<QuarterMileRun>({
    startTime: null,
    endTime: null,
    elapsedTime: null,
    trapSpeed: null,
    distance: 0,
    isActive: false,
  });

  const [health, setHealth] = useState<EngineHealth>(createInitialHealth());

  // Use refs for the animation loop to access immediate hot values without frame stutters
  const stateRef = useRef({
    rpm: parentIgnition !== undefined ? (parentIgnition ? 850 : 0) : 850,
    throttle: 0,
    targetThrottle: 0,
    gear: 1,
    speed: 0, // in km/h
    isShifting: false,
    clutchActive: false,
    ignitionOn: parentIgnition !== undefined ? parentIgnition : true,
    lastTime: performance.now(),
    limiterCutTimer: 0,
    shiftTimer: 0,
    boost: 0,
    braking: false,
    elapsedSec: 0,
    accelerationRun: {
      startTime: null,
      endTime: null,
      timeTo100: null,
      isActive: false,
    } as AccelerationRun,
    quarterMileRun: {
      startTime: null,
      endTime: null,
      elapsedTime: null,
      trapSpeed: null,
      distance: 0,
      isActive: false,
    } as QuarterMileRun,
    engineHealth: createInitialHealth() as EngineHealth,
  });

  // Track dependencies
  const carRef = useRef(car);
  const engineStateRef = useRef(engineState);
  const audioEngineRef = useRef(audioEngine);

  useEffect(() => {
    carRef.current = car;
  }, [car]);

  useEffect(() => {
    engineStateRef.current = engineState;
  }, [engineState]);

  useEffect(() => {
    audioEngineRef.current = audioEngine;
  }, [audioEngine]);

  // Setters updating both React state and Hot simulation references
  const setThrottle = (val: number) => {
    const clamped = Math.max(0, Math.min(1, val));
    stateRef.current.targetThrottle = clamped;
    setThrottleState(clamped);
  };

  const setBraking = (val: boolean) => {
    stateRef.current.braking = val;
  };

  const shiftUp = () => {
    if (stateRef.current.isShifting || stateRef.current.gear >= 6) return;
    triggerGearShift(stateRef.current.gear + 1);
  };

  const shiftDown = () => {
    if (stateRef.current.isShifting || stateRef.current.gear <= 1) return;
    triggerGearShift(stateRef.current.gear - 1);
  };

  const toggleNeutral = () => {
    if (stateRef.current.gear === 0) {
      stateRef.current.gear = 1;
      setGear(1);
    } else {
      stateRef.current.gear = 0;
      setGear(0);
    }
  };

  const toggleIgnition = () => {
    if (onToggleIgnition) {
      onToggleIgnition();
      return;
    }
    const nextIgnition = !stateRef.current.ignitionOn;
    stateRef.current.ignitionOn = nextIgnition;
    setIgnitionOn(nextIgnition);
    if (!nextIgnition) {
      stateRef.current.rpm = 0;
      setRpm(0);
      stateRef.current.speed = 0;
      setSpeed(0);
      stateRef.current.boost = 0;
      setBoost(0);
    } else {
      stateRef.current.rpm = 850;
      setRpm(850);
    }
  };

  // Sync with parent ignition states
  useEffect(() => {
    if (parentIgnition !== undefined) {
      stateRef.current.ignitionOn = parentIgnition;
      setIgnitionOn(parentIgnition);
      if (!parentIgnition) {
        stateRef.current.rpm = 0;
        setRpm(0);
        stateRef.current.speed = 0;
        setSpeed(0);
        stateRef.current.boost = 0;
        setBoost(0);
      } else if (stateRef.current.rpm < 850) {
        stateRef.current.rpm = 850;
        setRpm(850);
      }
    }
  }, [parentIgnition]);

  const triggerGearShift = (targetGear: number) => {
    stateRef.current.isShifting = true;
    stateRef.current.clutchActive = true;
    stateRef.current.shiftTimer = 0.28; // 280ms clutch-in gear travel time
    setIsShifting(true);
    setClutchActive(true);

    if (audioEngineRef.current) {
      audioEngineRef.current.triggerShift();
    }

    setTimeout(() => {
      stateRef.current.gear = targetGear;
      stateRef.current.isShifting = false;
      stateRef.current.clutchActive = false;
      setGear(targetGear);
      setIsShifting(false);
      setClutchActive(false);
    }, 280);
  };

  // Main real-time simulation loop
  useEffect(() => {
    let animationFrameId: number;

    const tick = () => {
      const now = performance.now();
      const dt = Math.min(0.05, (now - stateRef.current.lastTime) / 1000); // Guard extreme frame lags
      stateRef.current.lastTime = now;

      const activeCar = carRef.current;
      const activeState = engineStateRef.current;
      const s = stateRef.current;

      const isFailsafeActive = s.engineHealth.isEngineBlown;
      const activeMaxRPM = isFailsafeActive ? 3000 : activeCar.limits.maxRPM;

      if (!s.ignitionOn) {
        s.rpm += (0 - s.rpm) * (1 - Math.exp(-6.0 * dt));
        s.speed += (0 - s.speed) * (1 - Math.exp(-0.8 * dt));
        s.boost += (0 - s.boost) * (1 - Math.exp(-8.0 * dt));
        setRpm(Math.round(s.rpm));
        setSpeed(Math.round(s.speed));
        setBoost(Number(s.boost.toFixed(2)));
        if (audioEngineRef.current) {
          audioEngineRef.current.update(s.rpm, activeCar.limits.maxRPM, s.boost, 0, false);
        }
        animationFrameId = requestAnimationFrame(tick);
        return;
      }

      // Smooth throttle response including Rev Hang simulation (Task 2 of engine controller)
      let throttleRate = s.targetThrottle > s.throttle ? 15.0 : 6.0; // slower drop = rev hang
      s.throttle += (s.targetThrottle - s.throttle) * (1 - Math.exp(-throttleRate * dt));

      // Limiter spark cut/bounce timer
      if (s.limiterCutTimer > 0) {
        s.limiterCutTimer -= dt;
        if (s.limiterCutTimer <= 0) {
          setIsClipped(false);
        }
      }

      const isHardLimiterActive = s.rpm >= activeMaxRPM + 150;
      const isSoftLimiterActive = s.rpm >= activeMaxRPM;

      if (isHardLimiterActive) {
        s.limiterCutTimer = 0.22; // Longer fuel cut action
        s.rpm = activeMaxRPM - 650 - Math.random() * 150; // sharp drop
        setIsClipped(true);
        if (audioEngineRef.current) {
          audioEngineRef.current.triggerBackfire();
        }
      } else if (isSoftLimiterActive && s.limiterCutTimer <= 0) {
        s.limiterCutTimer = 0.11; // 110ms soft limit cuts
        s.rpm = activeMaxRPM - 350 - Math.random() * 150; // Moderate bounce
        setIsClipped(true);
        if (audioEngineRef.current) {
          audioEngineRef.current.triggerBackfire();
        }
      }

      const idleRPM = 850;
      const maxRPM = activeCar.limits.maxRPM;
      const currentRatio = VEHICLE_GEAR_RATIOS[s.gear] || 0; // 0 represents Neutral
      const isInNeutral = s.gear === 0 || s.clutchActive;

      // Update engine health real-time (Task 2 & 3)
      s.engineHealth = updateEngineHealth(
        s.engineHealth,
        s.rpm,
        maxRPM,
        s.boost,
        s.throttle,
        s.speed,
        dt
      );
      setHealth({ ...s.engineHealth });

      if (isInNeutral) {
        // Free revving block: light inertia with physical updates (Task 1 & 2)
        const engineInertia = activeCar.stock.weight * 0.008; // light scale representation
        const engineFriction = s.rpm * 0.72; // basic internal friction
        const peakTorque = activeState.torque * (isFailsafeActive ? 0.05 : 1.0);
        const torqueEfficiency = Math.max(0.3, 1.0 - Math.pow((s.rpm - 4000) / (activeMaxRPM * 0.55), 2));
        const torque = peakTorque * torqueEfficiency * (s.limiterCutTimer > 0 ? 0 : s.throttle);
        const accelForce = (torque * 32.0) - engineFriction;

        s.rpm += (accelForce / engineInertia) * dt;

        // Vehicle deceleration from resistance forces
        const resistances = calculateResistanceForces(s.speed, activeCar.stock.weight, 0.32, 2.1);
        const brakingForce = s.braking ? 4500 : 0;

        const physState = updateVehicle(
          {
            speed: s.speed,
            acceleration: 0,
            wheelForce: 0,
            dragForce: resistances.dragForce,
            rollingResistance: resistances.rollingResistance,
          },
          dt,
          0,
          resistances.dragForce,
          resistances.rollingResistance,
          activeCar.stock.weight,
          brakingForce
        );

        s.speed = physState.speed;
      } else {
        // Coupled drivetrain block utilizing our pristine vehicle physics engine (Task 7)
        const wheelForce = calculateWheelForce(
          activeState,
          currentRatio,
          VEHICLE_FINAL_DRIVE,
          VEHICLE_WHEEL_RADIUS,
          s.limiterCutTimer > 0 ? 0 : s.throttle,
          s.rpm,
          activeMaxRPM
        ) * (isFailsafeActive ? 0.05 : 1.0);

        const resistances = calculateResistanceForces(s.speed, activeCar.stock.weight, 0.32, 2.1);
        const brakingForce = s.braking ? 7500 : 0;

        const physState = updateVehicle(
          {
            speed: s.speed,
            acceleration: 0,
            wheelForce,
            dragForce: resistances.dragForce,
            rollingResistance: resistances.rollingResistance,
          },
          dt,
          wheelForce,
          resistances.dragForce,
          resistances.rollingResistance,
          activeCar.stock.weight + 80, // Dynamic weight of car + operator
          brakingForce
        );

        s.speed = physState.speed;

        // Direct mechanical locked link: Wheel Speed -> Engine RPM (Task 7)
        s.rpm = calculateRPMFromSpeed(
          s.speed,
          currentRatio,
          VEHICLE_FINAL_DRIVE,
          VEHICLE_WHEEL_RADIUS,
          idleRPM
        );

        // Constrain to failsafe redline if blown
        if (s.rpm > activeMaxRPM) {
          s.rpm = activeMaxRPM;
        }

        // Slip clutch safety at low RPMs to avoid stalling
        if (s.rpm < idleRPM) {
          s.rpm = idleRPM;
          // Slowly creep forward under idle torque
          if (s.throttle > 0.1) {
            s.speed += 1.8 * dt * 3.6; // convert creep to km/h speed
          }
        }
      }

      // Track relative session time (Task 4)
      if (s.speed > 0.1 || s.accelerationRun.isActive || s.quarterMileRun.isActive) {
        s.elapsedSec += dt;
      }

      // Real-time tracking of 0-100 and quarter mile (Task 4)
      s.accelerationRun = updateAccelerationRun(s.accelerationRun, s.speed, s.elapsedSec);
      s.quarterMileRun = updateQuarterMile(s.quarterMileRun, s.speed, dt, s.elapsedSec);

      // Calculate manifold boost
      if (activeCar.aspiration === "Turbo" && !isFailsafeActive) {
        const rpmRatio = Math.max(0, s.rpm / maxRPM);
        const targetBoost = Math.pow(rpmRatio, 2.0) * activeCar.limits.maxBoost * s.throttle;
        s.boost += (targetBoost - s.boost) * (1 - Math.exp(-2.5 * dt));
      } else {
        s.boost = 0;
      }

      // Sync React state values
      setRpm(Math.round(s.rpm));
      setSpeed(Math.round(s.speed));
      setBoost(Number(s.boost.toFixed(2)));
      setAccelerationRun(s.accelerationRun);
      setQuarterMileRun(s.quarterMileRun);

      // Call premium sound processor updates in requestAnimationFrame matching current ticks
      if (audioEngineRef.current) {
        audioEngineRef.current.updateFromState(activeState);
        audioEngineRef.current.update(
          s.rpm,
          maxRPM,
          s.boost,
          s.throttle,
          s.clutchActive || s.isShifting
        );
      }

      animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animationFrameId);
  }, []);

  const resetPerformanceRuns = () => {
    stateRef.current.elapsedSec = 0;
    stateRef.current.accelerationRun = {
      startTime: null,
      endTime: null,
      timeTo100: null,
      isActive: false,
    };
    stateRef.current.quarterMileRun = {
      startTime: null,
      endTime: null,
      elapsedTime: null,
      trapSpeed: null,
      distance: 0,
      isActive: false,
    };
    setAccelerationRun({ ...stateRef.current.accelerationRun });
    setQuarterMileRun({ ...stateRef.current.quarterMileRun });
  };

  const repairEngine = () => {
    const fresh = createInitialHealth();
    stateRef.current.engineHealth = fresh;
    setHealth(fresh);
  };

  return {
    rpm,
    throttle,
    gear,
    speed,
    isClipped,
    isShifting,
    clutchActive,
    ignitionOn,
    boost,
    accelerationRun,
    quarterMileRun,
    health,
    setThrottle,
    setBraking,
    shiftUp,
    shiftDown,
    toggleNeutral,
    toggleIgnition,
    resetPerformanceRuns,
    repairEngine,
  };
}
