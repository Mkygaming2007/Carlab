import { CarPlatform } from "./carDatabase";
import { VehicleModification } from "./modsDatabase";

export interface SerializedBuild {
  carId: string;
  modIds: string[];
  subParts?: Record<string, string>;
  stats: {
    hp: number;
    torque: number;
  };
}

export function serializeBuild(
  car: any,
  appliedMods: any[],
  engineState: any,
  subParts?: Record<string, string>
): string {
  if (!car) return "";

  const carId = typeof car === "string" ? car : car.id;
  
  // Handle both array of strings (installedModIds) and array of objects (VEHICLE_MODS_DATABASE)
  const modIds = appliedMods.map((m: any) => {
    if (typeof m === "string") return m;
    return m.id || "";
  }).filter(Boolean);

  const stats = {
    hp: engineState?.horsepower || engineState?.hp || engineState?.finalHp || 0,
    torque: engineState?.torque || engineState?.finalTorque || 0
  };

  const data: SerializedBuild = {
    carId,
    modIds,
    subParts,
    stats
  };

  try {
    const jsonStr = JSON.stringify(data);
    // Using btoa with encodeURIComponent for robust base64 encoding (supports special characters utf-8 safely)
    return btoa(encodeURIComponent(jsonStr));
  } catch (e) {
    console.error("Serialization failed:", e);
    return "";
  }
}

export function deserializeBuild(code: string): SerializedBuild | null {
  if (!code) return null;
  try {
    const decodedStr = decodeURIComponent(atob(code));
    return JSON.parse(decodedStr);
  } catch (e) {
    try {
      // Fallback base64 decoding
      const rawDecoded = atob(code);
      return JSON.parse(rawDecoded);
    } catch (err) {
      console.error("Deserialization failed:", err);
      return null;
    }
  }
}
