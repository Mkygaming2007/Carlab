export type EngineType = "i3" | "i4" | "i6" | "v6" | "v8";
export type AspirationType = "NA" | "Turbo" | "Supercharged";
export type DrivetrainType = "FWD" | "RWD" | "AWD";

export interface CarPlatform {
  id: string;
  name: string;
  brand: string;
  year: number;
  engineType: EngineType;
  aspiration: AspirationType;
  drivetrain: DrivetrainType;
  difficulty: "Easy" | "Medium" | "Hard" | "Expert";
  displacement: string;
  cylinders: number;
  description: string;
  stock: {
    hp: number;
    torque: number; // in Nm
    redline: number; // in RPM
    weight: number; // in kg
    boost?: number; // in bar (if applicable)
  };
  limits: {
    maxHP: number;
    maxBoost: number;
    maxRPM: number;
  };
  supportedMods: {
    turbo: boolean;
    supercharger: boolean;
    engineSwap: string[];
    intake: string[];
    exhaust: string[];
    ecu: boolean;
    camshaft: boolean;
    fuelSystem: boolean;
  };
}

export const VEHICLE_DATABASE: CarPlatform[] = [
  {
    id: "polo-1.0tsi",
    brand: "Volkswagen",
    name: "Polo GT 1.0 TSI",
    year: 2021,
    engineType: "i3",
    aspiration: "Turbo",
    drivetrain: "FWD",
    difficulty: "Easy",
    displacement: "1.0L",
    cylinders: 3,
    description: "Compact hot hatch with a highly tuneable 3-cylinder engine. Excellent potential for high boost levels on stock hardware.",
    stock: {
      hp: 110,
      torque: 175,
      redline: 6500,
      weight: 1072,
      boost: 1.0,
    },
    limits: {
      maxHP: 200,
      maxBoost: 1.8,
      maxRPM: 7200,
    },
    supportedMods: {
      turbo: true,
      supercharger: false,
      engineSwap: ["1.8 TSI I4", "2.0 TSI EA888"],
      intake: ["Stock", "Performance Panel Filter", "Cold Air Intake Intake Stage 1"],
      exhaust: ["Stock", "De-cat Downpipe", "Free-Flow Exhaust System"],
      ecu: true,
      camshaft: false,
      fuelSystem: true,
    },
  },
  {
    id: "swift-k12",
    brand: "Maruti Suzuki",
    name: "Swift K12",
    year: 2019,
    engineType: "i4",
    aspiration: "NA",
    drivetrain: "FWD",
    difficulty: "Medium",
    displacement: "1.2L",
    cylinders: 4,
    description: "Lightweight and rev-happy naturally aspirated layout. Perfect canvas for custom bolt-on turbo conversions.",
    stock: {
      hp: 83,
      torque: 113,
      redline: 6200,
      weight: 875,
    },
    limits: {
      maxHP: 160,
      maxBoost: 0.8,
      maxRPM: 7000,
    },
    supportedMods: {
      turbo: true,
      supercharger: false,
      engineSwap: ["Suzuki K14C Boosterjet", "Honda K20A I4"],
      intake: ["Stock", "Short Ram Intake", "Polished High-Flow Airbox"],
      exhaust: ["Stock", "4-2-1 Exhaust Headers", "Catback Exhaust System"],
      ecu: true,
      camshaft: true,
      fuelSystem: true,
    },
  },
  {
    id: "thar-2.0tgdi",
    brand: "Mahindra",
    name: "Thar 2.0 TGDi",
    year: 2022,
    engineType: "i4",
    aspiration: "Turbo",
    drivetrain: "AWD",
    difficulty: "Medium",
    displacement: "2.0L",
    cylinders: 4,
    description: "Rugged heavy offroader with a high-torque turbopetrol. Massive torque limits, constrained by conservative factory redline.",
    stock: {
      hp: 150,
      torque: 300,
      redline: 5500,
      weight: 1750,
      boost: 0.8,
    },
    limits: {
      maxHP: 280,
      maxBoost: 1.6,
      maxRPM: 6200,
    },
    supportedMods: {
      turbo: true,
      supercharger: false,
      engineSwap: ["Toyota 1UZ-FE V8", "GM LS3 V8"],
      intake: ["Stock", "Snorkel Ram-Air System", "Cold Air Intake Intake Stage 1"],
      exhaust: ["Stock", "Straight Pipe Exhaust Catback"],
      ecu: true,
      camshaft: false,
      fuelSystem: true,
    },
  },
  {
    id: "civic-1.5t",
    brand: "Honda",
    name: "Civic 1.5T",
    year: 2018,
    engineType: "i4",
    aspiration: "Turbo",
    drivetrain: "FWD",
    difficulty: "Easy",
    displacement: "1.5L",
    cylinders: 4,
    description: "Global standard of tuner cars with a versatile VTEC Turbo platform. Exceptional response to electronic boost controller mapping.",
    stock: {
      hp: 174,
      torque: 220,
      redline: 6500,
      weight: 1280,
      boost: 1.1,
    },
    limits: {
      maxHP: 320,
      maxBoost: 1.9,
      maxRPM: 7500,
    },
    supportedMods: {
      turbo: true,
      supercharger: false,
      engineSwap: ["Honda K20C1 Type R"],
      intake: ["Stock", "High Flow Intake Inlet", "Cold Air Intake Intake Stage 1"],
      exhaust: ["Stock", "Frontpipe & Catback", "Titanium Track Exhaust"],
      ecu: true,
      camshaft: true,
      fuelSystem: true,
    },
  },
  {
    id: "bmw-e46-m3",
    brand: "BMW",
    name: "M3 Coupe (E46)",
    year: 2003,
    engineType: "i6",
    aspiration: "NA",
    drivetrain: "RWD",
    difficulty: "Hard",
    displacement: "3.2L",
    cylinders: 6,
    description: "The legendary, high-revving S54 naturally-aspirated inline-6 engine. Superb track response with optional custom turbo swaps.",
    stock: {
      hp: 338,
      torque: 365,
      redline: 8000,
      weight: 1470,
    },
    limits: {
      maxHP: 620,
      maxBoost: 1.2,
      maxRPM: 9000,
    },
    supportedMods: {
      turbo: true,
      supercharger: true,
      engineSwap: ["S65 4.0L V8", "2JZ-GTE I6"],
      intake: ["Stock", "Carbon Velocity Stack Shroud", "CSL Style Airbox Intake"],
      exhaust: ["Stock", "Equal Length Equalizer Headers", "Titanium Muffler System"],
      ecu: true,
      camshaft: true,
      fuelSystem: true,
    },
  },
  {
    id: "shelby-gt500",
    brand: "Ford",
    name: "Shelby GT500",
    year: 2020,
    engineType: "v8",
    aspiration: "Supercharged",
    drivetrain: "RWD",
    difficulty: "Hard",
    displacement: "5.2L",
    cylinders: 8,
    description: "The brutal supercharged Predator crossplane V8. Unmatched exhaust signature and instant low-end torque delivery.",
    stock: {
      hp: 760,
      torque: 847,
      redline: 7500,
      weight: 1890,
      boost: 0.8,
    },
    limits: {
      maxHP: 1100,
      maxBoost: 1.5,
      maxRPM: 8200,
    },
    supportedMods: {
      turbo: false,
      supercharger: true,
      engineSwap: ["Roush Yates 5.8L V8 NASCAR Spec"],
      intake: ["Stock", "High-Flow Dry Filter", "Giant Cold Air Shroud Intake"],
      exhaust: ["Stock", "Longtube Headers & X-Pipe", "Active Valve Race Exhaust"],
      ecu: true,
      camshaft: true,
      fuelSystem: true,
    },
  },
  {
    id: "project-custom",
    brand: "Project Car",
    name: "Custom Forge Template",
    year: 2026,
    engineType: "i4",
    aspiration: "NA",
    drivetrain: "RWD",
    difficulty: "Expert",
    displacement: "2.0L",
    cylinders: 4,
    description: "A blank-sheet blueprint. Cast your own cylinder heads, specify compression, and configure custom parameters from scratch.",
    stock: {
      hp: 140,
      torque: 190,
      redline: 6800,
      weight: 1100,
    },
    limits: {
      maxHP: 500,
      maxBoost: 2.0,
      maxRPM: 9500,
    },
    supportedMods: {
      turbo: true,
      supercharger: true,
      engineSwap: ["2JZ-GTE I6", "GM LS3 V8", "EA888 Evo 4"],
      intake: ["Stock", "Stage 1 Intake", "Individual Throttle Bodies (ITBs)"],
      exhaust: ["Stock", "Catback Downpipe", "Full Drag-Spec Exhaust Mufflerless"],
      ecu: true,
      camshaft: true,
      fuelSystem: true,
    },
  },
];
