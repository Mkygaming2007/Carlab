import { CarPlatform } from "./carDatabase";

export interface EngineState {
  hp: number;
  torque: number;
  rpmLimit: number;
  boost: number; // Current maximum boost in bar
  weight: number; // in kg
  
  // Sound generation parameters (normalized or scaled)
  loudness: number;      // 0.0 to 1.5
  roughness: number;     // 0.0 to 1.5 (idle lope / rasp)
  brightness: number;    // 0.0 to 1.5 (metallic tone / high pitches)
  turboIntensity: number; // 0.0 to 1.5 (spool / blow-off-valve hiss)
  backfireRate: number;   // 0.0 to 1.0 (frequency of pops/bangs)
}

export type ModificationCategory = "turbo" | "supercharger" | "intake" | "exhaust" | "ecu" | "camshaft" | "fuel";

export interface Modification {
  id: string;
  name: string;
  description: string;
  category: ModificationCategory;
  cost: number;
  reliabilityImpact: number; // Percentage modifier
  apply: (state: EngineState, car: CarPlatform) => EngineState;
}

// Progressive gain with safety logic to reduce gains near limits and prevent unrealistic stacking
export function calculateProgression(
  currentVal: number,
  baseVal: number,
  maxLimit: number,
  targetIncrementFraction: number
): number {
  if (currentVal >= maxLimit) {
    return maxLimit;
  }
  // Calculate remaining headroom ratio (between 0.0 and 1.0)
  const headroomRatio = Math.max(0, Math.min(1, (maxLimit - currentVal) / (maxLimit - baseVal || 1)));
  // High headroom gets full boost. As you approach limits, marginal gain scales down
  // Let's use a 0.7 power curve for smooth roll-off near maximum ceiling
  const safetyFactor = Math.pow(headroomRatio, 0.7);
  const actualIncrement = targetIncrementFraction * safetyFactor;
  return currentVal * (1.0 + actualIncrement);
}

// Concrete Modifications Library with 11 advanced realistic upgrades
export const MODIFICATIONS_LIBRARY: Modification[] = [
  {
    id: "turbo-stage1",
    name: "Stage 1 Bolt-On Turbocharger",
    description: "Low-inertia dual journal bearing turbo. Quicker spooling speeds, +0.4 bar boost, and sharper induction noise.",
    category: "turbo",
    cost: 1800,
    reliabilityImpact: -5,
    apply: (state, car) => {
      const isStockTurbo = car.aspiration === "Turbo";
      const boostAdd = isStockTurbo ? 0.25 : 0.40;
      const hpGain = isStockTurbo ? 0.12 : 0.18;
      const tqGain = isStockTurbo ? 0.14 : 0.20;
      
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, hpGain),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, tqGain),
        boost: Math.min(state.boost + boostAdd, car.limits.maxBoost),
        loudness: Math.min(state.loudness + 0.05, 1.5),
        roughness: Math.min(state.roughness + 0.02, 1.5),
        brightness: Math.min(state.brightness + 0.15, 1.5),
        turboIntensity: Math.min(state.turboIntensity + 0.40, 1.5),
        backfireRate: Math.min(state.backfireRate + 0.10, 1.0),
      };
    },
  },
  {
    id: "turbo-stage2",
    name: "Stage 2 Heavy-Duty Turbocharger",
    description: "Race-grade forged billet compressor wheel. Supports up to +0.8 bar extra boost. Yields major high-rpm whistle.",
    category: "turbo",
    cost: 3500,
    reliabilityImpact: -15,
    apply: (state, car) => {
      const isStockTurbo = car.aspiration === "Turbo";
      const boostAdd = isStockTurbo ? 0.50 : 0.80;
      const hpGain = isStockTurbo ? 0.28 : 0.38;
      const tqGain = isStockTurbo ? 0.25 : 0.35;
      
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, hpGain),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, tqGain),
        boost: Math.min(state.boost + boostAdd, car.limits.maxBoost),
        loudness: Math.min(state.loudness + 0.12, 1.5),
        roughness: Math.min(state.roughness + 0.05, 1.5),
        brightness: Math.min(state.brightness + 0.25, 1.5),
        turboIntensity: Math.min(state.turboIntensity + 0.85, 1.5),
        backfireRate: Math.min(state.backfireRate + 0.35, 1.0),
      };
    },
  },
  {
    id: "supercharger-stage1",
    name: "Roots Supercharger Overdrive Porting",
    description: "Machined high-volume pulley ratio. Delivers +0.35 bar boost, producing high pitched mechanical supercharger gear whine.",
    category: "supercharger",
    cost: 2200,
    reliabilityImpact: -8,
    apply: (state, car) => {
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, 0.25),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, 0.30),
        boost: Math.min(state.boost + 0.35, car.limits.maxBoost),
        loudness: Math.min(state.loudness + 0.15, 1.5),
        roughness: Math.min(state.roughness + 0.10, 1.5),
        brightness: Math.min(state.brightness + 0.30, 1.5),
        turboIntensity: Math.min(state.turboIntensity + 0.50, 1.5), // Custom gears scream
        backfireRate: Math.min(state.backfireRate + 0.05, 1.0),
        weight: state.weight + 12,
      };
    },
  },
  {
    id: "cold-air-intake",
    name: "Stage 1 Cold Air Intake",
    description: "Thermal insulated high-flow composite intake. Lowers resistance, sharpening transient turbo spool cues.",
    category: "intake",
    cost: 450,
    reliabilityImpact: 0,
    apply: (state, car) => {
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, 0.04),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, 0.03),
        loudness: Math.min(state.loudness + 0.08, 1.5),
        roughness: Math.min(state.roughness + 0.02, 1.5),
        brightness: Math.min(state.brightness + 0.15, 1.5),
        turboIntensity: state.turboIntensity > 0 ? Math.min(state.turboIntensity + 0.05, 1.5) : 0,
        backfireRate: Math.min(state.backfireRate + 0.02, 1.0),
        weight: state.weight - 1,
      };
    },
  },
  {
    id: "high-flow-intake",
    name: "Carbon Fiber High-Velocity Shrouds",
    description: "Straight-flow open plenum filtration. Elevates cylinder induction noise and roars beautifully when flooring it.",
    category: "intake",
    cost: 950,
    reliabilityImpact: -1,
    apply: (state, car) => {
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, 0.08),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, 0.06),
        loudness: Math.min(state.loudness + 0.18, 1.5),
        roughness: Math.min(state.roughness + 0.06, 1.5),
        brightness: Math.min(state.brightness + 0.22, 1.5),
        turboIntensity: state.turboIntensity > 0 ? Math.min(state.turboIntensity + 0.12, 1.5) : 0,
        backfireRate: Math.min(state.backfireRate + 0.05, 1.0),
        weight: state.weight - 2,
      };
    },
  },
  {
    id: "catback-exhaust",
    name: "Stainless Steel Catback Muffler",
    description: "3.0-inch mandrel-bent system. Amplifies bass harmonics and releases pops during deceleration.",
    category: "exhaust",
    cost: 1100,
    reliabilityImpact: 0,
    apply: (state, car) => {
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, 0.06),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, 0.05),
        loudness: Math.min(state.loudness + 0.25, 1.5),
        roughness: Math.min(state.roughness + 0.18, 1.5),
        brightness: Math.min(state.brightness + 0.10, 1.5),
        turboIntensity: Math.min(state.turboIntensity + 0.05, 1.5),
        backfireRate: Math.min(state.backfireRate + 0.20, 1.0),
        weight: state.weight - 8,
      };
    },
  },
  {
    id: "straight-pipe-exhaust",
    name: "Titanium Straight Pipe Exhaust",
    description: "Unsilenced flow without mufflers or catalysts. Extreme volume, raw rasps, and fire-spitting backfires.",
    category: "exhaust",
    cost: 1600,
    reliabilityImpact: -2,
    apply: (state, car) => {
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, 0.12),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, 0.08),
        loudness: Math.min(state.loudness + 0.52, 1.5),
        roughness: Math.min(state.roughness + 0.38, 1.5),
        brightness: Math.min(state.brightness + 0.28, 1.5),
        turboIntensity: Math.min(state.turboIntensity + 0.10, 1.5),
        backfireRate: Math.min(state.backfireRate + 0.52, 1.0),
        weight: state.weight - 18,
      };
    },
  },
  {
    id: "ecu-stage1",
    name: "Stage 1 ECU Calibration Map",
    description: "Refined spark curve offsets and target air-to-fuel ratios. Lifts redline, unlocking immediate power.",
    category: "ecu",
    cost: 600,
    reliabilityImpact: -4,
    apply: (state, car) => {
      const targetRPMAdd = Math.min(state.rpmLimit + 300, car.limits.maxRPM);
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, 0.14),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, 0.15),
        rpmLimit: targetRPMAdd,
        loudness: Math.min(state.loudness + 0.04, 1.5),
        roughness: Math.min(state.roughness + 0.08, 1.5),
        brightness: Math.min(state.brightness + 0.05, 1.5),
        turboIntensity: Math.min(state.turboIntensity + 0.05, 1.5),
        backfireRate: Math.min(state.backfireRate + 0.20, 1.0),
      };
    },
  },
  {
    id: "ecu-stage2",
    name: "Stage 2 Pop-and-Bang Crackle Remap",
    description: "Aggressive fuel trims and timing delay. Adds constant crackles on throttle decel and lifts rpm limit.",
    category: "ecu",
    cost: 1200,
    reliabilityImpact: -12,
    apply: (state, car) => {
      const targetRPMAdd = Math.min(state.rpmLimit + 600, car.limits.maxRPM);
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, 0.24),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, 0.22),
        rpmLimit: targetRPMAdd,
        loudness: Math.min(state.loudness + 0.08, 1.5),
        roughness: Math.min(state.roughness + 0.15, 1.5),
        brightness: Math.min(state.brightness + 0.10, 1.5),
        turboIntensity: Math.min(state.turboIntensity + 0.12, 1.5),
        backfireRate: Math.min(state.backfireRate + 0.55, 1.0),
      };
    },
  },
  {
    id: "performance-camshaft",
    name: "Tomei 272° High-Lift Camshafts",
    description: "High valve duration shafts. Delivers lumpy loping idling roughness and massive top-end power.",
    category: "camshaft",
    cost: 1400,
    reliabilityImpact: -8,
    apply: (state, car) => {
      const targetRPMAdd = Math.min(state.rpmLimit + 400, car.limits.maxRPM);
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, 0.16),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, 0.06),
        rpmLimit: targetRPMAdd,
        loudness: Math.min(state.loudness + 0.12, 1.5),
        roughness: Math.min(state.roughness + 0.48, 1.5), // Severe idle lope
        brightness: Math.min(state.brightness + 0.15, 1.5),
        turboIntensity: Math.min(state.turboIntensity + 0.02, 1.5),
        backfireRate: Math.min(state.backfireRate + 0.10, 1.0),
      };
    },
  },
  {
    id: "high-pressure-fuel",
    name: "Heavy-Duty Injectors & Primary Fuel Pump",
    description: "Enhanced high-flow fueling rail. Minimizes combustion knock, stabilizing performance limits safely.",
    category: "fuel",
    cost: 850,
    reliabilityImpact: 5,
    apply: (state, car) => {
      return {
        ...state,
        hp: calculateProgression(state.hp, car.stock.hp, car.limits.maxHP, 0.05),
        torque: calculateProgression(state.torque, car.stock.torque, car.limits.maxHP * 1.1, 0.05),
        loudness: Math.min(state.loudness + 0.02, 1.5),
        roughness: Math.min(state.roughness + 0.05, 1.5),
        brightness: Math.min(state.brightness + 0.05, 1.5),
        turboIntensity: Math.min(state.turboIntensity + 0.02, 1.5),
        backfireRate: Math.min(state.backfireRate + 0.05, 1.0),
      };
    },
  },
];

export interface DSPParameters {
  masterGain: number;
  filterFreq: number;
  distortionGain: number;
  noiseGain: number;
  turboGain: number;
  turboPitchMultiplier: number;
  backfireProbability: number;
}

// TASK 2: mapEngineStateToDSP mapper
export function mapEngineStateToDSP(state: EngineState): DSPParameters {
  const safeState = state || {
    loudness: 0.55,
    brightness: 0.38,
    roughness: 0.30,
    turboIntensity: 0,
    backfireRate: 0.05
  };
  return {
    masterGain: Math.max(0, Math.min(1.5, safeState.loudness ?? 0.55)) * 0.38,
    filterFreq: 180 + Math.max(0, Math.min(1.5, safeState.brightness ?? 0.38)) * 3200, // 180Hz to 4980Hz
    distortionGain: 1.0 + Math.max(0, Math.min(1.5, safeState.roughness ?? 0.30)) * 14.0, // waveshaper amount
    noiseGain: Math.max(0, Math.min(1.5, safeState.roughness ?? 0.30)) * 0.18, // combustion friction noise
    turboGain: Math.max(0, Math.min(1.5, safeState.turboIntensity ?? 0)) * 0.32,
    turboPitchMultiplier: 1.0 + Math.max(0, Math.min(1.5, safeState.turboIntensity ?? 0)) * 0.65,
    backfireProbability: Math.max(0, Math.min(1.0, safeState.backfireRate ?? 0.05)),
  };
}

export function createBaseEngineState(car: CarPlatform): EngineState {
  const stockBoostVal = car.stock.boost !== undefined ? car.stock.boost : 0;
  
  let baseLoudness = 0.55;
  let baseRoughness = 0.30;
  let baseBrightness = 0.38;
  let baseTurboIntensity = 0.0;

  switch (car.engineType) {
    case "i3":
      baseLoudness = 0.50;
      baseRoughness = 0.45;
      baseBrightness = 0.32;
      break;
    case "i4":
      baseLoudness = 0.58;
      baseRoughness = 0.30;
      baseBrightness = 0.38;
      break;
    case "i6":
      baseLoudness = 0.62;
      baseRoughness = 0.22;
      baseBrightness = 0.48;
      break;
    case "v6":
      baseLoudness = 0.68;
      baseRoughness = 0.38;
      baseBrightness = 0.52;
      break;
    case "v8":
      baseLoudness = 0.82;
      baseRoughness = 0.60;
      baseBrightness = 0.42;
      break;
  }

  if (car.aspiration === "Turbo") {
    baseTurboIntensity = 0.30;
  } else if (car.aspiration === "Supercharged") {
    baseTurboIntensity = 0.22;
  }

  return {
    hp: car.stock.hp,
    torque: car.stock.torque,
    rpmLimit: car.stock.redline,
    boost: stockBoostVal,
    weight: car.stock.weight,
    loudness: baseLoudness,
    roughness: baseRoughness,
    brightness: baseBrightness,
    turboIntensity: baseTurboIntensity,
    backfireRate: 0.05,
  };
}

export function applyMods(baseState: EngineState, mods: Modification[], car: CarPlatform): EngineState {
  if (!baseState) return {} as EngineState;
  let finalState = { ...baseState };
  const safeMods = Array.isArray(mods) ? mods : [];
  for (const mod of safeMods) {
    if (!mod || typeof mod.apply !== 'function') continue;
    try {
      finalState = mod.apply({ ...finalState }, car);
    } catch (e) {
      console.error("Failed to apply mod:", e);
    }
  }
  return finalState;
}

export function clampToCarLimits(state: EngineState, car: CarPlatform): EngineState {
  if (!state) return {} as EngineState;
  if (!car) return state;
  return {
    ...state,
    hp: Math.min(state.hp, car.limits?.maxHP ?? 1000),
    boost: Math.min(state.boost, car.limits?.maxBoost ?? 5),
    rpmLimit: Math.min(state.rpmLimit, car.limits?.maxRPM ?? 10000),
  };
}

export function getAvailableMods(car: CarPlatform): Modification[] {
  if (!car || !car.supportedMods || !Array.isArray(MODIFICATIONS_LIBRARY)) {
    return [];
  }
  try {
    return MODIFICATIONS_LIBRARY.filter((mod) => {
      if (!mod || !mod.id) return false;
      // Stage validations
      if (mod.category === "turbo") {
        if (!car.supportedMods.turbo) return false;
      }
      
      if (mod.category === "supercharger") {
        if (!car.supportedMods.supercharger) return false;
      }

      if (mod.category === "ecu") {
        if (!car.supportedMods.ecu) return false;
      }

      if (mod.category === "camshaft") {
        if (!car.supportedMods.camshaft) return false;
      }

      if (mod.category === "fuel") {
        if (!car.supportedMods.fuelSystem) return false;
      }

      // Checking specific string requirements for parts (like matching intakes and exhausts)
      if (mod.category === "intake") {
        if (car.supportedMods.intake && car.supportedMods.intake.length > 0) {
          const isSupported = car.supportedMods.intake.some(item => 
            item && item.toLowerCase().includes("stage 1") || 
            item.toLowerCase().includes("intake") ||
            item.toLowerCase().includes("flow")
          );
          if (!isSupported) return false;
        }
      }

      if (mod.category === "exhaust") {
        if (car.supportedMods.exhaust && car.supportedMods.exhaust.length > 0) {
          const isSupported = car.supportedMods.exhaust.some(item => 
            item && item.toLowerCase().includes("catback") || 
            item.toLowerCase().includes("straight") ||
            item.toLowerCase().includes("exhaust")
          );
          if (!isSupported) return false;
        }
      }

      return true;
    });
  } catch (e) {
    return [];
  }
}
