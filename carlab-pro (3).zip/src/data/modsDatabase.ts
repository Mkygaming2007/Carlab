import { EngineType, DrivetrainType, CarPlatform } from "./carDatabase";

export type ModificationCategory =
  | "Engine"
  | "Forced Induction"
  | "Fuel System"
  | "Cooling"
  | "Exhaust"
  | "Suspension"
  | "Brakes"
  | "Wheels & Tires"
  | "Drivetrain"
  | "Aero"
  | "Interior"
  | "Exterior"
  | "Offroad";

export interface VehicleModification {
  id: string;
  name: string;
  description: string;
  category: ModificationCategory;
  minVal?: number;
  maxVal?: number;
  step?: number;
  unit?: string;
  defaultValue?: number;
  compatibleEngineTypes?: EngineType[];
  compatibleDrivetrains?: DrivetrainType[];
  compatibleVehicles?: string[]; // Car Platform IDs
  hpBonus: number;
  torqueBonus: number;
  weightImpact: number; // change in kg
  soundImpact?: {
    loudness?: number;     // e.g. +0.1
    roughness?: number;    // e.g. +0.05
    brightness?: number;   // e.g. +0.15
    backfireRate?: number; // e.g. +0.25
  };
  dependencies?: string[]; // Dependency IDs of modifications
  specs?: Record<string, string>;
}

// 1. CAR-SPECIFIC MODIFICATION CATALOG (TASK 1) & CATEGORIES (TASK 2) & REALISTIC LIMITS (TASK 3)
export const VEHICLE_MODS_DATABASE: VehicleModification[] = [
  // --- MAHINDRA THAR SPECIFIC OFFROAD MODS ---
  {
    id: "thar-lift-kit",
    name: "3-Inch Rugged Lift Kit",
    description: "Suspension lift designed specifically for the Thar. Increases ground clearance, accommodates extreme articulation, and alters body roll.",
    category: "Suspension",
    minVal: 1,
    maxVal: 4,
    step: 0.5,
    unit: "inches",
    defaultValue: 3,
    compatibleVehicles: ["thar-2.0tgdi"],
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: 35,
    specs: { "Clearance Gain": "+75mm", "Shock Absorbers": "Nitrogen Charged", "Stiffness": "+15%" }
  },
  {
    id: "thar-offroad-tires",
    name: "33-Inch BFG All-Terrain Tires",
    description: "Heavy-duty knobby tires with deep tread self-cleaning blocks. Optimizes traction on slush, gravel, and sand terrains.",
    category: "Wheels & Tires",
    minVal: 29,
    maxVal: 35,
    step: 1,
    unit: "diameter (in)",
    defaultValue: 33,
    compatibleVehicles: ["thar-2.0tgdi"],
    hpBonus: -2, // extra rolling resistance reduces effective wheel horsepower
    torqueBonus: 5,
    weightImpact: 48,
    specs: { "Compound": "Tri-Gard Layer", "Tread-Depth": "13.5mm", "Recommended PSI": "26" }
  },
  {
    id: "thar-snorkel",
    name: "Ram-Air Intake Snorkel",
    description: "Raised air intake system bypassing the front grille. Prevents hydro-locking during deep water-wading maneuvers.",
    category: "Offroad",
    compatibleVehicles: ["thar-2.0tgdi"],
    hpBonus: 3,
    torqueBonus: 2,
    weightImpact: 6,
    soundImpact: { loudness: 0.05, roughness: 0.02 },
    specs: { "Wading Height Limit": "900mm", "Material": "UV-Stable Polyethylene", "Inlet Size": "3-Inch" }
  },
  {
    id: "thar-winch",
    name: "Warn EVOlution 12,000lb Winch",
    description: "Heavy-duty electric recovery winch mounted on the bumper. Premium military-grade steel recovery cable included.",
    category: "Offroad",
    compatibleVehicles: ["thar-2.0tgdi"],
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: 38,
    specs: { "Pulling Force": "12,000 lbs", "Motor": "Series-Wound 12V", "Cable Type": "Aramid Synthetic" }
  },
  {
    id: "thar-steel-bumper",
    name: "Heavy-Duty Front Winch Bumper",
    description: "Reinforced 4mm thick structure of high-tensile steel plate. Protects radiator and recovery systems.",
    category: "Exterior",
    compatibleVehicles: ["thar-2.0tgdi"],
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: 45,
    specs: { "Material": "Dual powder-coated steel", "Approach Angle": "+8 degrees", "D-Ring Mounts": "Integrated" }
  },
  {
    id: "thar-roof-rack",
    name: "Expedition Roof Rack & Trail Lights",
    description: "Structural aluminum roof rack layout equipped with standard high-performance offroad LED spotlights.",
    category: "Exterior",
    compatibleVehicles: ["thar-2.0tgdi"],
    hpBonus: -1, // aerodynamic drag
    torqueBonus: 0,
    weightImpact: 22,
    specs: { "Static Load Capacity": "150 kg", "LED Bars Total Output": "22,000 lumens", "Aeroflow Profile": "Low Drag Utility" }
  },
  {
    id: "thar-fuel-pump",
    name: "Walbro 255 LPH High-Output Fuel Pump",
    description: "Necessary high-pressure cell modification supporting custom turbo map pressures safely.",
    category: "Fuel System",
    compatibleVehicles: ["thar-2.0tgdi"],
    hpBonus: 5,
    torqueBonus: 8,
    weightImpact: 1,
    specs: { "Flow Rate": "255 Liters Per Hour", "Terminal Junction": "Silver Alloy", "Operating Pressure": "5.5 Bar" }
  },
  {
    id: "thar-turbo-upgrade",
    name: "Garrett Stage 2 Twin-Scroll Turbo Upgrade",
    description: "Upgraded twin-scroll manifold producing lightning quick boost response, up to +0.6 bar over stock. Requires high fuel pump delivery.",
    category: "Forced Induction",
    compatibleVehicles: ["thar-2.0tgdi"],
    hpBonus: 65,
    torqueBonus: 95,
    weightImpact: 4,
    soundImpact: { loudness: 0.1, roughness: 0.05, brightness: 0.2, backfireRate: 0.15 },
    dependencies: ["thar-fuel-pump"], // Heavy turbo demands fuel! (Task 4)
    specs: { "Peak Boost": "1.4 bar", "Bearing": "Dual Ceramic Ball", "Material": "Silicon-Molybdenum Housing" }
  },
  {
    id: "thar-ecu-tune",
    name: "Redline Custom ECU Map Stage 1",
    description: "Custom ignition retard and fuel calibration maximizing low-end torque on Thar's turbopetrol profile.",
    category: "Engine",
    compatibleVehicles: ["thar-2.0tgdi"],
    hpBonus: 35,
    torqueBonus: 55,
    weightImpact: 0,
    soundImpact: { backfireRate: 0.1 },
    specs: { "Map Cycle": "Octane-95 Dynamic Tune", "Injection Timing": "Advanced 3 deg", "Wastegate Duty": "+12%" }
  },

  // --- HONDA CIVIC SPECIFIC TUNER MODS ---
  {
    id: "civic-cold-air-intake",
    name: "AEM Cold Air Induction Intake",
    description: "Mandrel-bent gunmetal aluminum pipe placing filter low in front arch for cold ambient breathing induction.",
    category: "Engine",
    compatibleVehicles: ["civic-1.5t"],
    hpBonus: 10,
    torqueBonus: 8,
    weightImpact: -3,
    soundImpact: { loudness: 0.08, brightness: 0.12 },
    specs: { "Tube Material": "Aircraft Grade 6061", "Filter Efficiency": "99.2%", "Airflow gain": "+32%" }
  },
  {
    id: "civic-exhaust-catback",
    name: "Invidia Q300 Dual Catback Exhaust",
    description: "High performance mirror polished stainless tube layout. Emits elegant mellow flat-four tuner notes.",
    category: "Exhaust",
    compatibleVehicles: ["civic-1.5t"],
    hpBonus: 12,
    torqueBonus: 10,
    weightImpact: -7,
    soundImpact: { loudness: 0.22, roughness: 0.15, backfireRate: 0.15 },
    specs: { "Piping Diameter": "70mm", "Muffler Tips": "101mm Blue Titanium", "Noise Certified": "dB-95" }
  },
  {
    id: "civic-upgraded-fuel-injector",
    name: "DeatschWerks 750cc Multi-port Injectors",
    description: "High-volume precision spray injectors. Stabilizes extra cylinders demands during extreme induction cycles.",
    category: "Fuel System",
    compatibleVehicles: ["civic-1.5t"],
    hpBonus: 8,
    torqueBonus: 12,
    weightImpact: 0.2,
    specs: { "Coil Impedance": "12.4 Ohms", "Spray Pattern": "Multi-hole Mist Jet", "Duty Threshold": "85% safe" }
  },
  {
    id: "civic-big-turbo",
    name: "Greddy T518Z Hybrid Big Turbocharger",
    description: "Massive oversized compressor assembly. Generates crazy 1.8 bar peak boost. Requires upgraded high frequency fuel delivery injectors.",
    category: "Forced Induction",
    compatibleVehicles: ["civic-1.5t"],
    hpBonus: 105,
    torqueBonus: 130,
    weightImpact: 6,
    soundImpact: { loudness: 0.18, roughness: 0.1, brightness: 0.35, backfireRate: 0.3 },
    dependencies: ["civic-upgraded-fuel-injector"], // Task 4: Big Turbo requires upgraded fuel system
    specs: { "Maximum Pressure Limit": "1.9 bar", "Trim Spec": "54 Compress / 56 Turbine", "Cooling integration": "Water/Oil Combined" }
  },
  {
    id: "civic-coilovers",
    name: "Tein Flex Z Multi-way Coilovers",
    description: "Fully adjustable twin-tube coilovers. Drops center of gravity, completely neutralizing high-speed FWD torque steer.",
    category: "Suspension",
    minVal: 10,
    maxVal: 60,
    step: 5,
    unit: "mm drop",
    defaultValue: 30,
    compatibleVehicles: ["civic-1.5t"],
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: -4,
    specs: { "Piston Size": "44mm", "Damping Adjustment": "16 clicks", "Spring Rating": "Front 6kg / Rear 4kg" }
  },
  {
    id: "civic-brake-kit",
    name: "Brembo GT 4-Piston Big Brake Kit",
    description: "Drilled high-ventilation compound discs paired with heavy clamping monoblock aluminum Brembo calipers.",
    category: "Brakes",
    compatibleVehicles: ["civic-1.5t"],
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: -2,
    specs: { "Caliper Pistons": "4 Pot", "Rotor Diameter": "345mm", "Friction Compound": "Carbon-Metallic Compound" }
  },
  {
    id: "civic-intercooler",
    name: "Mishimoto Front-Mount Intercooler Upgrade",
    description: "High-density bar-and-plate assembly. Drastically cools intake charge temperatures, keeping turbo induction safe.",
    category: "Cooling",
    compatibleVehicles: ["civic-1.5t"],
    hpBonus: 12,
    torqueBonus: 15,
    weightImpact: 8,
    specs: { "Core Core size": "610mm x 180mm x 90mm", "Operating Drop": "-28 deg C", "Slat Spec": "Straight Air-Fin" }
  },
  {
    id: "civic-ecu-tune-stage2",
    name: "Hondata FlashPro Stage 2 Custom ECU Map",
    description: "Extremist tuning logic. Optimizes high heat thresholds, ignition spark maps, and releases severe anti-lag exhaust pops. Requires high flow airbox intake + catback exhaust.",
    category: "Engine",
    compatibleVehicles: ["civic-1.5t"],
    hpBonus: 45,
    torqueBonus: 50,
    weightImpact: 0,
    soundImpact: { loudness: 0.1, backfireRate: 0.45 },
    dependencies: ["civic-cold-air-intake", "civic-exhaust-catback"], // Task 4: Stage 2 ECU requires intake + exhaust
    specs: { "Redline Modification": "+800 RPM", "Crackle Rate": "High", "Boost Profile": "Dynamic Target Map" }
  },

  // --- BMW E46 M3 TRACK SPECIFIC MODERN MODS ---
  {
    id: "e46-csl-airbox",
    name: "Karbonius Carbon Fibre S54 CSL Airbox",
    description: "Visually spectacular direct copy S54 intake chamber. Creates the iconic roaring, deep metallic S54 induction scream.",
    category: "Engine",
    compatibleVehicles: ["bmw-e46-m3"],
    hpBonus: 22,
    torqueBonus: 18,
    weightImpact: -6,
    soundImpact: { loudness: 0.35, roughness: 0.2, brightness: 0.45 },
    specs: { "Material": "Sartorial Carbon Fiber autoclaved", "Internal Volume": "11.2 Liters", "Trumpet Layout": "CNC Machined Aluminum" }
  },
  {
    id: "e46-equal-length-headers",
    name: "Superprint Equal Length Stepped Headers",
    description: "Long-tube tuned equalizer headers eliminating high RPM back-pressures, maximizing high frequency sound waves.",
    category: "Exhaust",
    compatibleVehicles: ["bmw-e46-m3"],
    hpBonus: 18,
    torqueBonus: 15,
    weightImpact: -8,
    soundImpact: { loudness: 0.28, roughness: 0.18, brightness: 0.15 },
    specs: { "Internal diameter": "42mm to 48mm stepped", "Material": "High Titanium-grade 304L", "Wall thickness": "1.5mm" }
  },
  {
    id: "e46-track-exhaust",
    name: "Eisenmann Titanium Track Exhaust Muffler",
    description: "Lightweight titanium straight muffler loops. Releases raw high-rev inline six metal rasps.",
    category: "Exhaust",
    compatibleVehicles: ["bmw-e46-m3"],
    hpBonus: 12,
    torqueBonus: 8,
    weightImpact: -14,
    soundImpact: { loudness: 0.42, roughness: 0.22, brightness: 0.3, backfireRate: 0.22 },
    specs: { "System Weight": "8.8 kg", "Noise Target": "102dB Racing", "Tips Layout": "Quad 76mm custom polished" }
  },
  {
    id: "e46-camshafts",
    name: "Schrick 288/280 Sport Engine Camshaft Profile",
    description: "Long-duration track profile. Delivers highly aggressive lumpy S54 idle loops and massive top-end breathing peaks.",
    category: "Engine",
    compatibleVehicles: ["bmw-e46-m3"],
    hpBonus: 32,
    torqueBonus: 12,
    weightImpact: 0,
    soundImpact: { roughness: 0.55 },
    specs: { "Cam Duration": "288° Intake / 280° Exhaust", "Max Valve Lift": "12.5mm", "Vanos compatibility": "Fully Supported Sport" }
  },
  {
    id: "e46-itb-tune",
    name: "Epic Motorsports Custom Alpha-N ITB Tune",
    description: "Eliminates standard MAF restriction to run speed-density mapping directly. Exceptional S54 mechanical response and sharp throttle response.",
    category: "Engine",
    compatibleVehicles: ["bmw-e46-m3"],
    hpBonus: 28,
    torqueBonus: 24,
    weightImpact: -1.5,
    soundImpact: { loudness: 0.15, brightness: 0.1 },
    dependencies: ["e46-csl-airbox"], // Task 4: Alpha-N ITB tune requires S54 induction intake airbox!
    specs: { "Calibration Logic": "Load mapping Alpha-N based", "Fuel Adjust": "+8.5% Rich", "Max RPM target": "8,700 RPM" }
  },
  {
    id: "e46-differential",
    name: "OS Giken Super Lock 1.5-Way LSD",
    description: "High accuracy multi-row locking differential. Converts E46 track exits into absolute rear-wheel launch points.",
    category: "Drivetrain",
    compatibleVehicles: ["bmw-e46-m3"],
    hpBonus: 0,
    torqueBonus: 15, // effective driven wheel torque increase
    weightImpact: 2,
    specs: { "Clutch Plates": "24 plates combined", "Lock Rate": "Gradual progressive lock", "Oil Spec": "75W-140 Premium" }
  },
  {
    id: "e46-coilovers",
    name: "KW Suspension Variant 3 Track Coilovers",
    description: "Handcrafted monotube coilovers with independent rebound and dynamic high/low compression adjustment.",
    category: "Suspension",
    minVal: 10,
    maxVal: 50,
    step: 2,
    unit: "mm drop",
    defaultValue: 25,
    compatibleVehicles: ["bmw-e46-m3"],
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: -3,
    specs: { "Shock Construction": "Stainless Steel 'Inox-line'", "Rebound clicks": "16 clicks", "Bumptravel clicks": "12 clicks" }
  },

  // --- FORD SHELBY GT500 MONSTER SUPERCHARGERS ---
  {
    id: "gt500-pulley-upgrade",
    name: "Lingenfelter 2.7-Inch Direct Drive Pulley Upgrade",
    description: "Smaller supercharger blower pulley resulting in faster rotation. Adds +3.5 PSI (+0.25 bar) extra boost and major low end whine.",
    category: "Engine",
    compatibleVehicles: ["shelby-gt500"],
    hpBonus: 45,
    torqueBonus: 60,
    weightImpact: -0.5,
    soundImpact: { loudness: 0.15, brightness: 0.25 },
    specs: { "Pulley Diameter": "2.70 Inches", "Ratio Boost Gain": "3.5 PSI", "Belt length required": "Standard minus 1.2 inches" }
  },
  {
    id: "gt500-fuel-upgrade",
    name: "Fore Innovations Triple-Pump Fuel Hangar",
    description: "Three parallel pumps delivery platform. Eradicates fuel starvation danger under extreme supercharger boost curves.",
    category: "Fuel System",
    compatibleVehicles: ["shelby-gt500"],
    hpBonus: 10,
    torqueBonus: 10,
    weightImpact: 3,
    specs: { "Fuel Pumps": "3x TI Automotive F90000274", "Lines spec": "PTFE braided steel", "Supply capacity": "1500 HP" }
  },
  {
    id: "gt500-heat-exchanger",
    name: "Whipple Dual-Pass Aluminum Heat Exchanger",
    description: "High ventilation front dual radiator. Essential for cooling intense hot high air pressures pushed by massive supercharger volumes.",
    category: "Cooling",
    compatibleVehicles: ["shelby-gt500"],
    hpBonus: 18,
    torqueBonus: 22,
    weightImpact: 12,
    specs: { "Radiator Volume": "Triple core thickness", "Thermo Fans": "Twin high speed 11-Inch", "Fluid Temperature reduction": "-18 deg C" }
  },
  {
    id: "gt500-supercharger-upgrade",
    name: "Whipple Gen-V 3.8L Twin-Screw Supercharger Upgrade",
    description: "Enormous 3.8L displacement supercharger assembly. Yields colossal +0.6 bar boost, creating earth-shattering torque. Requires cooling heat exchanger upgrade and triple pump fuel system.",
    category: "Forced Induction",
    compatibleVehicles: ["shelby-gt500"],
    hpBonus: 210,
    torqueBonus: 260,
    weightImpact: 28,
    soundImpact: { loudness: 0.35, roughness: 0.1, brightness: 0.5 },
    dependencies: ["gt500-heat-exchanger", "gt500-fuel-upgrade"], // Task 4: Large supercharger requires cooling upgrade/fuel
    specs: { "Displacement": "3.8 Liters", "Boost Limit Configuration": "1.7 Bar Bar Pressures", "Screws Core": "Teflon Coupled rotors" }
  },
  {
    id: "gt500-long-headers",
    name: "Kooks 2-Inch Long Tube Titanium Headers",
    description: "Immense long tube headers bypassing close stock catalysts. Emits an absolute screaming, thundering V8 exhaust wave.",
    category: "Exhaust",
    compatibleVehicles: ["shelby-gt500"],
    hpBonus: 38,
    torqueBonus: 40,
    weightImpact: -18,
    soundImpact: { loudness: 0.5, roughness: 0.35, backfireRate: 0.35 },
    specs: { "Collector diameter": "3.5-inch with scavenge spike", "Titanium Grade": "602", "Gasket sealing": "Graphite multi-layer" }
  },
  {
    id: "gt500-drag-pack",
    name: "Mickey Thompson Grid ET Drag Pack",
    description: "Super light forged rear beadlock wheels wrapped in specialized sticky competition drag radial slicks.",
    category: "Wheels & Tires",
    compatibleVehicles: ["shelby-gt500"],
    hpBonus: 0,
    torqueBonus: 45, // huge traction efficiency boost
    weightImpact: -12,
    specs: { "Carcass": "Bias-Ply radial", "Rear Rims size": "15x10 Forged Beadlock", "Optimal Temp Sweep": "80-95 deg C" }
  },

  // --- GENERAL / OTHER CARS COMMON CATEGORY STABLE ---
  {
    id: "common-stage1-ecu",
    name: "DynoTech Custom ECU Remap Map Stage 1",
    description: "Base spark map timing advances, fuel ratio adjustments and minor wastegate limit lifts. Unlocks generic baseline hardware potential.",
    category: "Engine",
    compatibleEngineTypes: ["i3", "i4", "i6", "v6"],
    hpBonus: 25,
    torqueBonus: 35,
    weightImpact: 0,
    soundImpact: { backfireRate: 0.15 },
    specs: { "Air Fuel Optimization": "12.2:1 safe ratio", "Timing Offset": "+2.5 deg", "Octane Profile": "98-RON" }
  },
  {
    id: "common-stage2-carbon-intake",
    name: "Carbon Fiber Ram-Air Airbox Shroud",
    description: "High capacity dry filtering pod inside lightweight polished resin composite housing. Yields snappy throttle reaction.",
    category: "Engine",
    compatibleEngineTypes: ["i3", "i4", "i6", "v6", "v8"],
    hpBonus: 8,
    torqueBonus: 6,
    weightImpact: -3,
    soundImpact: { loudness: 0.08, brightness: 0.1 },
    specs: { "Material": "Pre-preg Carbon Fiber", "Element": "Dry multi-layer cotton syn", "Mass flow gain": "+28%" }
  },
  {
    id: "common-stage2-catback-exhaust",
    name: "Custom Mandrel Bent Track Catback Exhaust",
    description: "Lightweight fully custom tig-welded catback muffler pipe kit. Amplifies rasps and deceleration pop frequencies cleanly.",
    category: "Exhaust",
    compatibleEngineTypes: ["i3", "i4", "i6", "v6", "v8"],
    hpBonus: 15,
    torqueBonus: 12,
    weightImpact: -9,
    soundImpact: { loudness: 0.28, roughness: 0.12, backfireRate: 0.25 },
    specs: { "Tube structure": "Seamless Titanium", "Joint Seals": "Slip fit springs", "dB Rating": "98dB active" }
  },
  {
    id: "common-racing-brakes",
    name: "EBC Sport Drilled Carbon Brake Rotors",
    description: "Grooved discs with high biting performance ceramic pads. Virtually eliminates brake fade.",
    category: "Brakes",
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: -4,
    specs: { "Rotors construction": "G3000 Carbon-Iron Casting", "Pad material": "Kevlar-Reinforced Ceramic", "Bite factor": "0.48Mu" }
  },
  {
    id: "common-light-wheels",
    name: "Enkei RPF1 Lightweight Tuner Wheels",
    description: "Ultra-lightweight wheels reducing unsprung rotating mass for outstanding cornering agility and transient weight shift response.",
    category: "Wheels & Tires",
    hpBonus: 0,
    torqueBonus: 5,
    weightImpact: -18,
    specs: { "Manufacturing": "MAT rotary extrusion forged", "Size": "18x9.5 Racing", "Weight per rim": "7.9 kg" }
  },
  {
    id: "common-track-coilovers",
    name: "BC Racing Custom Track Dampers & Coilovers",
    description: "Coilover springs featuring complete strut adjustment thresholds, supporting sharp camber alignment needs.",
    category: "Suspension",
    minVal: 10,
    maxVal: 45,
    step: 5,
    unit: "mm drop",
    defaultValue: 20,
    compatibleEngineTypes: ["i3", "i4", "i6", "v6", "v8"],
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: -5,
    specs: { "Piston": "53mm oversized strut", "Adjustment clicks": "30 point click adjustment", "Damping structure": "Monotube High Press" }
  },
  {
    id: "common-carbon-splitter",
    name: "Underbody Venturi Rear Diffuser & Front Splitter",
    description: "Structural carbon aero kit creating vacuum underbody pressures for high-speed tracking stabilization.",
    category: "Aero",
    hpBonus: -2, // slightly higher drag coefficient
    torqueBonus: 0,
    weightImpact: 8,
    specs: { "Downforce at 160km/h": "+85 kg", "Material": "Carbon fiber weave honeycomb", "Mounting": "Chassis-mounted support pins" }
  },
  {
    id: "common-racing-seats",
    name: "Recaro Pole Position Fiberglass Bucket Seats",
    description: "Deep, comfortable racing bucket seat holding driver shoulders and hips. Shaves major interior cabin weight.",
    category: "Interior",
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: -25,
    specs: { "Shell": "Glass fiber-reinforced plastic", "Weight per seat": "7.0 kg", "Harness Guide": "4/5/6 multi point config" }
  },
  {
    id: "common-carbon-hood",
    name: "Dry Carbon Vented Thermo Bonnet Hood",
    description: "Extremely light carbon hood layout featuring thermal extract vents right over hot exhaust manifolds.",
    category: "Exterior",
    hpBonus: 0,
    torqueBonus: 0,
    weightImpact: -12,
    specs: { "Weight Reduction vs Steel": "62% drop", "Heat Scavenge coefficient": "+35%", "Seals": "Integrated rain hood plates" }
  }
];

// Task 4: Dependency engine
export interface DependencyCheckResult {
  passes: boolean;
  missing: { id: string; name: string }[];
}

export function checkModificationDependencies(
  mod: VehicleModification,
  installedIds: string[],
  visited: Set<string> = new Set()
): DependencyCheckResult {
  if (!mod || !mod.id) {
    return { passes: false, missing: [] };
  }

  // Prevent circular dependency
  if (visited.has(mod.id)) {
    return { passes: false, missing: [] };
  }
  visited.add(mod.id);

  if (!mod.dependencies || !Array.isArray(mod.dependencies) || mod.dependencies.length === 0) {
    return { passes: true, missing: [] };
  }

  const missing: { id: string; name: string }[] = [];
  for (const depId of mod.dependencies) {
    if (!depId) continue;
    if (!installedIds.includes(depId)) {
      const depMod = VEHICLE_MODS_DATABASE.find((m) => m && m.id === depId);
      missing.push({
        id: depId,
        name: depMod ? depMod.name : depId,
      });
    } else {
      // Recursively check installed dependencies downstream for missing components or circular references
      const depMod = VEHICLE_MODS_DATABASE.find((m) => m && m.id === depId);
      if (depMod) {
        const subResult = checkModificationDependencies(depMod, installedIds, new Set(visited));
        if (!subResult.passes) {
          missing.push(...subResult.missing);
        }
      }
    }
  }

  // Deduplicate result missing entries
  const uniqueMissing = missing.filter((item, index, self) =>
    self.findIndex(t => t.id === item.id) === index
  );

  return {
    passes: uniqueMissing.length === 0,
    missing: uniqueMissing,
  };
}

// Check compatibility of a modification with a given vehicle (Task 3)
export function checkModCompatibility(
  mod: VehicleModification,
  car: CarPlatform
): { compatible: boolean; reason?: string } {
  if (!mod || !mod.id) {
    return { compatible: false, reason: "Invalid modification" };
  }
  if (!car || !car.id) {
    return { compatible: false, reason: "Invalid car reference" };
  }

  // 1. Vehicle specific constraint
  if (mod.compatibleVehicles && mod.compatibleVehicles.length > 0) {
    if (!mod.compatibleVehicles.includes(car.id)) {
      return {
        compatible: false,
        reason: `Engineered specifically for the brand's ${car.brand} custom layout (${mod.compatibleVehicles.join(", ")})`
      };
    }
  }

  // 2. EngineType constraint
  if (mod.compatibleEngineTypes && mod.compatibleEngineTypes.length > 0) {
    if (!mod.compatibleEngineTypes.includes(car.engineType)) {
      return {
        compatible: false,
        reason: `Requires cylinder arrangement type: ${mod.compatibleEngineTypes.join(", ").toUpperCase()}`
      };
    }
  }

  // 3. Drivetrain constraint
  if (mod.compatibleDrivetrains && mod.compatibleDrivetrains.length > 0) {
    if (!mod.compatibleDrivetrains.includes(car.drivetrain)) {
      return {
        compatible: false,
        reason: `Requires drivetrain transmission layout: ${mod.compatibleDrivetrains.join(", ")}`
      };
    }
  }

  return { compatible: true };
}

// Task 5: Scalable application helper to map currently applied mods metrics
export function applySelectedModsToEngine(
  baseState: { hp: number; torque: number; weight: number; loudness: number; roughness: number; brightness: number; backfireRate: number },
  installedMods: VehicleModification[]
): {
  hpAdd: number;
  torqueAdd: number;
  weightImpact: number;
  soundImpact: {
    loudness: number;
    roughness: number;
    brightness: number;
    backfireRate: number;
  };
} {
  let hpAdd = 0;
  let torqueAdd = 0;
  let weightImpact = 0;
  let loudnessAdd = 0;
  let roughnessAdd = 0;
  let brightnessAdd = 0;
  let backfireRateAdd = 0;

  for (const mod of installedMods) {
    if (!mod) continue;
    hpAdd += (mod.hpBonus ?? 0);
    torqueAdd += (mod.torqueBonus ?? 0);
    weightImpact += (mod.weightImpact ?? 0);

    if (mod.soundImpact) {
      if (mod.soundImpact.loudness) loudnessAdd += mod.soundImpact.loudness;
      if (mod.soundImpact.roughness) roughnessAdd += mod.soundImpact.roughness;
      if (mod.soundImpact.brightness) brightnessAdd += mod.soundImpact.brightness;
      if (mod.soundImpact.backfireRate) backfireRateAdd += mod.soundImpact.backfireRate;
    }
  }

  return {
    hpAdd,
    torqueAdd,
    weightImpact,
    soundImpact: {
      loudness: loudnessAdd,
      roughness: roughnessAdd,
      brightness: brightnessAdd,
      backfireRate: backfireRateAdd,
    },
  };
}
