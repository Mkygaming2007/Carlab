import { CarPlatform } from "./carDatabase";
import { EngineState, mapEngineStateToDSP } from "./modificationRules";

export class ExhaustSynthEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private activeCar: CarPlatform | null = null;
  
  // Real-time physical simulation values
  private currentRPM: number = 800;
  private currentThrottle: number = 0;
  private currentBoost: number = 0;
  
  // Tasks state tracking
  private smoothedRPM: number = 800;
  private smoothedBoost: number = 0;
  private prevThrottle: number = 0;
  private lastUpdateTime: number = 0;
  private lastBovTime: number = 0;
  private lastPopTime: number = 0;
  private popCooldown: number = 300;
  
  // DSP parameters matching state
  private baseGain: number = 0.20;
  
  // Web Audio Graph Nodes (Allocated ONCE)
  private masterGainNode: GainNode | null = null;
  private biquadFilterNode: BiquadFilterNode | null = null;
  private waveshaperNode: WaveShaperNode | null = null;
  
  // Oscillators for rich engine harmonics
  private oscillators: OscillatorNode[] = [];
  private oscillatorGains: GainNode[] = [];
  private numOscillators = 6;
  
  // White noise generator node for combustion gas friction
  private noiseSource: AudioBufferSourceNode | null = null;
  private gasNoiseGain: GainNode | null = null;
  private gasNoiseFilter: BiquadFilterNode | null = null;
  
  // Mechanical tappet clicking node
  private tickOscillator: OscillatorNode | null = null;
  private tickGain: GainNode | null = null;
  
  // Turbo layer nodes (spool / blow-off)
  private turboWhistleOsc: OscillatorNode | null = null;
  private turboWhistleGain: GainNode | null = null;
  private turboWhistleFilter: BiquadFilterNode | null = null;
  
  // Supercharger layer nodes
  private scWhineOsc: OscillatorNode | null = null;
  private scWhineGain: GainNode | null = null;
  
  // Low Frequency Oscillator for wobble & asymmetry
  private pitchLfo: OscillatorNode | null = null;
  private pitchLfoGain: GainNode | null = null;

  constructor() {
    this.initAudioContext();
  }

  private initAudioContext() {
    if (this.ctx) return;
    
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      
      this.ctx = new AudioContextClass();
      const t = this.ctx.currentTime;
      
      // Node Graph Structure
      this.masterGainNode = this.ctx.createGain();
      this.masterGainNode.gain.setValueAtTime(this.isMuted ? 0 : this.baseGain, t);
      
      this.biquadFilterNode = this.ctx.createBiquadFilter();
      this.biquadFilterNode.type = "lowpass";
      this.biquadFilterNode.frequency.setValueAtTime(800, t);
      this.biquadFilterNode.Q.setValueAtTime(3.5, t);
      
      this.waveshaperNode = this.ctx.createWaveShaper();
      this.waveshaperNode.curve = this.createDistortionCurve(16);
      
      // Hook up master chain: oscillators/noise -> waveshaper -> biquadFilter -> masterGain -> destination
      this.waveshaperNode.connect(this.biquadFilterNode);
      this.biquadFilterNode.connect(this.masterGainNode);
      this.masterGainNode.connect(this.ctx.destination);
      
      // Initialize Harmonical Oscillators (ONE TIME CREATION)
      for (let i = 0; i < this.numOscillators; i++) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        
        // Hybrid shapes to introduce acoustic overtones and metallic rasp over clean signals
        osc.type = i === 0 ? "sawtooth" : i % 2 === 0 ? "sawtooth" : "triangle";
        osc.frequency.setValueAtTime(40 * (i + 1), t);
        gain.gain.setValueAtTime(0, t);
        
        osc.connect(gain);
        gain.connect(this.waveshaperNode);
        osc.start(0);
        
        this.oscillators.push(osc);
        this.oscillatorGains.push(gain);
      }
      
      // Initialize persistent White Noise Buffer for combustion air velocity
      const sampleRate = this.ctx.sampleRate;
      const bufferSize = sampleRate * 2.0; // 2 seconds loop
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, sampleRate);
      const channelData = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        channelData[i] = Math.random() * 2.0 - 1.0;
      }
      
      this.noiseSource = this.ctx.createBufferSource();
      this.noiseSource.buffer = noiseBuffer;
      this.noiseSource.loop = true;
      
      this.gasNoiseGain = this.ctx.createGain();
      this.gasNoiseGain.gain.setValueAtTime(0, t);
      
      this.gasNoiseFilter = this.ctx.createBiquadFilter();
      this.gasNoiseFilter.type = "bandpass";
      this.gasNoiseFilter.frequency.setValueAtTime(450, t);
      this.gasNoiseFilter.Q.setValueAtTime(1.8, t);
      
      this.noiseSource.connect(this.gasNoiseFilter);
      this.gasNoiseFilter.connect(this.gasNoiseGain);
      this.gasNoiseGain.connect(this.masterGainNode);
      this.noiseSource.start(0);
      
      // Initialize mechanical valve tap frequencies
      this.tickOscillator = this.ctx.createOscillator();
      this.tickOscillator.type = "sawtooth";
      this.tickOscillator.frequency.setValueAtTime(12, t);
      
      this.tickGain = this.ctx.createGain();
      this.tickGain.gain.setValueAtTime(0, t);
      
      const tickFilter = this.ctx.createBiquadFilter();
      tickFilter.type = "bandpass";
      tickFilter.frequency.setValueAtTime(3200, t);
      
      this.tickOscillator.connect(this.tickGain);
      this.tickGain.connect(tickFilter);
      tickFilter.connect(this.masterGainNode);
      this.tickOscillator.start(0);
      
      // Initialize Turbo Spooling whistle
      this.turboWhistleOsc = this.ctx.createOscillator();
      this.turboWhistleOsc.type = "sine";
      this.turboWhistleOsc.frequency.setValueAtTime(800, t);
      
      this.turboWhistleGain = this.ctx.createGain();
      this.turboWhistleGain.gain.setValueAtTime(0, t);
      
      this.turboWhistleFilter = this.ctx.createBiquadFilter();
      this.turboWhistleFilter.type = "highpass";
      this.turboWhistleFilter.frequency.setValueAtTime(1200, t);
      
      this.turboWhistleOsc.connect(this.turboWhistleGain);
      this.turboWhistleGain.connect(this.turboWhistleFilter);
      this.turboWhistleFilter.connect(this.masterGainNode);
      this.turboWhistleOsc.start(0);
      
      // Initialize Supercharger Whine
      this.scWhineOsc = this.ctx.createOscillator();
      this.scWhineOsc.type = "triangle";
      this.scWhineOsc.frequency.setValueAtTime(600, t);
      
      this.scWhineGain = this.ctx.createGain();
      this.scWhineGain.gain.setValueAtTime(0, t);
      
      const scHighpass = this.ctx.createBiquadFilter();
      scHighpass.type = "highpass";
      scHighpass.frequency.setValueAtTime(800, t);
      
      this.scWhineOsc.connect(this.scWhineGain);
      this.scWhineGain.connect(scHighpass);
      scHighpass.connect(this.masterGainNode);
      this.scWhineOsc.start(0);
      
      // LFO for V8 lope wobble or i3 unbalanced ignition
      this.pitchLfo = this.ctx.createOscillator();
      this.pitchLfo.type = "sine";
      this.pitchLfo.frequency.setValueAtTime(6.5, t);
      
      this.pitchLfoGain = this.ctx.createGain();
      this.pitchLfoGain.gain.setValueAtTime(0, t);
      
      this.pitchLfo.connect(this.pitchLfoGain);
      this.pitchLfo.start(0);
      
    } catch (e) {
      console.error("Failed to boot ExhaustSynthEngine nodes:", e);
    }
  }

  private createDistortionCurve(amount: number): Float32Array {
    const k = Math.max(1, amount);
    const n_samples = 44100;
    const curve = new Float32Array(n_samples);
    const deg = Math.PI / 180;
    for (let i = 0; i < n_samples; ++i) {
      const x = (i * 2) / n_samples - 1;
      curve[i] = ((3 + k) * x * 20 * deg) / (Math.PI + k * Math.abs(x));
    }
    return curve;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGainNode && this.ctx) {
      const target = muted ? 0 : this.baseGain;
      this.masterGainNode.gain.setValueAtTime(target, this.ctx.currentTime);
    }
  }

  public toggleMute() {
    this.setMuted(!this.isMuted);
  }

  public getMuted() {
    return this.isMuted;
  }

  public start(car: CarPlatform, subParts?: Record<string, string>, hasTurbo: boolean = false) {
    this.activeCar = car;
    this.initAudioContext();
    
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
    
    this.smoothedRPM = 800;
    this.smoothedBoost = 0;
    this.lastUpdateTime = performance.now();
    
    this.recalibrateSound(car, subParts || {}, hasTurbo);
  }

  public recalibrateSound(car: CarPlatform, subParts: Record<string, string>, hasTurbo: boolean) {
    this.activeCar = car;
    this.initAudioContext();
    if (!this.ctx) return;
    
    const t = this.ctx.currentTime;
    
    // Evaluate custom parts weight/loudness modifiers
    const isExhaustStock = !subParts.catbackDiameter || subParts.catbackDiameter === "stock";
    const isManifoldStock = !subParts.manifoldType || subParts.manifoldType === "stock";
    const isValveStock = !subParts.exhaustValve || subParts.exhaustValve === "stock";
    const isCamStock = !subParts.camshaft || subParts.camshaft === "stock";
    const isEcuStock = !subParts.ecuVariant || subParts.ecuVariant === "stock";
    const isStock = isExhaustStock && isManifoldStock && isValveStock && isCamStock && isEcuStock;
    
    let loudnessOffset = 0.15;
    if (subParts.catbackDiameter === "titanium-3.5") loudnessOffset += 0.20;
    else if (subParts.catbackDiameter === "edelstahl-3.0") loudnessOffset += 0.10;
    if (subParts.exhaustValve === "active-bypass") loudnessOffset += 0.15;
    if (subParts.camshaft === "tomei-272") loudnessOffset += 0.08;
    
    this.baseGain = isStock ? 0.08 : 0.19 + loudnessOffset;
    if (this.masterGainNode && !this.isMuted) {
      this.masterGainNode.gain.setValueAtTime(this.baseGain, t);
    }
  }

  public updateRPM(rpm: number) {
    if (!this.activeCar) return;
    this.update(
      rpm,
      this.activeCar.limits.maxRPM,
      this.currentBoost,
      this.currentThrottle,
      false
    );
  }

  public update(
    rpm: number,
    maxRPM: number,
    boost: number,
    throttle: number = 0,
    clutchState?: number | boolean
  ) {
    this.currentRPM = rpm;
    this.currentThrottle = throttle;
    this.currentBoost = boost;
    
    if (!this.ctx || !this.activeCar) return;
    
    const isShifting = typeof clutchState === 'boolean' ? clutchState : clutchState !== undefined && clutchState > 0.5;
    const t = this.ctx.currentTime;
    
    // TASK 2: DELTA-TIME CALCULATION & ENGINE INERTIA MODEL
    const nowPerformance = performance.now();
    if (this.lastUpdateTime === 0) {
      this.lastUpdateTime = nowPerformance;
    }
    const dt = Math.min(0.1, (nowPerformance - this.lastUpdateTime) / 1000); // Max 100ms clamps
    this.lastUpdateTime = nowPerformance;
    
    // Simulate asymmetric engine inertia & rev hang during throttle let-off
    let inertiaRate = 14.0;
    if (throttle < 0.1 && this.smoothedRPM > rpm) {
      // Slow throttle release decays slower (rev hang)
      inertiaRate = isShifting ? 4.5 : 2.8;
    } else if (throttle > 0.75 && this.smoothedRPM < rpm) {
      // Rapid poke spools revs quickly
      inertiaRate = 18.0;
    }
    this.smoothedRPM += (rpm - this.smoothedRPM) * (1 - Math.exp(-inertiaRate * dt));
    const smoothRpmRatio = Math.max(0, Math.min(1, this.smoothedRPM / maxRPM));
    
    // TASK 3: EXPONENTIAL BOOST SPOOL MODEL & TURBO LAG
    const spoolThreshold = 2200;
    const boostOverage = Math.max(0, this.smoothedRPM - spoolThreshold);
    const rpmSpoolRatio = Math.max(0, Math.min(1, boostOverage / (maxRPM - spoolThreshold)));
    // Exponential curve of spooling building up
    const targetBoostCurve = Math.pow(rpmSpoolRatio, 2.2) * boost * throttle;
    
    // Turbo builds pressure slower than direct load drop dumps it
    const spoolRate = targetBoostCurve > this.smoothedBoost ? 2.4 : 4.8;
    const prevBoost = this.smoothedBoost;
    this.smoothedBoost += (targetBoostCurve - this.smoothedBoost) * (1 - Math.exp(-spoolRate * dt));
    
    // PRESSURE RELEASE DETECTION (BOV & Flutter Trigger)
    const throttleDiff = this.prevThrottle - throttle;
    const nowMs = Date.now();
    if (throttleDiff > 0.35 && prevBoost > 0.20 && (nowMs - this.lastBovTime > 650)) {
      this.triggerBlowoffValveWithLevel(prevBoost);
      this.lastBovTime = nowMs;
      this.smoothedBoost *= 0.15; // sudden pressure relief
    }
    
    // TASK 4: IMPROVED ROAD-INSPIRED STATEFUL POPS AND BANGS
    const canPop = throttleDiff > 0.38 && this.smoothedRPM > 2600 && (nowMs - this.lastPopTime > this.popCooldown);
    if (canPop) {
      this.popCooldown = 220 + Math.random() * 580; // random cooling gap between 220-800ms
      this.lastPopTime = nowMs;
      
      const isEcStage2 = maxRPM > 6400;
      const numExplosions = Math.floor(1 + Math.random() * (isEcStage2 ? 3 : 2));
      for (let i = 0; i < numExplosions; i++) {
        const popDelay = i * (70 + Math.random() * 110);
        setTimeout(() => {
          if (this.ctx && !this.isMuted) {
            const intensity = 0.5 + Math.random() * 0.7;
            const duration = 0.08 + Math.random() * 0.14;
            this.triggerDetailedBackfire(intensity, duration);
          }
        }, popDelay);
      }
    }
    
    // Save previous throttle state
    this.prevThrottle = throttle;
    
    // TASK 1: TIMING INSTABILITY & ENGINE CHARACTER PROFILES
    let enginePitchMultiplier = 1.0;
    if (this.activeCar.engineType === "i3") enginePitchMultiplier = 1.15;
    else if (this.activeCar.engineType === "i4") enginePitchMultiplier = 1.00;
    else if (this.activeCar.engineType === "i6") enginePitchMultiplier = 1.25;
    else if (this.activeCar.engineType === "v6") enginePitchMultiplier = 1.35;
    else if (this.activeCar.engineType === "v8") enginePitchMultiplier = 0.81;
    
    const fundamentalFreq = (this.smoothedRPM / 60) * (this.activeCar.cylinders / 2) * enginePitchMultiplier;
    
    // Introduce micro-fluctuations & unstable low-cylinder timing wobble
    let timingJitter = 0;
    const microVar = Math.sin(t * 45.0) * 0.003; // basic FM micro-variation
    
    if (this.activeCar.engineType === "i3") {
      timingJitter = (Math.sin(t * 32.0) * 0.035) + (Math.random() - 0.5) * 0.02;
    } else if (this.activeCar.engineType === "i4") {
      timingJitter = (Math.sin(t * 18.0) * 0.009) + (Math.random() - 0.5) * 0.006;
    } else if (this.activeCar.engineType === "v8") {
      timingJitter = (Math.sin(t * 15.0) * 0.012) + (Math.random() - 0.5) * 0.008;
    }
    
    const jitteredFundamental = fundamentalFreq * (1.0 + timingJitter + microVar);
    
    // TASK 5: LOAD-BASED SOUND VARIATION
    const loadStrength = throttle;
    const isAccelerating = throttle > 0.42;
    
    // TASK 1 & 6: HARMONIC OVERTONES AND BANK AMPLITUDE FORMATIONS
    for (let i = 0; i < this.numOscillators; i++) {
      const pOsc = this.oscillators[i];
      const pGain = this.oscillatorGains[i];
      if (!pOsc || !pGain) continue;
      
      let harmonicRatio = i + 1;
      
      // Distinct metallic resonance adjustments for Inline-6
      if (this.activeCar.engineType === "i6") {
        if (i === 1) harmonicRatio = 1.48; // micro-detuned fifths
        if (i === 3) harmonicRatio = 4.49;
      }
      
      // Inject slight frequency spread per individual overtone
      const spread = (i * 0.0015) * Math.sin(t * 12.0 * harmonicRatio);
      pOsc.frequency.setTargetAtTime(jitteredFundamental * harmonicRatio * (1.0 + spread), t, 0.04);
      
      let targetVol = 0.06;
      if (i === 0) targetVol = 0.20; // Heavy base displacement hum
      else if (i === 1) targetVol = 0.14; // Secondary throat rasp
      else if (i === 2) targetVol = 0.09;
      else if (i === 3) targetVol = 0.05;
      
      // Cruising vs Accelerating structural curves
      const soundCurve = isAccelerating ? (0.5 + (smoothRpmRatio * 0.5)) : (0.35 + (smoothRpmRatio * 0.3));
      let finalOscVol = targetVol * (0.35 + (loadStrength * 0.65)) * soundCurve;
      
      // Profile specifics: i3 lawnmower rowdy odd harmonics, i4 standard flat hum
      if (this.activeCar.engineType === "i3") {
        const oddBoost = (i % 2 !== 0) ? 1.4 : 0.8;
        finalOscVol *= oddBoost;
      }
      
      // Profile specifics: V8 crossplane lumpy amplitude modulation
      if (this.activeCar.engineType === "v8") {
        const lopeHz = 7.5 + (smoothRpmRatio * 9.5);
        const lumpyMod = 0.68 + 0.32 * Math.sin(t * lopeHz * Math.PI) * Math.sin(t * (lopeHz * 0.5) * Math.PI);
        finalOscVol *= lumpyMod;
      }
      
      if (isShifting) {
        finalOscVol *= 0.12;
      }
      
      pGain.gain.setTargetAtTime(finalOscVol, t, 0.04);
    }
    
    // Wavefolder & Distortion curves mapping under throttle (Roughness + Loudness)
    let dynamicDistort = 1.5 + (loadStrength * 12.0);
    if (this.activeCar.engineType === "v8") {
      dynamicDistort += 4.5; // deeper guttural growling
    } else if (this.activeCar.engineType === "i3") {
      dynamicDistort += 2.0; // raspy unrefined bark
    }
    if (this.waveshaperNode) {
      this.waveshaperNode.curve = this.createDistortionCurve(dynamicDistort);
    }
    
    // Swept high-pass brightness filter
    // Low throttle results in warm insulated low frequency; hard throttle fully opens the pipe screamer
    let filterFrequency = 450 + (smoothRpmRatio * 2200) * (0.35 + (loadStrength * 0.65));
    if (this.activeCar.engineType === "i6") {
      filterFrequency += 550; // crisp header ringing
    }
    if (this.biquadFilterNode) {
      this.biquadFilterNode.frequency.setTargetAtTime(Math.min(8500, filterFrequency), t, 0.06);
    }
    
    // Friction Gas/Combustion noise tracking
    if (this.gasNoiseGain && this.gasNoiseFilter) {
      const gasPitch = 160 + (smoothRpmRatio * 440) + (loadStrength * 150);
      this.gasNoiseFilter.frequency.setTargetAtTime(gasPitch, t, 0.05);
      
      const gasVol = 0.001 + (smoothRpmRatio * 0.040) + (loadStrength * 0.016);
      this.gasNoiseGain.gain.setTargetAtTime(gasVol, t, 0.04);
    }
    
    // Mechanical valve ticking layers (Prominent at low-load cruise, masked at high-load accel)
    if (this.tickOscillator && this.tickGain) {
      const valvePeriod = 8 + (smoothRpmRatio * 82);
      this.tickOscillator.frequency.setTargetAtTime(valvePeriod, t, 0.04);
      
      const tickVol = 0.014 * (1.0 - (loadStrength * 0.45));
      this.tickGain.gain.setTargetAtTime(tickVol, t, 0.04);
    }
    
    // Turbo Charger Whistle or Supercharger constant Whine Layer
    if (this.activeCar.aspiration === "Turbo" && this.turboWhistleOsc && this.turboWhistleGain) {
      const turboPitch = 800 + (smoothRpmRatio * 2200) + (this.smoothedBoost * 720);
      this.turboWhistleOsc.frequency.setTargetAtTime(turboPitch, t, 0.04);
      
      const turboVolume = isShifting ? 0.001 : Math.min(0.09, 0.001 + (smoothRpmRatio * 0.04) + (this.smoothedBoost * 0.04));
      this.turboWhistleGain.gain.setTargetAtTime(turboVolume, t, 0.05);
    } else if (this.turboWhistleGain) {
      this.turboWhistleGain.gain.setTargetAtTime(0, t, 0.04);
    }
    
    const isSupercharged = this.activeCar.aspiration === "Supercharged";
    if (isSupercharged && this.scWhineOsc && this.scWhineGain) {
      // Direct gear-bound supercharger scream, tracks engine crankshaft 1:1
      const scPitch = 380 + (smoothRpmRatio * 2500);
      this.scWhineOsc.frequency.setTargetAtTime(scPitch, t, 0.03);
      
      const scVolume = isShifting ? 0.001 : Math.min(0.07, 0.002 + (smoothRpmRatio * 0.02) + (loadStrength * 0.04));
      this.scWhineGain.gain.setTargetAtTime(scVolume, t, 0.04);
    } else if (this.scWhineGain) {
      this.scWhineGain.gain.setTargetAtTime(0, t, 0.04);
    }
  }

  public updateFromState(state: EngineState) {
    if (!this.ctx) return;
    
    const dsp = mapEngineStateToDSP(state);
    const t = this.ctx.currentTime;
    
    if (this.biquadFilterNode) {
      this.biquadFilterNode.frequency.setTargetAtTime(dsp.filterFreq, t, 0.08);
    }
    
    if (this.waveshaperNode) {
      this.waveshaperNode.curve = this.createDistortionCurve(dsp.distortionGain);
    }
    
    if (this.gasNoiseGain) {
      this.gasNoiseGain.gain.setTargetAtTime(dsp.noiseGain, t, 0.08);
    }
    
    this.baseGain = dsp.masterGain;
    if (this.masterGainNode && !this.isMuted) {
      this.masterGainNode.gain.setTargetAtTime(this.baseGain, t, 0.08);
    }
  }

  private triggerBlowoffValveWithLevel(boostAmount: number) {
    if (!this.ctx || this.isMuted || !this.masterGainNode) return;
    
    // High boost level triggers flutter compressor surge ("sututut")
    if (boostAmount > 1.25) {
      this.triggerCompressorSurge(boostAmount);
    } else {
      this.triggerClassicHiss(boostAmount);
    }
  }

  private triggerCompressorSurge(boostAmount: number) {
    if (!this.ctx || this.isMuted || !this.masterGainNode) return;
    const t = this.ctx.currentTime;
    try {
      const bufferSize = this.ctx.sampleRate * 0.65;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const chData = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        chData[i] = Math.random() * 2.0 - 1.0;
      }
      
      const nSrc = this.ctx.createBufferSource();
      nSrc.buffer = noiseBuffer;
      
      const flt = this.ctx.createBiquadFilter();
      flt.type = "bandpass";
      flt.frequency.setValueAtTime(2200, t);
      flt.Q.setValueAtTime(3.8, t);
      
      const gn = this.ctx.createGain();
      
      // Sutututut surge envelopes mapping
      const surgeHz = 14.5;
      const surgeDuration = 0.55;
      const step = 0.01;
      for (let delay = 0; delay < surgeDuration; delay += step) {
        const dScale = Math.exp(-6.2 * delay);
        const lfoOsc = 0.58 + 0.42 * Math.sin(2 * Math.PI * surgeHz * delay);
        gn.gain.setValueAtTime(0.32 * boostAmount * dScale * lfoOsc, t + delay);
      }
      gn.gain.setValueAtTime(0.001, t + surgeDuration);
      
      nSrc.connect(flt);
      flt.connect(gn);
      gn.connect(this.masterGainNode);
      nSrc.start(t);
      nSrc.stop(t + surgeDuration + 0.02);
    } catch (e) {}
  }

  private triggerClassicHiss(boostAmount: number) {
    if (!this.ctx || this.isMuted || !this.masterGainNode) return;
    const t = this.ctx.currentTime;
    try {
      const bufferSize = this.ctx.sampleRate * 0.42;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const chData = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        chData[i] = Math.random() * 2.0 - 1.0;
      }
      
      const nSrc = this.ctx.createBufferSource();
      nSrc.buffer = noiseBuffer;
      
      const flt = this.ctx.createBiquadFilter();
      flt.type = "highpass";
      flt.frequency.setValueAtTime(1600, t);
      
      const gn = this.ctx.createGain();
      gn.gain.setValueAtTime(0.24 * boostAmount, t);
      gn.gain.exponentialRampToValueAtTime(0.001, t + 0.38);
      
      nSrc.connect(flt);
      flt.connect(gn);
      gn.connect(this.masterGainNode);
      nSrc.start(t);
      nSrc.stop(t + 0.42);
    } catch (e) {}
  }

  public triggerBlowoffValve() {
    this.triggerBlowoffValveWithLevel(Math.max(0.2, this.smoothedBoost));
  }

  public triggerBackfire() {
    this.triggerDetailedBackfire(1.0, 0.15);
  }

  private triggerDetailedBackfire(intensity: number, duration: number) {
    if (!this.ctx || this.isMuted || !this.masterGainNode) return;
    const t = this.ctx.currentTime;
    try {
      // 1. Primary shockwave explosion frequency decay
      const shockwave = this.ctx.createOscillator();
      const shockGain = this.ctx.createGain();
      shockwave.type = "triangle";
      shockwave.frequency.setValueAtTime(95 + Math.random() * 45, t);
      shockwave.frequency.exponentialRampToValueAtTime(14, t + duration);
      
      shockGain.gain.setValueAtTime(0.85 * intensity, t);
      shockGain.gain.exponentialRampToValueAtTime(0.001, t + duration);
      
      shockwave.connect(shockGain);
      shockGain.connect(this.masterGainNode);
      shockwave.start(t);
      shockwave.stop(t + duration);
      
      // 2. High frequency sharp metallic snapping (muffler popping feedback)
      const crack = this.ctx.createOscillator();
      const crackGain = this.ctx.createGain();
      crack.type = "sawtooth";
      crack.frequency.setValueAtTime(420 + Math.random() * 280, t);
      crack.frequency.exponentialRampToValueAtTime(22, t + 0.05);
      
      crackGain.gain.setValueAtTime(0.65 * intensity, t);
      crackGain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
      
      crack.connect(crackGain);
      crackGain.connect(this.masterGainNode);
      crack.start(t);
      crack.stop(t + 0.07);
      
      // 3. High velocity hot gas noise crackle
      const burstSize = this.ctx.sampleRate * duration;
      const noiseBuffer = this.ctx.createBuffer(1, burstSize, this.ctx.sampleRate);
      const chData = noiseBuffer.getChannelData(0);
      for (let i = 0; i < burstSize; i++) {
        chData[i] = Math.random() * 2.0 - 1.0;
      }
      const bSrc = this.ctx.createBufferSource();
      bSrc.buffer = noiseBuffer;
      
      const bFlt = this.ctx.createBiquadFilter();
      bFlt.type = "bandpass";
      bFlt.frequency.setValueAtTime(1100, t);
      bFlt.Q.setValueAtTime(2.2, t);
      
      const bGain = this.ctx.createGain();
      bGain.gain.setValueAtTime(0.42 * intensity, t);
      bGain.gain.exponentialRampToValueAtTime(0.001, t + duration);
      
      bSrc.connect(bFlt);
      bFlt.connect(bGain);
      bGain.connect(this.masterGainNode);
      bSrc.start(t);
      bSrc.stop(t + duration);
    } catch (e) {}
  }

  public triggerShift() {
    if (!this.ctx || this.isMuted || !this.masterGainNode) return;
    
    const t = this.ctx.currentTime;
    try {
      // Structural gear shift engagement ring
      const ring = this.ctx.createOscillator();
      const rGain = this.ctx.createGain();
      ring.type = "sine";
      ring.frequency.setValueAtTime(1580, t);
      rGain.gain.setValueAtTime(0.06, t);
      rGain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
      
      ring.connect(rGain);
      rGain.connect(this.masterGainNode);
      ring.start(t);
      ring.stop(t + 0.06);
      
      // Solid hydraulic clonk
      const clonk = this.ctx.createOscillator();
      const cGain = this.ctx.createGain();
      clonk.type = "triangle";
      clonk.frequency.setValueAtTime(180, t);
      clonk.frequency.exponentialRampToValueAtTime(32, t + 0.08);
      cGain.gain.setValueAtTime(0.22, t);
      cGain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
      
      clonk.connect(cGain);
      cGain.connect(this.masterGainNode);
      clonk.start(t);
      clonk.stop(t + 0.10);
      
      if (this.activeCar && this.activeCar.aspiration === "Turbo" && this.currentRPM > 2500) {
        this.triggerBlowoffValve();
      }
    } catch (e) {}
  }

  public stop() {
    if (this.ctx && this.ctx.state !== "closed") {
      try {
        this.ctx.close();
      } catch(e) {}
    }
    this.ctx = null;
    this.oscillators = [];
    this.oscillatorGains = [];
    this.noiseSource = null;
    this.gasNoiseGain = null;
    this.gasNoiseFilter = null;
    this.tickOscillator = null;
    this.tickGain = null;
    this.turboWhistleOsc = null;
    this.turboWhistleGain = null;
    this.scWhineOsc = null;
    this.scWhineGain = null;
    this.pitchLfo = null;
    this.pitchLfoGain = null;
  }
}
