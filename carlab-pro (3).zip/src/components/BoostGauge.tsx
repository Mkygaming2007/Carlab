import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Zap, RefreshCw, Eye } from "lucide-react";

interface BoostGaugeProps {
  boost: number;
  maxBoost: number;
}

export const BoostGauge: React.FC<BoostGaugeProps> = ({ boost, maxBoost }) => {
  const [peakBoost, setPeakBoost] = useState<number>(0);
  const decayTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Peak hold logic with a delay before slowly decaying back down
  useEffect(() => {
    if (boost > peakBoost) {
      setPeakBoost(boost);
      if (decayTimeoutRef.current) {
        clearTimeout(decayTimeoutRef.current);
      }
      // Hold peak boost for 2.5 seconds before allowing slow downward adaptation
      decayTimeoutRef.current = setTimeout(() => {
        // Slow decay interval
        const interval = setInterval(() => {
          setPeakBoost((prev) => {
            if (boost >= prev - 0.05) {
              clearInterval(interval);
              return prev;
            }
            return Math.max(boost, Number((prev - 0.04).toFixed(2)));
          });
        }, 100);
      }, 2500);
    }
  }, [boost, peakBoost]);

  const resetPeak = () => {
    setPeakBoost(0);
  };

  const boostRatio = maxBoost > 0 ? Math.min(1.0, Math.max(0, boost / maxBoost)) : 0;
  const peakRatio = maxBoost > 0 ? Math.min(1.0, Math.max(0, peakBoost / maxBoost)) : 0;

  // Gauge angles for visual indicator needle
  const startAngle = -120;
  const endAngle = 120;
  const totalAngle = endAngle - startAngle;

  const currentAngle = startAngle + boostRatio * totalAngle;
  const peakAngle = startAngle + peakRatio * totalAngle;

  return (
    <div 
      className="bg-slate-950/90 border border-slate-900 rounded-2xl p-5 flex flex-col justify-between h-full relative overflow-hidden shadow-2xl" 
      id="induction-boost-gauge"
    >
      {/* Dynamic neon vector light backgrounds */}
      <div className="absolute top-0 right-0 p-8 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header telemetry info bar */}
      <div className="flex justify-between items-center border-b border-slate-900 pb-3 mb-4">
        <div>
          <span className="text-[8px] font-mono font-black text-cyan-400 block uppercase tracking-widest">Forced Induction Induction</span>
          <h4 className="text-sm font-black font-mono text-slate-100 uppercase tracking-tight">Boost Pressure</h4>
        </div>
        <button
          onClick={resetPeak}
          className="text-[8.5px] font-mono text-slate-500 hover:text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer transition"
        >
          <RefreshCw className="w-3 h-3" />
          Reset Peak
        </button>
      </div>

      {/* Circular interactive Gauge */}
      <div className="relative flex flex-col items-center justify-center p-2">
        <div className="relative w-40 h-40 flex items-center justify-center">
          
          {/* Gauge path markers */}
          <svg className="absolute inset-0 w-full. h-full overflow-visible">
            {/* Background Arch Track */}
            <circle
              cx="80" cy="80" r="64"
              fill="none" stroke="#0e1324" strokeWidth="6"
              strokeDasharray="301.59"
              strokeDashoffset="100.53"
              strokeLinecap="round"
              className="origin-center transform rotate-[150deg]"
            />

            {/* Cyan boost indicator level */}
            <circle
              cx="80" cy="80" r="64"
              fill="none" stroke="url(#cyanGlowGrad)" strokeWidth="8"
              strokeDasharray="301.59"
              strokeDashoffset={301.59 - (201.06 * boostRatio)}
              strokeLinecap="round"
              className="origin-center transform rotate-[150deg] transition-all duration-75 ease-out"
            />

            <defs>
              <linearGradient id="cyanGlowGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0891b2" />
                <stop offset="100%" stopColor="#22d3ee" />
              </linearGradient>
            </defs>
          </svg>

          {/* Central status indicators and peak numbers */}
          <div className="z-10 text-center flex flex-col items-center">
            <span className="text-[8px] font-mono text-slate-500 uppercase tracking-widest font-black block">MANIFOLD</span>
            <span className="text-3xl font-extrabold font-mono text-cyan-400 tracking-tighter">
              {boost.toFixed(2)}
            </span>
            <span className="text-[8.5px] font-mono text-slate-400 uppercase tracking-wide">BAR</span>

            {/* Peak hold stats bar snippet */}
            <span className="text-[8px] font-mono text-slate-500 mt-1 uppercase">
              PEAK: <span className="text-rose-400 font-black">{peakBoost.toFixed(2)} BAR</span>
            </span>
          </div>

          {/* Precision current Needle representation */}
          <div 
            className="absolute bottom-1/2 left-1/2 w-1.5 h-16 origin-bottom transform -translate-x-1/2 -translate-y-full transition-transform duration-75 ease-out pointer-events-none"
            style={{ transform: `translateX(-50%) rotate(${currentAngle}deg)` }}
          >
            <div className="w-1 h-full rounded-full bg-cyan-400 bg-opacity-90 shadow-[0_0_10px_rgba(34,211,238,0.5)]" />
          </div>

          {/* Peak needle tick marker */}
          <div 
            className="absolute bottom-1/2 left-1/2 w-1 h-16 origin-bottom transform -translate-x-1/2 -translate-y-full transition-transform duration-300 ease-out pointer-events-none"
            style={{ transform: `translateX(-50%) rotate(${peakAngle}deg)` }}
          >
            <div className="w-0.5 h-4 rounded-full bg-rose-500 absolute top-0" />
          </div>

        </div>
      </div>

      {/* Numerical linear scale markers */}
      <div className="mt-2.5 pt-2.5 border-t border-slate-900/60 flex items-center justify-between text-[8px] font-mono text-slate-500 uppercase">
        <span>0.0 BAR (VACUUM)</span>
        <span className="text-cyan-400 font-bold">STAGE: {boost > 0.8 * maxBoost ? "BOOST SCALED" : boost > 0.3 * maxBoost ? "SPOOLING" : "IDLE"}</span>
        <span>{maxBoost.toFixed(1)} BAR MAX</span>
      </div>

    </div>
  );
};
