import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Share2, Copy, Check, QrCode, ClipboardCheck } from "lucide-react";
import { serializeBuild } from "../data/shareSystem";

interface ShareBuildButtonProps {
  car: any;
  installedModIds: string[];
  engineState: any;
  subParts?: Record<string, string>;
  variant?: "compact" | "full";
}

export const ShareBuildButton: React.FC<ShareBuildButtonProps> = ({
  car,
  installedModIds,
  engineState,
  subParts,
  variant = "full"
}) => {
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);

  // Generate share code and full URL
  const shareCode = serializeBuild(car, installedModIds, engineState, subParts);
  const shareUrl = `${window.location.origin}${window.location.pathname}?build=${shareCode}`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      // Fallback for iframe environments or unsupported clipboards
      const tempInput = document.createElement("input");
      tempInput.value = shareUrl;
      document.body.appendChild(tempInput);
      tempInput.select();
      document.execCommand("copy");
      document.body.removeChild(tempInput);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(shareUrl)}&color=a855f7&bgcolor=020617`;

  if (variant === "compact") {
    return (
      <div className="flex gap-2">
        <button
          onClick={handleCopyLink}
          className="px-3 py-1.5 rounded-lg bg-purple-950/45 hover:bg-purple-900/60 border border-purple-800/40 text-purple-200 text-[10px] font-mono font-bold uppercase transition flex items-center gap-1.5 cursor-pointer shadow-sm relative overflow-hidden"
          title="Copy shareable link"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Share Config</span>
            </>
          )}
        </button>

        <button
          onClick={() => setShowQr(!showQr)}
          className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 transition cursor-pointer"
          title="Show QR Code"
        >
          <QrCode className="w-3.5 h-3.5" />
        </button>

        {/* Floating QR Modal overlay */}
        <AnimatePresence>
          {showQr && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowQr(false)}
                className="fixed inset-0 bg-slate-950/80 z-50 cursor-pointer"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 10 }}
                className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-64 bg-slate-950 border border-purple-900/60 rounded-2xl p-5 shadow-2xl flex flex-col items-center text-center gap-4"
              >
                <div>
                  <h4 className="text-xs font-black font-mono text-purple-400 uppercase tracking-widest">BUILD TUNER SCAN</h4>
                  <p className="text-[9px] font-mono text-slate-400 mt-0.5 uppercase">Scan with mobile to port build</p>
                </div>
                <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                  <img
                    src={qrImageUrl}
                    alt="QR Code"
                    className="w-40 h-40 rounded"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <button
                  onClick={() => setShowQr(false)}
                  className="w-full py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded font-mono text-[9px] uppercase border border-slate-800 cursor-pointer transition"
                >
                  Close Tuner QR
                </button>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/40 border border-purple-500/10 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 relative overflow-hidden">
      <div className="absolute top-0 right-0 p-8 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />
      
      <div className="flex items-center gap-2.5">
        <div className="p-2 bg-purple-950/30 border border-purple-800/30 rounded-lg text-purple-400 shrink-0">
          <Share2 className="w-4 h-4" />
        </div>
        <div>
          <span className="text-[8px] font-mono font-black text-purple-400 uppercase tracking-widest block">Config Broadcast</span>
          <h5 className="text-xs font-bold text-slate-200 leading-tight">Share active setup with builders</h5>
        </div>
      </div>

      <div className="flex items-center gap-2 w-full sm:w-auto">
        <button
          onClick={handleCopyLink}
          className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-mono text-[10px] font-bold uppercase transition shadow-[0_0_15px_rgba(168,85,247,0.3)] cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5" />
              <span>URL Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy Build URL</span>
            </>
          )}
        </button>

        <button
          onClick={() => setShowQr(true)}
          className="px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white font-mono text-[10px] uppercase transition flex items-center gap-1.5 cursor-pointer"
          title="Display QR Code"
        >
          <QrCode className="w-3.5 h-3.5 text-purple-400" />
          <span>QR</span>
        </button>
      </div>

      <AnimatePresence>
        {showQr && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowQr(false)}
              className="fixed inset-0 bg-slate-950/80 z-50 cursor-pointer"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-64 bg-slate-950 border border-purple-900/60 rounded-2xl p-5 shadow-2xl flex flex-col items-center text-center gap-4"
            >
              <div>
                <h4 className="text-xs font-black font-mono text-purple-400 uppercase tracking-widest">BUILD TUNER SCAN</h4>
                <p className="text-[9px] font-mono text-slate-400 mt-0.5 uppercase">Scan with mobile to port build</p>
              </div>
              <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                <img
                  src={qrImageUrl}
                  alt="QR Code"
                  className="w-40 h-40 rounded"
                  referrerPolicy="no-referrer"
                />
              </div>
              <button
                onClick={() => setShowQr(false)}
                className="w-full py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded font-mono text-[9px] uppercase border border-slate-800 cursor-pointer transition"
              >
                Close Tuner QR
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};
