import React from "react";
import { Timer, Zap, Milestone, RefreshCw, Activity, ArrowRight, Gauge } from "lucide-react";
import { DynoPoint, AccelerationRun, QuarterMileRun } from "../dynoSystem";
import { DynoGraph } from "./DynoGraph";
import { ShareBuildButton } from "./ShareBuildButton";

interface PerformancePanelProps {
  speed: number;
  accelerationRun: AccelerationRun;
  quarterMileRun: QuarterMileRun;
  dynoCurve: DynoPoint[];
  onReset: () => void;
  currentRpm: number;
  maxRpm: number;
  car?: any;
  installedModIds?: string[];
  subParts?: Record<string, string>;
}

export const PerformancePanel: React.FC<PerformancePanelProps> = ({
  speed,
  accelerationRun,
  quarterMileRun,
  dynoCurve,
  onReset,
  currentRpm,
  maxRpm,
  car,
  installedModIds,
  subParts,
}) => {
  // Find peak values in the generated curves for visual reference callouts
  const peakHPPoint = [...dynoCurve].sort((a, b) => b.horsepower - a.horsepower)[0];
  const peakTorquePoint = [...dynoCurve].sort((a, b) => b.torque - a.torque)[0];

  const formatTime = (time: number | null): string => {
    if (time === null) return "--:--";
    return `${time.toFixed(2)}s`;
  };

  const formatSpeed = (val: number | null): string => {
    if (val === null) return "---";
    return `${Math.round(val)} km/h`;
  };

  // Determine the performance status badges
  let statusText = "STANDING START READY";
  let statusColor = "text-emerald-400 border-emerald-800/40 bg-emerald-950/20";

  if (accelerationRun.isActive || quarterMileRun.isActive) {
    statusText = "MEASURING SPEED TRIAL...";
    statusColor = "text-amber-400 border-amber-800/40 bg-amber-950/20 animate-pulse";
  } else if (accelerationRun.timeTo100 !== null || quarterMileRun.elapsedTime !== null) {
    statusText = "RUN COMPLETE - IMMOBILE FOR RESET";
    statusColor = "text-purple-400 border-purple-800/40 bg-purple-950/20";
  }

  return (
    <div className="w-full flex flex-col gap-6" id="perf-panel-root">
      {/* Upper Status Bar & Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 bg-slate-950 rounded-xl border border-slate-800 gap-3">
        <div className="flex items-center gap-2.5">
          <Activity className="w-4 h-4 text-purple-400" />
          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block">TELEMETRY MATRIX STATUS</span>
          <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold tracking-wider border uppercase ${statusColor}`}>
            {statusText}
          </span>
        </div>
        <button
          onClick={onReset}
          className="flex items-center gap-2 py-1.5 px-4 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white rounded-lg text-xs font-mono font-bold transition duration-150 border border-slate-800 cursor-pointer self-stretch sm:self-auto justify-center"
          id="perf-reset-btn"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>RESET RACING TRIPS</span>
        </button>
      </div>

      {/* Grid displaying the Real-Time Trials */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Real-time speedometer card */}
        <div className="bg-slate-955 p-5 rounded-xl border border-slate-800 flex flex-col justify-between min-h-[140px] relative overflow-hidden bg-slate-950/40">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block">CURRENT VELOCITY</span>
              <h4 className="text-sm font-bold text-slate-200 mt-0.5">SPEEDOMETER</h4>
            </div>
            <span className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
              <Gauge className="w-4 h-4 text-cyan-400" />
            </span>
          </div>
          <div className="mt-4 flex items-baseline gap-1">
            <span className="text-4xl font-extrabold font-mono text-cyan-400 tracking-tight">
              {Math.round(speed)}
            </span>
            <span className="text-xs font-mono text-slate-500">KM/H</span>
          </div>
          <div className="mt-2 w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-cyan-400 h-full transition-all duration-75 ease-out"
              style={{ width: `${Math.min(100, (speed / 320) * 100)}%` }}
            />
          </div>
        </div>

        {/* 0-100 KM/H Acceleration Run Card */}
        <div className="bg-slate-955 p-5 rounded-xl border border-slate-800 flex flex-col justify-between min-h-[140px] relative overflow-hidden bg-slate-950/40">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block">0 - 100 KM/H RUN</span>
              <h4 className="text-sm font-bold text-slate-200 mt-0.5">ACCELERATION</h4>
            </div>
            <span className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
              <Zap className="w-4 h-4 text-amber-400 animate-pulse" />
            </span>
          </div>

          <div className="mt-4 flex items-baseline gap-1">
            {accelerationRun.isActive ? (
              <span className="text-4xl font-extrabold font-mono text-amber-300 tracking-tight animate-pulse">
                {formatTime(accelerationRun.timeTo100)}
              </span>
            ) : (
              <span className="text-4xl font-extrabold font-mono text-amber-400 tracking-tight">
                {formatTime(accelerationRun.timeTo100)}
              </span>
            )}
            <span className="text-xs font-mono text-slate-500">SECONDS</span>
          </div>

          <p className="text-[10px] text-slate-500 font-mono flex items-center gap-1.5 mt-2">
            <span>Progress:</span>
            <span className={speed >= 100 ? "text-emerald-400 font-bold" : "text-amber-400 animate-pulse"}>
              {speed >= 100 ? "100% COMPLETE" : `${Math.min(100, Math.floor(speed))}%`}
            </span>
          </p>
        </div>

        {/* Quarter Mile Drag Racing Run Card */}
        <div className="bg-slate-955 p-5 rounded-xl border border-slate-800 flex flex-col justify-between min-h-[140px] relative overflow-hidden bg-slate-950/40">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block">1/4 MILE ACCUMULATION</span>
              <h4 className="text-sm font-bold text-slate-200 mt-0.5 font-sans">402M DRAG STRIP</h4>
            </div>
            <span className="p-1.5 rounded-lg bg-slate-900 border border-slate-800">
              <Milestone className="w-4 h-4 text-purple-400" />
            </span>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2">
            <div>
              <p className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">ELAPSED TIME</p>
              <p className="text-xl font-mono font-bold text-purple-400">
                {formatTime(quarterMileRun.elapsedTime)}
              </p>
            </div>
            <div>
              <p className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">TRAP SPEED</p>
              <p className="text-xl font-mono font-bold text-cyan-400">
                {formatSpeed(quarterMileRun.trapSpeed)}
              </p>
            </div>
          </div>

          <div className="mt-2.5">
            <div className="flex justify-between text-[8px] font-mono text-slate-500 uppercase mb-0.5">
              <span>Distance</span>
              <span>{Math.round(quarterMileRun.distance)} / 402m</span>
            </div>
            <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
              <div
                className="bg-purple-500 h-full transition-all duration-100 ease-out"
                style={{ width: `${Math.min(100, (quarterMileRun.distance / 402) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Advanced dyno plot sweep system */}
      <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center border-b border-slate-800 pb-3 gap-2">
          <div>
            <h3 className="text-sm font-bold font-mono text-purple-400 tracking-widest uppercase">🎙️ GRAPHIC DYNO ANALYZE WAVEFORM</h3>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">Interactive Horsepower and Torque projection matched with existing modifications.</p>
          </div>
          
          <div className="flex gap-4 text-xs font-mono ml-auto sm:ml-0">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-rose-500 block" />
              <span className="text-slate-400">Peak HP:</span>
              <span className="text-rose-400 font-bold">{peakHPPoint ? peakHPPoint.horsepower : 0} hp</span>
              <span className="text-slate-600">@{peakHPPoint ? peakHPPoint.rpm : 0} rpm</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-purple-500 block" />
              <span className="text-slate-400">Peak Torque:</span>
              <span className="text-purple-400 font-bold">{peakTorquePoint ? peakTorquePoint.torque : 0} N·m</span>
              <span className="text-slate-600">@{peakTorquePoint ? peakTorquePoint.rpm : 0} rpm</span>
            </div>
          </div>
        </div>

        {/* Custom Dynamic Dyno Graph Component replacing recharts area chart */}
        <div className="w-full">
          <DynoGraph
            dynoCurve={dynoCurve}
            currentRpm={currentRpm}
            maxRpm={maxRpm}
          />
        </div>
      </div>

      {car && installedModIds && (
        <div className="w-full">
          <ShareBuildButton
            car={car}
            installedModIds={installedModIds}
            engineState={{
              horsepower: peakHPPoint ? peakHPPoint.horsepower : 0,
              torque: peakTorquePoint ? peakTorquePoint.torque : 0
            }}
            subParts={subParts}
          />
        </div>
      )}
    </div>
  );
};
