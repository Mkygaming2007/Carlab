import React, { useMemo, useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Zap, Volume2, Flame, Sliders } from "lucide-react";

interface EngineVisualizerProps {
  rpm: number;
  maxRpm: number;
  gear: number;
  isShifting: boolean;
  throttle: number;
  isClipped: boolean;
  loudness?: number; // 0.0 - 1.0 multiplier
  roughness?: number; // 0.0 - 1.0 lumpy multi
}

export const EngineVisualizer: React.FC<EngineVisualizerProps> = ({
  rpm,
  maxRpm,
  gear,
  isShifting,
  throttle,
  isClipped,
  loudness = 0.5,
  roughness = 0.3,
}) => {
  const [lastGear, setLastGear] = useState(gear);
  const [gearShiftFlash, setGearShiftFlash] = useState(false);

  // Detect gear changes for flash/dip animation
  useEffect(() => {
    if (gear !== lastGear) {
      setGearShiftFlash(true);
      const timer = setTimeout(() => setGearShiftFlash(false), 200);
      setLastGear(gear);
      return () => clearTimeout(timer);
    }
  }, [gear, lastGear]);

  const rpmRatio = Math.min(1, Math.max(0, rpm / maxRpm));
  const isRedline = rpmRatio >= 0.88;

  // Sound reactive values
  const shakeIntensity = useMemo(() => {
    if (isClipped) return 12;
    const baseShake = roughness * 6;
    const rpmShake = rpmRatio * 4;
    return Math.max(0, baseShake + rpmShake - 2);
  }, [roughness, rpmRatio, isClipped]);

  const glowOpacity = useMemo(() => {
    return Math.max(0.1, Math.min(0.9, (rpmRatio * 0.5) + (throttle * 0.4)));
  }, [rpmRatio, throttle]);

  // Color mapping based on RPM
  const rpmColor = useMemo(() => {
    if (isClipped) return "rgb(239, 68, 68)"; // Bright solid Red
    if (rpmRatio >= 0.88) return "rgb(244, 63, 94)"; // Rose Red
    if (rpmRatio >= 0.70) return "rgb(245, 158, 11)"; // Amber
    if (rpmRatio >= 0.45) return "rgb(234, 179, 8)"; // Yellow
    if (rpmRatio >= 0.20) return "rgb(14, 165, 233)"; // Sky Blue
    return "rgb(6, 182, 212)"; // Cyan
  }, [rpmRatio, isClipped]);

  // Fire frequency based on RPM
  const fireSpeed = useMemo(() => {
    if (rpm === 0) return 0;
    return Math.max(0.04, 0.4 - (rpmRatio * 0.36)); // lower duration means faster pulse
  }, [rpm, rpmRatio]);

  return (
    <div 
      className="relative w-full bg-slate-950/90 border border-slate-900 rounded-2xl p-5 flex flex-col gap-4 overflow-hidden shadow-xl"
      id="engine-visualizer-container"
    >
      {/* Sound-reactive vibrating/glow ambient layer */}
      <div 
        className="absolute inset-0 bg-radial-gradient from-transparent to-slate-950 pointer-events-none z-0"
        style={{
          boxShadow: isRedline 
            ? `inset 0 0 ${30 + glowOpacity * 50}px rgba(239, 68, 68, ${glowOpacity * 0.25})`
            : `inset 0 0 ${20 + glowOpacity * 30}px rgba(6, 182, 212, ${glowOpacity * 0.15})`
        }}
      />

      {/* Shifting visual flash overlay */}
      <AnimatePresence>
        {gearShiftFlash && (
          <motion.div 
            initial={{ opacity: 0.8 }}
            animate={{ opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute inset-0 bg-indigo-500/20 mix-blend-screen pointer-events-none z-10"
          />
        )}
      </AnimatePresence>

      <div className="flex justify-between items-center border-b border-slate-900 pb-2.5 z-10">
        <div className="flex items-center gap-2">
          <Flame className={`w-4 h-4 ${isRedline ? "text-rose-500 animate-pulse" : "text-cyan-400"}`} />
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block font-bold">
            Real-time Acoustics & Chamber Spark Vis
          </span>
        </div>
        <div className="flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
          <span className="text-[8px] font-mono text-slate-500 uppercase">Interactive telemetry synced</span>
        </div>
      </div>

      {/* Main Reactive visualizers display box */}
      <div 
        className="relative flex flex-col md:flex-row items-center justify-around gap-6 py-2 z-10"
        style={{
          transform: shakeIntensity > 0 
            ? `translate(${(Math.random() - 0.5) * shakeIntensity}px, ${(Math.random() - 0.5) * shakeIntensity}px)`
            : "none"
        }}
      >
        {/* Piston chamber ignition spark visual */}
        <div className="flex flex-col items-center justify-center p-3 p-y bg-slate-900/50 border border-slate-900 rounded-xl w-40 h-36 relative overflow-hidden">
          <span className="text-[8px] font-mono text-slate-500 uppercase tracking-wider mb-2.5">Chamber Spark</span>
          
          <div className="flex gap-2.5 justify-center items-end h-14">
            {/* 4 separate dynamic cylinders sparking sequentially */}
            {[0, 1, 2, 3].map((cylinder) => {
              const activePulse = rpm > 0 && Math.sin((performance.now() * 0.05 * (rpm / 100)) + cylinder * Math.PI / 2) > 0.4;
              return (
                <div key={cylinder} className="flex flex-col items-center justify-end h-full">
                  <motion.div
                    animate={{
                      y: activePulse ? -12 : 0,
                      backgroundColor: activePulse ? rpmColor : "rgb(30, 41, 59)"
                    }}
                    transition={{ type: "spring", stiffness: 350, damping: 20 }}
                    className="w-4 h-8 rounded-md bg-slate-800 border border-slate-900 flex items-center justify-center relative shadow-inner"
                  >
                    {activePulse && (
                      <motion.div 
                        animate={{ scale: [1, 1.4, 0.9] }}
                        transition={{ repeat: Infinity, duration: fireSpeed }}
                        className="absolute -top-3 w-3 h-3 bg-amber-400 rounded-full blur-[1px] opacity-90"
                      />
                    )}
                  </motion.div>
                  <span className="text-[7.5px] font-mono text-slate-600 mt-1">C{cylinder + 1}</span>
                </div>
              );
            })}
          </div>

          <span className="text-[9px] text-slate-400 font-mono mt-3 uppercase tracking-tight flex items-center gap-1">
            <Zap className="w-3 h-3 text-cyan-400" />
            {(rpm / 2).toLocaleString()} ignitions/min
          </span>
        </div>

        {/* Massive interactive RPM curved sweep display */}
        <div className="relative w-44 h-44 flex items-center justify-center">
          {/* Circular dial background and levels */}
          <svg className="absolute inset-0 w-full h-full transform -rotate-90">
            {/* Background Dial track */}
            <circle
              cx="88" cy="88" r="70"
              fill="none" stroke="#101524" strokeWidth="8"
              strokeDasharray="219.9" strokeDashoffset="0"
              strokeLinecap="round"
              transform="rotate(45 88 88)"
            />
            {/* RPM visual active arc */}
            <circle
              cx="88" cy="88" r="70"
              fill="none"
              stroke={rpmColor}
              strokeWidth="9"
              strokeDasharray="329.8"
              strokeDashoffset={329.8 - (329.8 * rpmRatio * 0.75)}
              strokeLinecap="round"
              transform="rotate(135 88 88)"
              style={{ transition: "stroke-dashoffset 0.08s ease-out, stroke 0.2s ease" }}
            />
          </svg>

          {/* Central status screen */}
          <div className="text-center z-10 flex flex-col items-center justify-center">
            <span className="text-[8px] font-mono text-slate-500 uppercase tracking-widest block mb-0.5">ACOUSTIC SPEED</span>
            
            <AnimatePresence mode="popLayout">
              <motion.span 
                key={isClipped ? "clip" : "rpm-text"}
                initial={{ scale: isClipped ? 1.15 : 1 }}
                animate={{ scale: 1 }}
                className={`text-3xl font-extrabold font-mono tracking-tighter ${
                  isClipped ? "text-red-500 animate-pulse" : "text-slate-100"
                }`}
              >
                {rpm.toLocaleString()}
              </motion.span>
            </AnimatePresence>
            
            <span className="text-[9px] font-mono text-slate-400 block mt-1">
              RPM
            </span>
            {isClipped && (
              <span className="text-[7.5px] font-mono font-bold bg-red-950 text-red-400 border border-red-900 rounded px-1 mt-1 animate-pulse">
                LIMIT CUT ACTIVE
              </span>
            )}
          </div>
        </div>

        {/* Dynamic Acoustic Spectrum Bar */}
        <div className="w-full md:w-36 bg-slate-900/40 border border-slate-900 rounded-xl p-3 h-36 flex flex-col justify-between">
          <span className="text-[8px] font-mono text-slate-500 uppercase tracking-wider block text-center">FREQUENCY WAVE</span>
          
          <div className="flex justify-between items-end h-16 px-1 gap-1">
            {/* Sound Wave Bars reacting directly */}
            {Array.from({ length: 8 }).map((_, i) => {
              const frequencyOffset = Math.sin((performance.now() * 0.05 * (rpm / 100)) + i) * 0.3 + 0.7;
              const barHeight = rpm === 0 ? 4 : Math.min(100, Math.round(rpmRatio * frequencyOffset * 100));
              return (
                <div 
                  key={i} 
                  className="w-full rounded-sm transition-all duration-75"
                  style={{
                    height: `${barHeight}%`,
                    backgroundColor: rpmRatio >= 0.88 ? "rgb(239, 68, 68)" : rpmRatio >= 0.5 ? "rgb(234, 179, 8)" : "rgb(6, 182, 212)"
                  }}
                />
              );
            })}
          </div>

          <div className="flex justify-between items-center text-[8px] font-mono text-slate-400 uppercase pt-1 border-t border-slate-900">
            <span>Rough: {Math.round(roughness * 100)}%</span>
            <span>Vol: {Math.round(loudness * 100)}%</span>
          </div>
        </div>
      </div>

      {/* RPM Linear Progressive Bar across bottom */}
      <div className="w-full space-y-1 z-10">
        <div className="flex justify-between items-center text-[8.5px] font-mono text-slate-500 uppercase font-black">
          <span>RPM SPREAD</span>
          <span className="text-cyan-400">REDLINE: {Math.round(maxRpm * 0.88)}+</span>
        </div>
        <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-900 flex relative">
          <div 
            className="h-full transition-all duration-75 relative"
            style={{ 
              width: `${rpmRatio * 100}%`,
              backgroundColor: rpmColor
            }}
          >
            {/* Linear indicator highlight */}
            <div className="absolute right-0 top-0 bottom-0 w-1 bg-white opacity-40 shadow shadow-white" />
          </div>
          
          {/* Marker lines for tuning zones */}
          <div className="absolute left-[20%] top-0 bottom-0 w-px bg-slate-900" />
          <div className="absolute left-[45%] top-0 bottom-0 w-px bg-slate-900" />
          <div className="absolute left-[70%] top-0 bottom-0 w-px bg-slate-900" />
          <div className="absolute left-[88%] top-0 bottom-0 w-px bg-red-800" />
        </div>
      </div>
    </div>
  );
};
