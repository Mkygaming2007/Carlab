import React from "react";
import { Thermometer, Heart, AlertTriangle, ShieldAlert, Sparkles, AlertOctagon } from "lucide-react";
import { EngineHealth, HEALTH_LIMITS } from "../engineHealth";

interface EngineHealthPanelProps {
  health: EngineHealth;
  onRepair: () => void;
}

export const EngineHealthPanel: React.FC<EngineHealthPanelProps> = ({
  health,
  onRepair,
}) => {
  const currentHealthPercent = Math.max(0, Math.round(100 - health.damage));

  // Determine health bar gradient & text style
  let healthColor = "text-emerald-400 bg-emerald-950/20 border-emerald-800/40";
  let healthBg = "bg-emerald-500";
  if (currentHealthPercent < 40) {
    healthColor = "text-rose-400 bg-rose-950/20 border-rose-800/40 animate-pulse";
    healthBg = "bg-rose-500";
  } else if (currentHealthPercent < 80) {
    healthColor = "text-amber-400 bg-amber-950/20 border-amber-800/40";
    healthBg = "bg-amber-500";
  }

  // Determine temperature text style
  let tempColor = "text-emerald-400";
  let tempIconColor = "text-emerald-400";
  let tempProgressBg = "bg-emerald-500";
  if (health.temperature >= HEALTH_LIMITS.overheatThreshold) {
    tempColor = "text-rose-400 font-bold animate-pulse";
    tempIconColor = "text-rose-500 animate-bounce";
    tempProgressBg = "bg-rose-500";
  } else if (health.temperature >= 95) {
    tempColor = "text-amber-400 font-medium";
    tempIconColor = "text-amber-400";
    tempProgressBg = "bg-amber-500";
  }

  // Dynamic warnings list
  const warnings: string[] = [];
  if (health.isEngineBlown) {
    warnings.push("FAILSAFE/LIMP MODE ACTIVE: Engine block blown out completely. Top speed restricted, turbo induction disabled.");
  } else {
    if (health.warningLights.overheating) {
      warnings.push("CRITICAL TEMPERATURE: Water jacket boiling. Severe cylinder and valve wear occurring currently.");
    }
    if (health.warningLights.highBoost) {
      warnings.push("CYLINDER PRESSURE EXCESS: Extreme turbo boost exceeds ring land limits. Ring land stress active.");
    }
    if (health.temperature > 100) {
      warnings.push("ELEVATED COOLANT HEAT: Cooling cycle struggling. Reduce engine RPM to allow cooling flow.");
    }
    if (health.wear > HEALTH_LIMITS.wearDamageThreshold) {
      warnings.push("STRUCTURAL WEAR THRESHOLD: Micro-fractures active in crank journal. Complete seal breakdown imminent.");
    }
  }

  return (
    <div className="w-full flex flex-col gap-5 bg-slate-950 p-5 rounded-xl border border-slate-800" id="engine-health-root">
      {/* Header bar defining systems status */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-800 pb-3 gap-2">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-rose-500" />
          <div>
            <h3 className="text-sm font-bold font-mono text-rose-400 tracking-widest uppercase">ECU HEALTH PROFILE SYSTEMS</h3>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">Real-time cylinder pressures, seal status, and thermal metrics.</p>
          </div>
        </div>
        
        {/* Blown Engine Status Badge */}
        {health.isEngineBlown ? (
          <span className="px-3 py-1 bg-rose-950/40 border border-rose-800/60 text-rose-400 text-[10px] font-mono font-bold rounded-lg animate-pulse tracking-widest uppercase flex items-center gap-1">
            <AlertOctagon className="w-3.5 h-3.5 animate-bounce" />
            ENGINE BLOWN
          </span>
        ) : (
          <span className="px-3 py-1 bg-emerald-950/30 border border-emerald-800/40 text-emerald-400 text-[10px] font-mono font-bold rounded-lg tracking-widest uppercase flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" />
            ECU SYSTEMS NORMAL
          </span>
        )}
      </div>

      {/* Main Stats Display Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Vital 1: Core Engine Health Ratio */}
        <div className="bg-slate-900/40 border border-slate-800/60 p-4 rounded-lg flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block">CORE STRUCTURAL STATE</span>
              <h4 className="text-xs font-bold font-mono text-slate-200 mt-0.5">CYLINDER WALL INTEGRITY</h4>
            </div>
            <span className={`p-1.5 rounded-md border text-xs font-mono font-bold ${healthColor}`}>
              {currentHealthPercent}%
            </span>
          </div>

          <div className="mt-4">
            <div className="flex justify-between text-[9px] font-mono text-slate-500 uppercase mb-1">
              <span>Block Stress: {Math.round(health.damage)}%</span>
              <span>Wear Degradation: {Math.round(health.wear)}%</span>
            </div>
            <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-805">
              <div
                className={`${healthBg} h-full transition-all duration-300 ease-out`}
                style={{ width: `${currentHealthPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Vital 2: Dynamic Coolant Temperature */}
        <div className="bg-slate-900/40 border border-slate-800/60 p-4 rounded-lg flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block">THERMAL ENVELOPE</span>
              <h4 className="text-xs font-bold font-mono text-slate-200 mt-0.5">WATER JACKET TEMP</h4>
            </div>
            <span className="p-1.5 rounded-lg bg-slate-900/80 border border-slate-850">
              <Thermometer className={`w-4 h-4 ${tempIconColor}`} />
            </span>
          </div>

          <div className="mt-4 flex items-baseline justify-between">
            <div className="flex items-baseline gap-1">
              <span className={`text-2xl font-mono font-extrabold tracking-tight ${tempColor}`}>
                {health.temperature.toFixed(1)}
              </span>
              <span className="text-[10px] font-mono text-slate-500">°C</span>
            </div>
            <span className="text-[9px] font-mono text-slate-500 uppercase">Warning Limit: 105°C</span>
          </div>

          {/* Color-changing thermal bar */}
          <div className="mt-2 w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
            <div
              className={`${tempProgressBg} h-full transition-all duration-300`}
              style={{ width: `${Math.min(100, (health.temperature / 135) * 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Warnings Panel and Warnings Log */}
      {warnings.length > 0 && (
        <div className="bg-rose-950/10 border border-rose-900/30 rounded-lg p-3.5 flex flex-col gap-2">
          <div className="flex items-center gap-1.5 text-rose-400 font-mono text-xs font-bold">
            <AlertTriangle className="w-4 h-4 animate-pulse" />
            <span>ECU SYSTEM TELEMETRY WARNINGS</span>
          </div>
          <ul className="flex flex-col gap-1 text-[10px] font-mono text-rose-300 list-disc pl-4 leading-relaxed">
            {warnings.map((msg, idx) => (
              <li key={idx}>
                {msg}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Repair & Service Block */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-900/20 border border-slate-800/40 p-4 rounded-lg mt-1 gap-4">
        <div>
          <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block">PIT STOP RECONSTRUCTION</span>
          <h4 className="text-xs font-mono font-bold text-slate-300 mt-0.5">MOTOR CRANK RECONSTRUCT</h4>
          <p className="text-[9px] text-slate-500 mt-1 uppercase tracking-wider">Flush coolant, machine cylinder blocks, and reset piston seals to pristine specs.</p>
        </div>
        
        <button
          onClick={onRepair}
          className="flex items-center gap-2 py-2 px-5 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-lg text-xs font-mono font-bold uppercase cursor-pointer transition duration-150 shadow shadow-rose-950/60 self-stretch sm:self-auto justify-center"
          disabled={health.damage === 0 && health.wear === 0 && health.temperature <= 75}
        >
          <Heart className="w-3.5 h-3.5" />
          <span>RECONSTRUCT ENGINE CODE</span>
        </button>
      </div>
    </div>
  );
};
