import React, { useRef, useEffect, useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Play, RotateCcw, AlertTriangle, ShieldCheck, Cpu } from "lucide-react";
import { DynoPoint } from "../dynoSystem";

interface DynoGraphProps {
  dynoCurve: DynoPoint[];
  currentRpm: number;
  maxRpm: number;
}

export const DynoGraph: React.FC<DynoGraphProps> = ({
  dynoCurve,
  currentRpm,
  maxRpm
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [dimensions, setDimensions] = useState({ width: 600, height: 260 });
  const [hoveredPoint, setHoveredPoint] = useState<DynoPoint & { x: number; yHp: number; yTorque: number } | null>(null);
  const [hoverPosition, setHoverPosition] = useState({ x: 0, y: 0 });

  // Progressive Sweep state
  const [sweepProgress, setSweepProgress] = useState(1.0); // 1.0 means fully drawn
  const [isSweeping, setIsSweeping] = useState(false);
  const sweepIntervalRef = useRef<number | null>(null);

  // Resize listener using ResizeObserver
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width, height } = entries[0].contentRect;
      setDimensions({
        width: Math.max(280, width),
        height: Math.max(180, height || 250)
      });
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Compute Peak figures
  const peakHp = useMemo(() => {
    if (dynoCurve.length === 0) return 0;
    return Math.max(...dynoCurve.map(p => p.horsepower));
  }, [dynoCurve]);

  const peakTorque = useMemo(() => {
    if (dynoCurve.length === 0) return 0;
    return Math.max(...dynoCurve.map(p => p.torque));
  }, [dynoCurve]);

  // Max bounds for axes scaling
  const maxAxisHp = useMemo(() => Math.ceil((peakHp * 1.15) / 50) * 50 || 100, [peakHp]);
  const maxAxisTorque = useMemo(() => Math.ceil((peakTorque * 1.15) / 50) * 50 || 100, [peakTorque]);

  // Run a visual dyno sweep animation
  const triggerSweep = () => {
    if (isSweeping) return;
    setIsSweeping(true);
    setSweepProgress(0.0);

    let start: number | null = null;
    const duration = 1600; // 1.6s sweep

    const animate = (timestamp: number) => {
      if (!start) start = timestamp;
      const elapsed = timestamp - start;
      const progress = Math.min(1.0, elapsed / duration);

      setSweepProgress(progress);

      if (progress < 1.0) {
        sweepIntervalRef.current = requestAnimationFrame(animate);
      } else {
        setIsSweeping(false);
      }
    };

    sweepIntervalRef.current = requestAnimationFrame(animate);
  };

  // Auto-sweep when dataset (active modifications) changes
  useEffect(() => {
    triggerSweep();
    return () => {
      if (sweepIntervalRef.current) {
        cancelAnimationFrame(sweepIntervalRef.current);
      }
    };
  }, [dynoCurve]);

  // Canvas drawing effect
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Support high-DPI displays
    const dpr = window.devicePixelRatio || 1;
    canvas.width = dimensions.width * dpr;
    canvas.height = dimensions.height * dpr;
    ctx.scale(dpr, dpr);

    const width = dimensions.width;
    const height = dimensions.height;

    // Define padded viewport boundaries
    const paddingLeft = 50;
    const paddingRight = 50;
    const paddingTop = 25;
    const paddingBottom = 40;

    const plotWidth = width - paddingLeft - paddingRight;
    const plotHeight = height - paddingTop - paddingBottom;

    // Clear Canvas
    ctx.clearRect(0, 0, width, height);

    // 1. Draw grid background & Cartesian divisions
    ctx.strokeStyle = "rgba(30, 41, 59, 0.4)";
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);

    for (let i = 0; i <= 5; i++) {
      // Horizontal grid lines
      const y = paddingTop + (plotHeight * i) / 5;
      ctx.beginPath();
      ctx.moveTo(paddingLeft, y);
      ctx.lineTo(width - paddingRight, y);
      ctx.stroke();

      // Vertical grids for RPM zones
      const x = paddingLeft + (plotWidth * i) / 5;
      ctx.beginPath();
      ctx.moveTo(x, paddingTop);
      ctx.lineTo(x, height - paddingBottom);
      ctx.stroke();
    }
    ctx.setLineDash([]); // Reset line dash

    // Axial Labels
    ctx.fillStyle = "#64748b";
    ctx.font = "bold 9px 'JetBrains Mono', monospace";
    ctx.textAlign = "center";

    // X-Axis bounds (RPM)
    ctx.fillText("1,000", paddingLeft, height - paddingBottom + 16);
    ctx.fillText("RPM", paddingLeft + plotWidth / 2, height - paddingBottom + 26);
    ctx.fillText(`${maxRpm.toLocaleString()}`, width - paddingRight, height - paddingBottom + 16);

    // Left Y-Axis labels (Horsepower)
    ctx.fillStyle = "#f43f5e"; // Rose
    ctx.textAlign = "right";
    ctx.fillText(`${maxAxisHp} HP`, paddingLeft - 8, paddingTop + 4);
    ctx.fillText("0 HP", paddingLeft - 8, height - paddingBottom);

    // Right Y-Axis labels (Torque)
    ctx.fillStyle = "#a855f7"; // Purple/Fuchsia
    ctx.textAlign = "left";
    ctx.fillText(`${maxAxisTorque} Nm`, width - paddingRight + 8, paddingTop + 4);
    ctx.fillText("0 Nm", width - paddingRight + 8, height - paddingBottom);

    if (dynoCurve.length === 0) return;

    // Helper coordinates mapping functions
    const getXCoords = (rpm: number) => {
      const ratio = (rpm - 1000) / (maxRpm - 1000);
      return paddingLeft + ratio * plotWidth;
    };

    const getYHpCoords = (hp: number) => {
      const ratio = hp / maxAxisHp;
      return height - paddingBottom - ratio * plotHeight;
    };

    const getYTorqueCoords = (torque: number) => {
      const ratio = torque / maxAxisTorque;
      return height - paddingBottom - ratio * plotHeight;
    };

    // Filter points based on current sweep progression
    const maxRpmLim = 1000 + (maxRpm - 1000) * sweepProgress;
    const visiblePoints = dynoCurve.filter(p => p.rpm <= maxRpmLim);

    if (visiblePoints.length > 1) {
      // 2. Draw Torque Curve
      ctx.beginPath();
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#a855f7"; // Purple Glow
      ctx.shadowColor = "#a855f7";
      ctx.shadowBlur = 4;

      let first = true;
      visiblePoints.forEach((p) => {
        const x = getXCoords(p.rpm);
        const y = getYTorqueCoords(p.torque);
        if (first) {
          ctx.moveTo(x, y);
          first = false;
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();
      ctx.shadowBlur = 0; // Reset blur

      // Fill secondary Gradient under Torque line
      const trqGrad = ctx.createLinearGradient(0, paddingTop, 0, height - paddingBottom);
      trqGrad.addColorStop(0, "rgba(168, 85, 247, 0.08)");
      trqGrad.addColorStop(1, "rgba(168, 85, 247, 0.0)");
      ctx.beginPath();
      ctx.moveTo(getXCoords(visiblePoints[0].rpm), height - paddingBottom);
      visiblePoints.forEach((p) => {
        ctx.lineTo(getXCoords(p.rpm), getYTorqueCoords(p.torque));
      });
      ctx.lineTo(getXCoords(visiblePoints[visiblePoints.length - 1].rpm), height - paddingBottom);
      ctx.closePath();
      ctx.fillStyle = trqGrad;
      ctx.fill();

      // 3. Draw Horsepower Curve
      ctx.beginPath();
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#f43f5e"; // Rose Glow
      ctx.shadowColor = "#f43f5e";
      ctx.shadowBlur = 4;

      first = true;
      visiblePoints.forEach((p) => {
        const x = getXCoords(p.rpm);
        const y = getYHpCoords(p.horsepower);
        if (first) {
          ctx.moveTo(x, y);
          first = false;
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();
      ctx.shadowBlur = 0; // Reset blur

      // Fill Gradient under HP line
      const hpGrad = ctx.createLinearGradient(0, paddingTop, 0, height - paddingBottom);
      hpGrad.addColorStop(0, "rgba(244, 63, 94, 0.08)");
      hpGrad.addColorStop(1, "rgba(244, 63, 94, 0.0)");
      ctx.beginPath();
      ctx.moveTo(getXCoords(visiblePoints[0].rpm), height - paddingBottom);
      visiblePoints.forEach((p) => {
        ctx.lineTo(getXCoords(p.rpm), getYHpCoords(p.horsepower));
      });
      ctx.lineTo(getXCoords(visiblePoints[visiblePoints.length - 1].rpm), height - paddingBottom);
      ctx.closePath();
      ctx.fillStyle = hpGrad;
      ctx.fill();
    }

    // 4. Draw Current Live Tachometer RPM Cursor
    if (currentRpm > 1000) {
      const cursorX = getXCoords(currentRpm);
      if (cursorX >= paddingLeft && cursorX <= width - paddingRight) {
        // Glowing live indicator line
        ctx.strokeStyle = "rgba(6, 182, 212, 0.75)";
        ctx.lineWidth = 1.5;
        ctx.setLineDash([5, 3]);
        ctx.beginPath();
        ctx.moveTo(cursorX, paddingTop);
        ctx.lineTo(cursorX, height - paddingBottom);
        ctx.stroke();
        ctx.setLineDash([]);

        // Interactive particle indicator dot
        ctx.fillStyle = "#22d3ee"; // Neon Cyan
        ctx.shadowColor = "#06b6d4";
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.arc(cursorX, height - paddingBottom, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Visual "LIVE" tag
        ctx.fillStyle = "#22d3ee";
        ctx.font = "9px 'JetBrains Mono', monospace";
        ctx.fillText("LIVE", cursorX, paddingTop - 4);
      }
    }

    // 5. Draw sweep progress marker indicator if sweeping
    if (isSweeping && sweepProgress < 1.0) {
      const sweepX = paddingLeft + plotWidth * sweepProgress;
      ctx.strokeStyle = "rgba(168, 85, 247, 0.6)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(sweepX, paddingTop);
      ctx.lineTo(sweepX, height - paddingBottom);
      ctx.stroke();
    }
  }, [dimensions, dynoCurve, currentRpm, maxRpm, maxAxisHp, maxAxisTorque, sweepProgress, isSweeping]);

  // Handle visual hover selection over graph area
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || dynoCurve.length === 0) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const paddingLeft = 50;
    const paddingRight = 50;
    const plotWidth = dimensions.width - paddingLeft - paddingRight;

    if (x < paddingLeft || x > dimensions.width - paddingRight) {
      setHoveredPoint(null);
      return;
    }

    // Locate closest mathematical coordinates index match
    const ratio = (x - paddingLeft) / plotWidth;
    const targetRpm = 1000 + ratio * (maxRpm - 1000);

    // Find closest element
    let closest = dynoCurve[0];
    let minDiff = Math.abs(closest.rpm - targetRpm);

    dynoCurve.forEach((p) => {
      const diff = Math.abs(p.rpm - targetRpm);
      if (diff < minDiff) {
        closest = p;
        minDiff = diff;
      }
    });

    // Recompute projected dynamic Y positions inside coordinate scale
    const paddingTop = 25;
    const paddingBottom = 40;
    const plotHeight = dimensions.height - paddingTop - paddingBottom;

    const xVal = paddingLeft + ((closest.rpm - 1000) / (maxRpm - 1000)) * plotWidth;
    const yHpVal = dimensions.height - paddingBottom - (closest.horsepower / maxAxisHp) * plotHeight;
    const yTorqueVal = dimensions.height - paddingBottom - (closest.torque / maxAxisTorque) * plotHeight;

    setHoveredPoint({
      ...closest,
      x: xVal,
      yHp: yHpVal,
      yTorque: yTorqueVal
    });

    // Hover tooltip viewport boundary placement
    setHoverPosition({
      x: e.clientX - rect.left + 15,
      y: e.clientY - rect.top - 85
    });
  };

  const handleMouseLeave = () => {
    setHoveredPoint(null);
  };

  return (
    <div className="w-full flex flex-col gap-3 relative" ref={containerRef}>
      
      {/* Visual tool headers with Dyno Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pb-2 border-b border-slate-900">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-purple-400" />
          <span className="text-[10px] font-mono font-black text-purple-400 tracking-wider uppercase">
            Dynamometer Sweep Plotter
          </span>
        </div>
        
        <div className="flex items-center gap-2.5">
          <button
            onClick={triggerSweep}
            disabled={isSweeping}
            className="px-2.5 py-1 text-[8.5px] font-mono font-bold uppercase transition bg-slate-900 hover:bg-slate-800 disabled:opacity-40 border border-slate-800 text-slate-300 hover:text-white rounded flex items-center gap-1 cursor-pointer"
          >
            <Play className="w-2.5 h-2.5 fill-current text-purple-400" />
            Sweep Graph
          </button>
        </div>
      </div>

      {/* Main Canvas Node and Absolute tooltip layer */}
      <div className="relative w-full bg-slate-950/60 rounded-xl overflow-hidden border border-slate-900/45">
        <canvas
          ref={canvasRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="block w-full h-[220px] md:h-[260px] cursor-crosshair z-10 relative"
          style={{ width: "100%", height: "240px" }}
        />

        {/* Floating tooltip component portal */}
        <AnimatePresence>
          {hoveredPoint && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.1 }}
              className="absolute z-20 pointer-events-none p-3 rounded-lg bg-slate-955 border border-slate-800 shadow-2xl flex flex-col gap-1.5 font-mono text-[9px] uppercase leading-none text-slate-350 min-w-[125px]"
              style={{
                left: `${Math.min(dimensions.width - 145, Math.max(10, hoverPosition.x))}px`,
                top: `${Math.min(dimensions.height - 110, Math.max(10, hoverPosition.y))}px`
              }}
            >
              <div className="border-b border-slate-900 pb-1.5">
                <span className="text-slate-500 text-[8px] font-bold block mb-0.5">ENGINE SPEED</span>
                <span className="text-slate-100 font-extrabold text-[11px]">{hoveredPoint.rpm.toLocaleString()} RPM</span>
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-center text-rose-400">
                  <span className="text-slate-500 text-[7.5px]">HORSEPOWER:</span>
                  <span className="font-extrabold">{hoveredPoint.horsepower} HP</span>
                </div>
                <div className="flex justify-between items-center text-purple-400">
                  <span className="text-slate-500 text-[7.5px]">TORQUE FORCE:</span>
                  <span className="font-extrabold">{hoveredPoint.torque} Nm</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Auxiliary legends indicators */}
      <div className="flex justify-start gap-4 text-[9px] font-mono uppercase text-slate-505 px-1 border-t border-slate-900/50 pt-2">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-0.5 bg-rose-500 block" />
          <span>Horsepower Curve (Metric HP)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-0.5 bg-purple-500 block" />
          <span>Engine Torque Output (Nm Force)</span>
        </div>
      </div>
    </div>
  );
};
