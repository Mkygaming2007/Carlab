import React, { ErrorInfo, ReactNode } from "react";
import { AlertOctagon, RotateCcw } from "lucide-react";

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("ErrorBoundary caught an uncaught crash:", error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#07091a] flex flex-col items-center justify-center p-6 text-white font-sans" id="error-boundary-view">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(139,92,246,0.08),transparent_65%)] pointer-events-none" />
          
          <div className="max-w-md w-full bg-slate-900/60 border border-red-500/20 rounded-2xl p-6 sm:p-8 backdrop-blur-md relative z-10 text-center flex flex-col items-center gap-5 shadow-2xl">
            <div className="p-4 bg-red-950/40 border border-red-800/30 rounded-full animate-bounce">
              <AlertOctagon className="w-10 h-10 text-red-400" />
            </div>

            <div className="flex flex-col gap-1.5">
              <h2 className="text-xl font-bold tracking-tight text-white uppercase font-mono">
                System Interface Diagnostics Alert
              </h2>
              <p className="text-sm text-slate-400 leading-relaxed">
                CARLAB PRO experienced a virtual runtime collision. Standard execution limits have been tripped.
              </p>
            </div>

            {this.state.error && (
              <div className="w-full bg-slate-950/80 p-3 rounded-lg border border-slate-850 text-left font-mono text-[10px] text-red-300 max-h-[140px] overflow-auto select-all leading-normal">
                <span className="text-red-400 font-bold uppercase tracking-wider block mb-1">CATCH_TRACE:</span>
                {this.state.error.toString()}
              </div>
            )}

            <button
              onClick={this.handleReset}
              className="mt-2 w-full py-2.5 px-4 bg-purple-650 hover:bg-purple-700 active:scale-[0.98] text-white font-mono text-xs font-bold uppercase tracking-wider rounded-xl transition cursor-pointer flex items-center justify-center gap-2 border border-purple-500/20 hover:border-purple-500/40"
            >
              <RotateCcw className="w-4 h-4" />
              Reset Simulation Matrix
            </button>
          </div>
        </div>
      );
    }

    return this.props.children ? this.props.children : null;
  }
}
