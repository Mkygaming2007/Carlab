import React, { useState, useMemo } from "react";
import {
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Info,
  Wrench,
  Sparkles,
  Gauge,
  TrendingUp,
  Weight,
  Volume2,
  ChevronDown,
  ChevronRight,
  Eye,
  Sliders,
  AlertCircle,
  HelpCircle,
  FolderMinus,
  FolderPlus,
  Play
} from "lucide-react";
import { CarPlatform } from "../data/carDatabase";
import {
  VEHICLE_MODS_DATABASE,
  VehicleModification,
  ModificationCategory,
  checkModCompatibility,
  checkModificationDependencies,
  applySelectedModsToEngine
} from "../data/modsDatabase";

interface AdvancedModificationPanelProps {
  activeCar?: CarPlatform;
  installedModIds?: string[];
  onToggleMod?: (modId: string) => void;
  engineState?: any;
  availableMods?: any[];
  appliedMods?: any[];
}

export const AdvancedModificationPanel: React.FC<AdvancedModificationPanelProps> = ({
  activeCar,
  installedModIds = [],
  onToggleMod = () => {},
  engineState,
  availableMods,
  appliedMods = [],
}) => {
  // TASK 1: FIX UNDEFINED STATE CRASHES
  if (!activeCar) return null;
  if (!engineState) return null;
  if (!availableMods) return [];

  // TASK 6: ADD LOADING STATE
  if (!activeCar || !VEHICLE_MODS_DATABASE || VEHICLE_MODS_DATABASE.length === 0) {
    return <div className="text-center font-mono text-slate-400 text-xs py-10" id="mods-loading">Loading mods...</div>;
  }

  const [searchQuery, setSearchQuery] = useState("");
  const [showOnlyCompatible, setShowOnlyCompatible] = useState(true);
  const [hoveredModId, setHoveredModId] = useState<string | null>(null);
  const [selectedPreviewId, setSelectedPreviewId] = useState<string | null>(null);

  // Categories list
  const categories: ModificationCategory[] = [
    "Engine",
    "Forced Induction",
    "Fuel System",
    "Cooling",
    "Exhaust",
    "Suspension",
    "Brakes",
    "Wheels & Tires",
    "Drivetrain",
    "Aero",
    "Interior",
    "Exterior",
    "Offroad"
  ];

  // Accordion open/close state tracking
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({
    "Interior": true,
    "Exterior": true,
    "Offroad": activeCar.id !== "thar-2.0tgdi" // Thar should start with Offroad expanded, others closed
  });

  const toggleCategoryCollapse = (cat: string) => {
    setCollapsedCategories(prev => ({
      ...prev,
      [cat]: !prev[cat]
    }));
  };

  const expandAll = () => {
    const fresh: Record<string, boolean> = {};
    categories.forEach(cat => {
      fresh[cat] = false;
    });
    setCollapsedCategories(fresh);
  };

  const collapseAll = () => {
    const fresh: Record<string, boolean> = {};
    categories.forEach(cat => {
      fresh[cat] = true;
    });
    setCollapsedCategories(fresh);
  };

  // Map category to styles
  const getCategoryStyles = (cat: ModificationCategory) => {
    switch (cat) {
      case "Engine": return { text: "text-cyan-400", bg: "bg-cyan-950/20", border: "border-cyan-800/40" };
      case "Forced Induction": return { text: "text-emerald-400", bg: "bg-emerald-955/20", border: "border-emerald-800/40" };
      case "Fuel System": return { text: "text-purple-400", bg: "bg-purple-955/20", border: "border-purple-800/40" };
      case "Cooling": return { text: "text-sky-400", bg: "bg-sky-955/20", border: "border-sky-800/40" };
      case "Exhaust": return { text: "text-orange-400", bg: "bg-orange-955/20", border: "border-orange-850/40" };
      case "Suspension": return { text: "text-indigo-400", bg: "bg-indigo-950/20", border: "border-indigo-805/40" };
      case "Brakes": return { text: "text-rose-400", bg: "bg-rose-955/20", border: "border-rose-800/40" };
      case "Wheels & Tires": return { text: "text-amber-400", bg: "bg-amber-955/20", border: "border-amber-800/40" };
      case "Drivetrain": return { text: "text-fuchsia-400", bg: "bg-fuchsia-955/20", border: "border-fuchsia-800/40" };
      case "Aero": return { text: "text-teal-400", bg: "bg-teal-955/20", border: "border-teal-800/40" };
      case "Interior": return { text: "text-violet-400", bg: "bg-violet-955/20", border: "border-violet-800/40" };
      case "Exterior": return { text: "text-pink-400", bg: "bg-pink-955/20", border: "border-pink-800/40" };
      case "Offroad": return { text: "text-lime-400", bg: "bg-lime-955/20", border: "border-lime-800/40" };
      default: return { text: "text-slate-400", bg: "bg-slate-950/20", border: "border-slate-800/40" };
    }
  };

  // Enhance all database mods with status and precalculated compatibility checks
  const enrichedMods = useMemo(() => {
    return VEHICLE_MODS_DATABASE.map(mod => {
      const compCheck = checkModCompatibility(mod, activeCar);
      const depCheck = checkModificationDependencies(mod, installedModIds);
      return {
        ...mod,
        isCompatible: compCheck.compatible,
        incompatibilityReason: compCheck.reason,
        isInstalled: installedModIds.includes(mod.id),
        unmetDependencies: depCheck.missing,
        hasUnmetDependencies: !depCheck.passes && installedModIds.includes(mod.id),
        passesDependencies: depCheck.passes
      };
    });
  }, [activeCar, installedModIds]);

  // Handle preview calculation context on selected or hovered mod
  const previewedMod = useMemo(() => {
    const targetId = hoveredModId || selectedPreviewId;
    if (!targetId) return null;
    return enrichedMods.find(m => m.id === targetId) || null;
  }, [hoveredModId, selectedPreviewId, enrichedMods]);

  // Group mods by category after evaluating filters
  const groupedMods = useMemo(() => {
    const result: Record<ModificationCategory, typeof enrichedMods> = {} as any;
    categories.forEach(cat => {
      result[cat] = [];
    });

    enrichedMods.forEach(mod => {
      // Apply filters:
      // 1. Compatibility constraint
      if (showOnlyCompatible && !mod.isCompatible) return;

      // 2. Search query filter
      if (searchQuery.trim() !== "") {
        const query = searchQuery.toLowerCase();
        const matchesName = mod.name.toLowerCase().includes(query);
        const matchesDesc = mod.description.toLowerCase().includes(query);
        const matchesSpecs = mod.specs && Object.values(mod.specs).some(val => String(val).toLowerCase().includes(query));
        if (!matchesName && !matchesDesc && !matchesSpecs) return;
      }

      result[mod.category].push(mod);
    });

    return result;
  }, [enrichedMods, showOnlyCompatible, searchQuery]);

  return (
    <div className="w-full bg-[#080a1c] p-4 sm:p-5 rounded-2xl border border-purple-500/10 flex flex-col gap-5 relative overflow-hidden" id="advanced-modification-panel">
      {/* Decorative backdrop glow */}
      <div className="absolute top-0 right-0 p-12 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
      
      {/* Search and control filter row */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-900/40 p-4 rounded-xl border border-slate-900">
        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto items-center">
          {/* Quick search input */}
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search specifications or upgrades..."
              className="w-full bg-slate-950 border border-slate-805 pl-9 pr-4 py-1.5 rounded-lg text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500 transition"
            />
          </div>

          {/* Supported compatibility filter */}
          <label className="flex items-center gap-2 cursor-pointer text-[11px] font-mono text-slate-400 select-none">
            <input
              type="checkbox"
              checked={showOnlyCompatible}
              onChange={(e) => setShowOnlyCompatible(e.target.checked)}
              className="rounded border-slate-800 text-purple-600 focus:ring-purple-500 focus:ring-offset-slate-900 bg-slate-950 w-4 h-4 checked:bg-purple-600"
            />
            <span>Show Only Compatible with {activeCar.brand}</span>
          </label>
        </div>

        {/* Global accordion control handles */}
        <div className="flex gap-2 shrink-0">
          <button
            onClick={expandAll}
            className="px-2.5 py-1 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 text-[10px] font-mono uppercase rounded flex items-center gap-1 transition cursor-pointer"
          >
            <FolderPlus className="w-3.5 h-3.5" />
            Expand All
          </button>
          <button
            onClick={collapseAll}
            className="px-2.5 py-1 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 text-[10px] font-mono uppercase rounded flex items-center gap-1 transition cursor-pointer"
          >
            <FolderMinus className="w-3.5 h-3.5" />
            Collapse All
          </button>
        </div>
      </div>

      {/* Primary two-column layout configuration */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
        
        {/* Accordions containing categorical products */}
        <div className="xl:col-span-8 flex flex-col gap-3 max-h-[60vh] overflow-y-auto pr-1">
          {categories.map((cat) => {
            const mods = groupedMods[cat] || [];
            if (mods.length === 0) return null; // Hide empty filtered categories

            const isCollapsed = !!collapsedCategories[cat];
            const catStyle = getCategoryStyles(cat);
            const appliedCount = mods.filter(m => m.isInstalled).length;

            return (
              <div 
                key={cat}
                className="bg-slate-950/60 border border-slate-900 rounded-xl overflow-hidden"
              >
                {/* Header of Accordion Box */}
                <div
                  onClick={() => toggleCategoryCollapse(cat)}
                  className="p-3 bg-slate-900/40 hover:bg-slate-900/80 cursor-pointer flex justify-between items-center transition select-none"
                >
                  <div className="flex items-center gap-2">
                    {isCollapsed ? <ChevronRight className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                    <span className={`text-[11px] font-black font-mono uppercase tracking-widest ${catStyle.text}`}>
                      {cat}
                    </span>
                    {appliedCount > 0 && (
                      <span className="text-[9px] font-mono font-bold bg-purple-950 text-purple-400 border border-purple-800/40 px-1.5 py-0.5 rounded">
                        {appliedCount} Applied
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">{mods.length} Option{mods.length !== 1 ? "s" : ""}</span>
                </div>

                {/* Subproducts list wrapper */}
                {!isCollapsed && (
                  <div className="p-3 border-t border-slate-900 bg-slate-950/20 grid grid-cols-1 md:grid-cols-2 gap-3.5 animate-fadeIn">
                    {(() => {
                      const safeMods = Array.isArray(mods) ? mods : [];
                      return safeMods.map((mod) => {
                        if (!mod || !mod.id) return null;
                        const isUnmetDep = Array.isArray(mod.dependencies) && mod.dependencies.some(id => !installedModIds.includes(id));
                        const isHovered = hoveredModId === mod.id;
                        const isSelected = selectedPreviewId === mod.id;
                        const isActivePreviewFocus = isHovered || isSelected;

                        return (
                        <div
                          key={mod.id}
                          onMouseEnter={() => setHoveredModId(mod.id)}
                          onMouseLeave={() => setHoveredModId(null)}
                          onClick={() => setSelectedPreviewId(mod.id)}
                          className={`relative border rounded-xl p-3.5 flex flex-col justify-between transition-all duration-150 group cursor-pointer ${
                            mod.isInstalled
                              ? "border-purple-500 bg-purple-955/10 min-h-[175px]"
                              : !mod.isCompatible
                              ? "border-slate-900/60 opacity-50 bg-slate-950/10 grayscale min-h-[175px]"
                              : isActivePreviewFocus
                              ? "border-cyan-500 bg-cyan-955/5 shadow shadow-cyan-950/30 min-h-[175px]"
                              : "border-slate-850 hover:border-slate-700 bg-slate-950/30 min-h-[175px]"
                          }`}
                        >
                          {/* Corner selected state ribbon */}
                          {mod.isInstalled && (
                            <div className="absolute top-0 right-0 p-1 bg-purple-500 rounded-bl-lg rounded-tr-lg">
                              <CheckCircle2 className="w-3.5 h-3.5 text-slate-100" />
                            </div>
                          )}

                          <div>
                            {/* Card label parameters headers */}
                            <div className="flex justify-between items-start gap-2 mb-1.5">
                              <span className={`text-[8px] font-mono font-black px-1.5 py-0.5 rounded border uppercase ${catStyle.text} ${catStyle.bg} ${catStyle.border}`}>
                                {mod.category}
                              </span>

                              <span className="text-[9px] font-mono text-slate-600">
                                {mod.minVal !== undefined && mod.maxVal !== undefined ? (
                                  `Slide: ${mod.minVal}-${mod.maxVal} ${mod.unit || ""}`
                                ) : (
                                  "Custom Hardware"
                                )}
                              </span>
                            </div>

                            {/* Standard title */}
                            <h4 className="text-xs font-black font-mono text-slate-200 group-hover:text-cyan-400 transition leading-snug">
                              {mod.name}
                            </h4>

                            {/* Description text */}
                            <p className="text-[10px] text-slate-400 mt-1 leading-relaxed line-clamp-2">
                              {mod.description}
                            </p>

                            {/* Specification mini tags */}
                            {mod.specs && (
                              <div className="grid grid-cols-2 gap-1.5 mt-2.5 pt-2 border-t border-slate-900/60 text-[8px] font-mono text-slate-500">
                                {Object.entries(mod.specs).slice(0, 2).map(([k, v]) => (
                                  <div key={k} className="flex justify-between truncate uppercase">
                                    <span className="text-slate-650 font-bold">{k}:</span>
                                    <span className="text-slate-400 truncate font-semibold">{v}</span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Incompatibility notes wrapper */}
                            {!mod.isCompatible && (
                              <div className="mt-2.5 bg-rose-955/10 border border-rose-900/30 px-2 py-1.5 rounded flex items-start gap-1">
                                <AlertTriangle className="w-3 h-3 text-rose-500 shrink-0 mt-0.5" />
                                <span className="text-[8px] font-mono text-rose-400 uppercase leading-relaxed">
                                  {mod.incompatibilityReason}
                                </span>
                              </div>
                            )}

                            {/* Pre-requisite Dependency warning */}
                            {mod.dependencies && mod.dependencies.length > 0 && (
                              <div className="mt-2 text-[9px] font-mono flex flex-col gap-0.5 text-slate-500">
                                <span className="text-slate-600 text-[8px] uppercase font-bold tracking-wider">Required Component:</span>
                                <span className={`${isUnmetDep ? "text-amber-400/80" : "text-emerald-400/80"} uppercase inline-flex items-center gap-1`}>
                                  {isUnmetDep ? <AlertTriangle className="w-3 h-3 text-amber-500 animate-pulse" /> : <CheckCircle2 className="w-3 h-3 text-emerald-500" />}
                                  {mod.dependencies.map(id => VEHICLE_MODS_DATABASE.find(m => m.id === id)?.name || id).join(", ")}
                                </span>
                              </div>
                            )}
                          </div>

                          {/* Metric bonus and Installation handles */}
                          <div className="mt-3.5 pt-2 border-t border-slate-900/80 flex items-center justify-between">
                            <span className="text-[9px] font-mono font-bold uppercase">
                              {mod.hpBonus > 0 ? (
                                <span className="text-cyan-400">+{mod.hpBonus} HP Dyno</span>
                              ) : mod.hpBonus < 0 ? (
                                <span className="text-rose-400">{mod.hpBonus} HP Roll</span>
                              ) : (
                                <span className="text-slate-500">Structural</span>
                              )}
                            </span>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                if (mod.isCompatible) {
                                  onToggleMod(mod.id);
                                }
                              }}
                              disabled={!mod.isCompatible}
                              className={`px-2.5 py-1 rounded text-[9px] font-mono font-black uppercase cursor-pointer transition ${
                                mod.isInstalled
                                  ? "bg-purple-900 hover:bg-purple-800 text-white border border-purple-500"
                                  : "bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 disabled:opacity-30 disabled:cursor-not-allowed"
                              }`}
                            >
                              {mod.isInstalled ? "Uninstall" : "Apply Mod"}
                            </button>
                          </div>
                        </div>
                      );
                    });
                  })()}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Real-time preview panel */}
        <div className="xl:col-span-4 flex flex-col gap-4">
          <div className="bg-slate-900/40 border border-slate-900 p-4 rounded-xl flex-1 flex flex-col gap-4 justify-between relative overflow-hidden">
            <div className="absolute top-0 left-0 p-8 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />
            
            <div>
              <div className="flex items-center gap-1.5 border-b border-slate-900 pb-2.5">
                <Sliders className="w-4.5 h-4.5 text-cyan-400" />
                <h4 className="text-xs font-black font-mono text-cyan-400 uppercase tracking-widest">
                  Real-time Simulation HUD
                </h4>
              </div>

              {previewedMod ? (
                <div className="mt-4 animate-fadeIn flex flex-col gap-4">
                  {/* Title block */}
                  <div>
                    <span className="text-[8px] font-mono text-slate-500 uppercase tracking-wider block font-bold">PREVIEW MATRIX:</span>
                    <h5 className="text-sm font-black font-mono text-cyan-300 uppercase leading-snug">
                      {previewedMod.name}
                    </h5>
                    <div className="flex flex-wrap gap-1.5 mt-1.5 text-[9px] font-mono uppercase">
                      <span className="text-slate-450">Category: {previewedMod.category}</span>
                      <span className="text-slate-500">•</span>
                      <span className={previewedMod.isCompatible ? "text-emerald-400" : "text-rose-400"}>
                        {previewedMod.isCompatible ? "Platform Compatible" : "Locked / Incompatible"}
                      </span>
                    </div>
                  </div>

                  {/* Dyno metric offset bar */}
                  <div className="space-y-2.5 bg-slate-950/80 border border-slate-850 p-3 rounded-lg">
                    <span className="text-[8px] font-mono text-cyan-400 uppercase tracking-wider block font-bold">Estimated Hardware Displacement</span>
                    
                    {/* HP delta bar */}
                    <div>
                      <div className="flex justify-between text-[8px] font-mono text-slate-400 uppercase mb-0.5">
                        <span>ESTIMATED HORSEPOWER</span>
                        <span className={`font-black ${previewedMod.hpBonus >= 0 ? "text-cyan-400" : "text-rose-400"}`}>
                          {previewedMod.hpBonus >= 0 ? "+" : ""}{previewedMod.hpBonus} HP
                        </span>
                      </div>
                      <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
                        <div
                          className="bg-cyan-400 h-full transition-all"
                          style={{ width: `${Math.min(100, (Math.abs(previewedMod.hpBonus) / 210) * 100)}%` }}
                        />
                      </div>
                    </div>

                    {/* Torque Delta Bar */}
                    <div>
                      <div className="flex justify-between text-[8px] font-mono text-slate-400 uppercase mb-0.5">
                        <span>INTERMEDIATE TORQUE</span>
                        <span className={`font-black ${previewedMod.torqueBonus >= 0 ? "text-cyan-400" : "text-rose-400"}`}>
                          {previewedMod.torqueBonus >= 0 ? "+" : ""}{previewedMod.torqueBonus} Nm
                        </span>
                      </div>
                      <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
                        <div
                          className="bg-cyan-400 h-full transition-all"
                          style={{ width: `${Math.min(100, (Math.abs(previewedMod.torqueBonus) / 260) * 100)}%` }}
                        />
                      </div>
                    </div>

                    {/* Mass weight offset */}
                    <div>
                      <div className="flex justify-between text-[8px] font-mono text-slate-400 uppercase mb-0.5">
                        <span>CHASSIS WEIGHT</span>
                        <span className={`font-black ${previewedMod.weightImpact <= 0 ? "text-emerald-400" : "text-amber-400"}`}>
                          {previewedMod.weightImpact <= 0 ? "" : "+"}{previewedMod.weightImpact} kg
                        </span>
                      </div>
                      <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
                        <div
                          className="bg-amber-400 h-full transition-all"
                          style={{ width: `${Math.min(100, (Math.abs(previewedMod.weightImpact) / 50) * 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Sound profile indicators */}
                  {previewedMod.soundImpact && (
                    <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-850 flex flex-col gap-1 text-[9px] font-mono text-slate-400">
                      <span className="text-cyan-400 font-bold text-[8px] uppercase tracking-wider mb-1 flex items-center gap-1">
                        <Volume2 className="w-3.5 h-3.5" />
                        Acoustic Signature impact
                      </span>
                      {previewedMod.soundImpact?.loudness && (
                        <div className="flex justify-between">
                          <span>Volume Amplitude:</span>
                          <span className="text-slate-305 font-bold">+{Math.round((previewedMod.soundImpact?.loudness ?? 0) * 100)}%</span>
                        </div>
                      )}
                      {previewedMod.soundImpact?.roughness && (
                        <div className="flex justify-between">
                          <span>Idling Roughness (Lope):</span>
                          <span className="text-slate-305 font-bold">+{Math.round((previewedMod.soundImpact?.roughness ?? 0) * 100)}%</span>
                        </div>
                      )}
                      {previewedMod.soundImpact?.brightness && (
                        <div className="flex justify-between">
                          <span>Resonance Brightness:</span>
                          <span className="text-slate-305 font-bold">+{Math.round((previewedMod.soundImpact?.brightness ?? 0) * 100)}%</span>
                        </div>
                      )}
                      {previewedMod.soundImpact?.backfireRate && (
                        <div className="flex justify-between">
                          <span>Exhaust Crackle pop Rate:</span>
                          <span className="text-slate-305 font-bold">+{Math.round((previewedMod.soundImpact?.backfireRate ?? 0) * 100)}%</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Quick Action directly from Sidebar preview */}
                  <div className="mt-2.5 pt-3 border-t border-slate-850/60">
                    <button
                      onClick={() => {
                        if (previewedMod.isCompatible) {
                          onToggleMod(previewedMod.id);
                        }
                      }}
                      disabled={!previewedMod.isCompatible}
                      className={`w-full py-2 rounded-lg text-xs font-mono font-black uppercase transition cursor-pointer flex items-center justify-center gap-1.5 ${
                        previewedMod.isInstalled
                          ? "bg-purple-900 border border-purple-500 hover:bg-purple-800 text-white"
                          : "bg-cyan-500 border border-cyan-450 hover:bg-cyan-600 text-slate-950 disabled:opacity-30 disabled:cursor-not-allowed"
                      }`}
                    >
                      <Play className="w-3 h-3 fill-current" />
                      {previewedMod.isInstalled ? "Uninstall Configuration Package" : "Apply Specific Hardware Setup"}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="mt-8 text-center py-10 flex flex-col items-center gap-3 text-slate-500 uppercase font-mono text-[9px]">
                  <Eye className="w-7 h-7 text-slate-700 animate-pulse" />
                  <p className="max-w-[190px] leading-relaxed">
                    Hover over or click any modification card to run simulation and display instant performance telemetry delta.
                  </p>
                </div>
              )}
            </div>

            {/* Advice summary block */}
            <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-850 text-[9.5px] font-mono text-slate-400 leading-normal">
              <span className="text-purple-400 font-bold uppercase block mb-1">TUNER'S DIRECTIVE:</span>
              <p>
                Platform specific parts deliver fine-tuned response. While general upgrades (like Enkei wheels) can fit most drivetrains, bespoke components (such as Greddy turbos or Whipple Superchargers) are tailored only for matching platforms.
              </p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
