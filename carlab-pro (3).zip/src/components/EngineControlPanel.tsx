import React, { useEffect, useState, useRef, useMemo } from "react";
import { useEngineController, GEAR_RATIOS } from "../useEngineController";
import { CarPlatform } from "../data/carDatabase";
import { EngineState } from "../data/modificationRules";
import { ExhaustSynthEngine } from "../data/ExhaustSynthEngine";
import { generateDynoCurve } from "../dynoSystem";
import { PerformancePanel } from "./PerformancePanel";
import { EngineHealthPanel } from "./EngineHealthPanel";
import { EngineVisualizer } from "./EngineVisualizer";
import { BoostGauge } from "./BoostGauge";

interface EngineControlPanelProps {
  car: CarPlatform;
  engineState: EngineState;
  audioEngine: ExhaustSynthEngine | null;
  isMuted: boolean;
  onToggleMute: () => void;
  ignitionOn?: boolean;
  onToggleIgnition?: () => void;
  installedModIds?: string[];
  subParts?: Record<string, string>;
}

export function EngineControlPanel({
  car,
  engineState,
  audioEngine,
  isMuted,
  onToggleMute,
  ignitionOn,
  onToggleIgnition,
  installedModIds,
  subParts,
}: EngineControlPanelProps) {
  const safeEngineState = engineState || {
    hp: car?.stock?.hp ?? 100,
    torque: car?.stock?.torque ?? 100,
    rpmLimit: car?.limits?.maxRPM ?? car?.stock?.redline ?? 6500,
    boost: 0,
    weight: car?.stock?.weight ?? 1200,
    loudness: 1.2,
    roughness: 1.1,
    brightness: 1.1,
    turboIntensity: 0.0,
    backfireRate: 0.6,
  };

  const controller = useEngineController(car, safeEngineState, audioEngine, ignitionOn, onToggleIgnition);
  const [isPressingThrottle, setIsPressingThrottle] = useState(false);
  const [isPressingBrake, setIsPressingBrake] = useState(false);

  const dynoCurve = useMemo(() => generateDynoCurve(safeEngineState), [safeEngineState]);

  // Keyboard mapping for immediate real-life driver feedback (Task 4)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't interfere if user is typing in any text inputs
      if (
        document.activeElement?.tagName === "INPUT" ||
        document.activeElement?.tagName === "TEXTAREA"
      ) {
        return;
      }

      const key = e.key.toLowerCase();
      if (key === "w" || e.key === "ArrowUp") {
        setIsPressingThrottle(true);
        controller.setThrottle(1.0);
      } else if (key === "s" || e.key === "ArrowDown") {
        setIsPressingBrake(true);
        controller.setBraking(true);
      } else if (key === "e" || key === "d") {
        controller.shiftUp();
      } else if (key === "q" || key === "a") {
        controller.shiftDown();
      } else if (key === "n") {
        controller.toggleNeutral();
      } else if (key === "i") {
        controller.toggleIgnition();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (key === "w" || e.key === "ArrowUp") {
        setIsPressingThrottle(false);
        controller.setThrottle(0.0);
      } else if (key === "s" || e.key === "ArrowDown") {
        setIsPressingBrake(false);
        controller.setBraking(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [controller]);

  // Calculate dynamic angle for tachy dial display
  const maxRpm = car.limits.maxRPM || 7000;
  const rpmRatio = Math.min(1.0, controller.rpm / maxRpm);
  const rpmAngle = -90 + rpmRatio * 180; // Arc from 180deg left to right

  return (
    <div id="engine-dashboard-root" className="w-full bg-slate-950 text-white rounded-2xl border border-slate-800 p-6 shadow-2xl relative overflow-hidden font-sans">
      {/* Decorative dynamic neon grid lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(15,23,42,0.6)_1px,transparent_1px),linear-gradient(to_bottom,rgba(15,23,42,0.6)_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] pointer-events-none opacity-20" />

      {/* Header Info Block */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-800 pb-4 mb-6 relative z-10 gap-3">
        <div>
          <span className="text-[10px] font-mono tracking-wider text-emerald-400 font-bold bg-emerald-950/40 border border-emerald-900/50 px-2 py-0.5 rounded-full uppercase">
            {car.aspiration} {car.engineType} Sim Active
          </span>
          <h3 className="text-xl font-bold tracking-tight text-white mt-1">
            {car.brand} {car.name}
          </h3>
          <p className="text-xs text-slate-400 font-mono">
            Max Power: {Math.round(safeEngineState.hp)} HP | Weight: {safeEngineState.weight} kg
          </p>
        </div>

        {/* Action Controls Header */}
        <div className="flex items-center gap-2">
          <button
            id="toggle-ign-btn"
            onClick={controller.toggleIgnition}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-mono transition-all font-bold cursor-pointer ${
              controller.ignitionOn
                ? "bg-rose-950/40 border-rose-800 text-rose-300 hover:bg-rose-900/60"
                : "bg-emerald-950/40 border-emerald-800 text-emerald-300 hover:bg-emerald-900/60"
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${controller.ignitionOn ? "bg-rose-500 animate-pulse" : "bg-emerald-500"}`} />
            {controller.ignitionOn ? "IGNITION OFF" : "ENGINE START"}
          </button>

          <button
            id="toggle-mute-btn"
            onClick={onToggleMute}
            className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
              isMuted
                ? "bg-amber-950/30 border-amber-800/60 text-amber-400"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800"
            }`}
            title="Toggle Dashboard Sound"
          >
            {isMuted ? "🔇 Silent" : "🔊 Live Audio"}
          </button>
        </div>
      </div>

      {/* Simulation Cluster Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-10">
        
        {/* Visual GAUGE cluster - SVG speed / RPM curves */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          <EngineVisualizer
            rpm={controller.rpm}
            maxRpm={maxRpm}
            gear={controller.gear}
            isShifting={controller.isShifting}
            throttle={controller.throttle}
            isClipped={controller.isClipped}
            loudness={safeEngineState.loudness}
            roughness={safeEngineState.roughness}
          />

          {/* Sub-cluster with Gearbox, Velocity, and Optional BoostGauge */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            {/* CENTRE GEAR DISPLAY SCREEN */}
            <div className="flex flex-col items-center justify-center p-4 bg-slate-900/40 border border-slate-800/80 rounded-xl h-full">
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mb-2">GEARBOX</span>
              <div className="relative flex items-center justify-center">
                <span className={`text-6xl font-black font-mono leading-none ${
                  controller.gear === 0 ? "text-amber-400" : controller.isShifting ? "text-neutral-600 animate-pulse" : "text-emerald-400"
                }`}>
                  {controller.gear === 0 ? "N" : controller.gear}
                </span>
                {controller.clutchActive && (
                  <span className="absolute -top-1 -right-2 text-[8px] font-mono bg-red-950 text-red-400 px-1 border border-red-900 rounded font-bold animate-pulse">
                    CLUTCH
                  </span>
                )}
              </div>
              <span className="text-[10px] text-slate-400 font-mono mt-3">
                {controller.gear === 0 ? "Neutral Idle" : `Ratio: ${GEAR_RATIOS[controller.gear].toFixed(2)}`}
              </span>
            </div>

            {/* VELOCITY SCREEN */}
            <div className="flex flex-col items-center justify-center p-4 bg-slate-900/40 border border-slate-800/80 rounded-xl h-full">
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mb-2">Velocity</span>
              <div className="flex items-baseline gap-1 justify-center">
                <span className="text-5xl font-black font-mono text-white tracking-tight">
                  {controller.speed}
                </span>
                <span className="text-xs text-slate-400 font-mono uppercase">KM/H</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono mt-3 uppercase">
                {controller.isShifting ? "SHIFTING ACTIVE" : "SYNCHRONIZED"}
              </span>
            </div>

            {/* BOOST GAUGE CARD OR ASPECT CONTAINER */}
            <div className="sm:col-span-1">
              {car.aspiration === "Turbo" ? (
                <BoostGauge
                  boost={controller.boost}
                  maxBoost={car.limits.maxBoost || 1.8}
                />
              ) : (
                <div className="flex flex-col items-center justify-center p-4 bg-slate-900/10 border border-slate-800/40 rounded-xl h-full opacity-40 min-h-[148px]">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-black mb-1">INDUCTION</span>
                  <span className="text-xs font-mono text-slate-400 text-center uppercase tracking-wider">NATURALLY ASPIRATED</span>
                </div>
              )}
            </div>

          </div>
        </div>

        {/* Interactive Pedals and Driver Controls */}
        <div id="pedal-cluster" className="lg:col-span-4 flex flex-col gap-4">
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-xl p-4 flex flex-col gap-4">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">Foot pedals</span>
            
            {/* THROTTLE PEDAL CONTROLS */}
            <div className="flex flex-col gap-1.5">
              <div className="flex justify-between items-center text-xs text-slate-400">
                <span className="font-bold flex items-center gap-1">
                  <span className={`w-1.5 h-1.5 rounded-full ${isPressingThrottle ? "bg-amber-400 animate-ping" : "bg-slate-700"}`} />
                  Accelerator (Gas)
                </span>
                <span className="font-mono">{Math.round(controller.throttle * 100)}%</span>
              </div>
              
              {/* Click/Touch-Hold carbon gas pedal boundary */}
              <button
                id="gas-pedal"
                onMouseDown={() => {
                  if (controller.ignitionOn) {
                    setIsPressingThrottle(true);
                    controller.setThrottle(1.0);
                  }
                }}
                onMouseUp={() => {
                  setIsPressingThrottle(false);
                  controller.setThrottle(0.0);
                }}
                onMouseLeave={() => {
                  setIsPressingThrottle(false);
                  controller.setThrottle(0.0);
                }}
                onTouchStart={(e) => {
                  e.preventDefault();
                  if (controller.ignitionOn) {
                    setIsPressingThrottle(true);
                    controller.setThrottle(1.0);
                  }
                }}
                onTouchEnd={(e) => {
                  e.preventDefault();
                  setIsPressingThrottle(false);
                  controller.setThrottle(0.0);
                }}
                disabled={!controller.ignitionOn}
                className={`relative h-20 w-full rounded-xl border font-bold flex flex-col items-center justify-center cursor-pointer overflow-hidden select-none transition-all ${
                  !controller.ignitionOn
                    ? "bg-slate-950/20 border-slate-900 text-slate-600 cursor-not-allowed"
                    : isPressingThrottle
                    ? "bg-gradient-to-t from-orange-950/60 to-amber-950/40 border-amber-500 text-amber-200 shadow-[inset_0_0_12px_rgba(249,115,22,0.3)] scale-[0.98]"
                    : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-300"
                }`}
              >
                {/* Structural carbon fiber look-alike stripes */}
                <div className="absolute inset-0 bg-[linear-gradient(45deg,#000_25%,transparent_25%,transparent_50%,#000_50%,#000_75%,transparent_75%,transparent)] bg-[size:10px_10px] opacity-10" />
                <span className="text-sm tracking-wider uppercase font-mono relative z-10">
                  {isPressingThrottle ? "PEDAL FLOORED" : "HOLD ACCELERATOR"}
                </span>
                <span className="text-[10px] text-slate-500 font-normal mt-1 relative z-10">
                  Holds down throttle (W key / ArrowUp)
                </span>
                {/* Floating active meter strip */}
                <div
                  className="absolute bottom-0 left-0 h-1 bg-amber-500 transition-all duration-75"
                  style={{ width: `${controller.throttle * 100}%` }}
                />
              </button>
            </div>

            {/* MECHANICAL BRAKE PEDAL */}
            <div className="flex flex-col gap-1.5">
              <button
                id="brake-pedal"
                onMouseDown={() => {
                  setIsPressingBrake(true);
                  controller.setBraking(true);
                }}
                onMouseUp={() => {
                  setIsPressingBrake(false);
                  controller.setBraking(false);
                }}
                onMouseLeave={() => {
                  setIsPressingBrake(false);
                  controller.setBraking(false);
                }}
                onTouchStart={(e) => {
                  e.preventDefault();
                  setIsPressingBrake(true);
                  controller.setBraking(true);
                }}
                onTouchEnd={(e) => {
                  e.preventDefault();
                  setIsPressingBrake(false);
                  controller.setBraking(false);
                }}
                className={`relative h-14 w-full rounded-xl border font-bold flex flex-col items-center justify-center cursor-pointer select-none transition-all ${
                  isPressingBrake
                    ? "bg-rose-950/40 border-rose-600 text-rose-300 scale-[0.98]"
                    : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700"
                }`}
              >
                <span className="text-xs uppercase font-mono tracking-wider">
                  {isPressingBrake ? "BRAKES LOCKED" : "APPLY FOOT BRAKINGS"}
                </span>
                <span className="text-[9px] text-slate-500 mt-0.5">
                  Hold to decelerate speeds (S key / ArrowDown)
                </span>
              </button>
            </div>

            {/* MANUAL GEAR SHIFT ROW */}
            <div className="flex flex-col gap-1.5 border-t border-slate-800/60 pt-3">
              <span className="text-xs text-slate-400 font-bold block mb-1">Gearbox Control</span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  id="shift-down-btn"
                  onClick={controller.shiftDown}
                  disabled={!controller.ignitionOn || controller.gear <= 1}
                  className="px-2 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono font-bold hover:border-slate-600 disabled:opacity-40 disabled:hover:border-slate-800 cursor-pointer"
                >
                  ◀ DOWN (Q / A)
                </button>
                <button
                  id="toggle-neutral-btn"
                  onClick={controller.toggleNeutral}
                  disabled={!controller.ignitionOn}
                  className={`px-2 py-2 rounded-lg border text-xs font-mono font-bold cursor-pointer ${
                    controller.gear === 0 ? "bg-amber-950/20 border-amber-600 text-amber-400" : "bg-slate-950 border-slate-800"
                  }`}
                >
                  N (Neutral)
                </button>
                <button
                  id="shift-up-btn"
                  onClick={controller.shiftUp}
                  disabled={!controller.ignitionOn || controller.gear >= 6}
                  className="px-2 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono font-bold hover:border-slate-600 disabled:opacity-40 disabled:hover:border-slate-800 cursor-pointer"
                >
                  UP (E / D) ▶
                </button>
              </div>
            </div>

          </div>

          {/* KEYBOARD CONTROL REFERENCE LEGEND */}
          <div className="bg-slate-950 border border-slate-900 rounded-xl p-3 text-[11px] text-slate-400 font-mono leading-relaxed">
            <span className="font-bold text-[10px] text-slate-500 uppercase tracking-widest block mb-1">
              ⌨ Keyboard hotkeys
            </span>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1">
              <div><kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">W</kbd> / <kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">↑</kbd> : Gas Pedal</div>
              <div><kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">S</kbd> / <kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">↓</kbd> : Foot Brakes</div>
              <div><kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">E</kbd> / <kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">D</kbd> : Gear Up</div>
              <div><kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">Q</kbd> / <kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">A</kbd> : Gear Down</div>
              <div><kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">N</kbd> : Toggle Neutral</div>
              <div><kbd className="bg-slate-900 text-slate-200 px-1 border border-slate-800 rounded">I</kbd> : Ignition</div>
            </div>
          </div>

        </div>

      </div>

      {/* Performance telemetry diagnostics and dyno sweep (Task 5) */}
      <div className="mt-8 border-t border-slate-800/60 pt-8 relative z-10 flex flex-col gap-8">
        <PerformancePanel
          speed={controller.speed}
          accelerationRun={controller.accelerationRun}
          quarterMileRun={controller.quarterMileRun}
          dynoCurve={dynoCurve}
          onReset={controller.resetPerformanceRuns}
          currentRpm={controller.rpm}
          maxRpm={safeEngineState.rpmLimit}
          car={car}
          installedModIds={installedModIds}
          subParts={subParts}
        />
        <EngineHealthPanel
          health={controller.health}
          onRepair={controller.repairEngine}
        />
      </div>

    </div>
  );
}
