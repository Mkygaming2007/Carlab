import React, { useState, useMemo } from "react";
import {
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Info,
  Layers,
  Wrench,
  Sparkles,
  Gauge,
  TrendingUp,
  Weight,
  Volume2,
  HelpCircle,
  Eye,
  Sliders,
  AlertCircle
} from "lucide-react";
import { CarPlatform } from "../data/carDatabase";
import {
  VEHICLE_MODS_DATABASE,
  VehicleModification,
  ModificationCategory,
  checkModCompatibility,
  checkModificationDependencies,
  applySelectedModsToEngine
} from "../data/modsDatabase";

interface ModificationBrowserProps {
  activeCar?: CarPlatform;
  installedModIds?: string[];
  onToggleMod?: (modId: string) => void;
  engineState?: any;
  availableMods?: any[];
  appliedMods?: any[];
}

export const ModificationBrowser: React.FC<ModificationBrowserProps> = ({
  activeCar,
  installedModIds = [],
  onToggleMod = () => {},
  engineState,
  availableMods,
  appliedMods = [],
}) => {
  // TASK 1: FIX UNDEFINED STATE CRASHES
  if (!activeCar) return null;
  if (!engineState) return null;
  if (!availableMods) return [];

  // TASK 6: ADD LOADING STATE
  if (!activeCar || !VEHICLE_MODS_DATABASE || VEHICLE_MODS_DATABASE.length === 0) {
    return <div className="text-center font-mono text-slate-400 text-xs py-10" id="browser-loading">Loading mods...</div>;
  }

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<ModificationCategory | "All">("All");
  const [showOnlyCompatible, setShowOnlyCompatible] = useState(true);
  const [hoveredModId, setHoveredModId] = useState<string | null>(null);

  // Supported Categories matching specification
  const categories: (ModificationCategory | "All")[] = [
    "All",
    "Engine",
    "Forced Induction",
    "Fuel System",
    "Cooling",
    "Exhaust",
    "Suspension",
    "Brakes",
    "Wheels & Tires",
    "Drivetrain",
    "Aero",
    "Interior",
    "Exterior",
    "Offroad"
  ];

  // Map of category to visual colors/accents
  const getCategoryColor = (cat: ModificationCategory) => {
    switch (cat) {
      case "Engine": return "text-cyan-400 bg-cyan-955/20 border-cyan-800/40";
      case "Forced Induction": return "text-emerald-400 bg-emerald-955/20 border-emerald-800/40";
      case "Fuel System": return "text-purple-400 bg-purple-955/20 border-purple-800/40";
      case "Cooling": return "text-sky-400 bg-sky-955/20 border-sky-800/40";
      case "Exhaust": return "text-orange-400 bg-orange-955/20 border-orange-800/40";
      case "Suspension": return "text-indigo-400 bg-indigo-955/20 border-indigo-800/40";
      case "Brakes": return "text-rose-400 bg-rose-955/20 border-rose-800/40";
      case "Wheels & Tires": return "text-amber-400 bg-amber-955/20 border-amber-800/40";
      case "Drivetrain": return "text-fuchsia-400 bg-fuchsia-955/20 border-fuchsia-800/40";
      case "Aero": return "text-teal-400 bg-teal-955/20 border-teal-800/40";
      case "Interior": return "text-violet-400 bg-violet-955/20 border-violet-800/40";
      case "Exterior": return "text-pink-400 bg-pink-955/20 border-pink-800/40";
      case "Offroad": return "text-lime-400 bg-lime-955/20 border-lime-800/40";
      default: return "text-slate-400 bg-slate-950/20 border-slate-800/40";
    }
  };

  // Process and filter mods
  const processedMods = useMemo(() => {
    return VEHICLE_MODS_DATABASE.map(mod => {
      const compCheck = checkModCompatibility(mod, activeCar);
      const depCheck = checkModificationDependencies(mod, installedModIds);
      return {
        ...mod,
        isCompatible: compCheck.compatible,
        incompatibilityReason: compCheck.reason,
        isInstalled: installedModIds.includes(mod.id),
        unmetDependencies: depCheck.missing,
        hasUnmetDependencies: !depCheck.passes && installedModIds.includes(mod.id)
      };
    });
  }, [activeCar, installedModIds]);

  // Apply filters
  const filteredMods = useMemo(() => {
    return processedMods.filter(mod => {
      // 1. Category search matches
      if (selectedCategory !== "All" && mod.category !== selectedCategory) {
        return false;
      }

      // 2. Query search matches
      if (searchQuery.trim() !== "") {
        const query = searchQuery.toLowerCase();
        const matchesName = mod.name.toLowerCase().includes(query);
        const matchesDesc = mod.description.toLowerCase().includes(query);
        const matchesSpecs = mod.specs && Object.values(mod.specs).some(val => String(val).toLowerCase().includes(query));
        if (!matchesName && !matchesDesc && !matchesSpecs) return false;
      }

      // 3. Compatibility toggle restriction
      if (showOnlyCompatible && !mod.isCompatible) {
        return false;
      }

      return true;
    });
  }, [processedMods, selectedCategory, searchQuery, showOnlyCompatible]);

  // Net metrics of installed mods for the car
  const installedModsData = useMemo(() => {
    const installed = processedMods.filter(m => m.isInstalled);
    const totals = applySelectedModsToEngine(
      { hp: activeCar.stock.hp, torque: activeCar.stock.torque, weight: activeCar.stock.weight, loudness: 0, roughness: 0, brightness: 0, backfireRate: 0 },
      installed
    );

    // Collect any warning highlights (e.g. installed mods with unresolved requirements)
    const brokenDependenciesList = installed.filter(m => m.unmetDependencies.length > 0);

    return {
      count: installed.length,
      hpAdd: totals.hpAdd,
      torqueAdd: totals.torqueAdd,
      weightImpact: totals.weightImpact,
      sound: totals.soundImpact,
      brokenDependenciesList
    };
  }, [processedMods, activeCar]);

  // Calculate current hovered modification data preview
  const hoveredModInfo = useMemo(() => {
    if (!hoveredModId) return null;
    return VEHICLE_MODS_DATABASE.find(m => m.id === hoveredModId) || null;
  }, [hoveredModId]);

  return (
    <div className="w-full bg-[#07091a] p-4 sm:p-6 rounded-2xl border border-purple-500/10 flex flex-col gap-6" id="mod-browser-root">
      
      {/* Upper Status Banner & Active Profile Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-slate-900/60 p-4 rounded-xl border border-purple-500/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-[10px] font-mono font-bold text-purple-400 tracking-wider bg-purple-950/40 px-2 py-0.5 rounded border border-purple-800/30 uppercase">
              Sandbox Modification Core
            </span>
          </div>
          <h2 className="text-xl font-black font-mono text-slate-100 mt-1 uppercase tracking-tight">
            {activeCar.brand} {activeCar.name} <span className="text-sm font-light text-slate-400 uppercase tracking-widest">(Catalog)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Browse and hot-install authentic modifications. Entire catalog is unlocked and free.
          </p>
        </div>

        {/* Live Net Modification Package State */}
        <div className="flex flex-wrap gap-3 relative z-10 shrink-0">
          <div className="bg-slate-950/80 border border-slate-800 px-3 py-2 rounded-lg flex items-center gap-2">
            <div className="p-1 rounded bg-purple-950 border border-purple-800/40">
              <Layers className="w-4 h-4 text-purple-400" />
            </div>
            <div>
              <span className="text-[8px] text-slate-500 block uppercase font-mono">Installed Package</span>
              <span className="text-xs font-mono font-black text-slate-200">
                {installedModsData.count} Upgrade{installedModsData.count !== 1 ? "s" : ""}
              </span>
            </div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 px-3 py-2 rounded-lg flex items-center gap-2">
            <div className="p-1 rounded bg-cyan-950 border border-cyan-800/40">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <span className="text-[8px] text-slate-500 block uppercase font-mono">Tuning HP Shift</span>
              <span className={`text-xs font-mono font-black ${installedModsData.hpAdd >= 0 ? "text-cyan-400" : "text-rose-400"}`}>
                {installedModsData.hpAdd >= 0 ? "+" : ""}{installedModsData.hpAdd} HP
              </span>
            </div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 px-3 py-2 rounded-lg flex items-center gap-2">
            <div className="p-1 rounded bg-amber-950 border border-amber-800/40">
              <Weight className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <span className="text-[8px] text-slate-500 block uppercase font-mono">Dry Weight Shift</span>
              <span className={`text-xs font-mono font-black ${installedModsData.weightImpact <= 0 ? "text-emerald-400" : "text-amber-400"}`}>
                {installedModsData.weightImpact <= 0 ? "" : "+"}{installedModsData.weightImpact} kg
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Dependency Warning Bar */}
      {installedModsData.brokenDependenciesList.length > 0 && (
        <div className="bg-amber-950/30 border border-amber-600/40 rounded-xl p-3.5 flex items-start gap-3 text-amber-300">
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5 animate-pulse" />
          <div className="flex-1">
            <h4 className="text-xs font-extrabold font-mono tracking-wider uppercase">MODIFICATION DEPENDENCY WARNINGS</h4>
            <p className="text-[10px] text-amber-400/80 mt-0.5 leading-relaxed">
              The following installed hardware upgrades have uninstalled dependencies. They may struggle to run at full efficiency:
            </p>
            <div className="flex flex-wrap gap-2 mt-2">
              {installedModsData.brokenDependenciesList.map(mod => (
                <span key={mod.id} className="text-[10px] font-mono font-bold bg-amber-950/80 border border-amber-800/60 px-2.5 py-1 rounded inline-flex items-center gap-1 text-amber-300 uppercase">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
                  {mod.name}: Missing [{mod.unmetDependencies.map(d => d.name).join(", ")}]
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main filter, search and catalog block */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        
        {/* Left Grid: Browser filters & Catalog list (9 cols on xl) */}
        <div className="xl:col-span-8 flex flex-col gap-4">
          
          {/* Controls Bar: Search & Comp-Only Toggle */}
          <div className="bg-slate-900/40 border border-slate-800 p-3 rounded-xl flex flex-col sm:flex-row justify-between items-center gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search specs, brands, or descriptions..."
                className="w-full bg-slate-950 border border-slate-800 pl-9 pr-4 py-1.5 rounded-lg text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-purple-500 transition"
              />
            </div>

            <label className="flex items-center gap-2 cursor-pointer text-xs font-mono text-slate-400 select-none">
              <input
                type="checkbox"
                checked={showOnlyCompatible}
                onChange={(e) => setShowOnlyCompatible(e.target.checked)}
                className="rounded border-slate-800 text-purple-600 focus:ring-purple-500 focus:ring-offset-slate-900 bg-slate-950 w-4 h-4 checked:bg-purple-600 focus:ring-1"
              />
              <span>Filter Only {activeCar.brand} Compatible Upgrades</span>
            </label>
          </div>

          {/* Horizontal Category Filters list */}
          <div className="flex gap-1.5 overflow-x-auto pb-2 no-scrollbar scroll-smooth whitespace-nowrap">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition cursor-pointer shrink-0 ${
                    isSelected
                      ? "bg-purple-600 text-white shadow shadow-purple-950/60"
                      : "bg-slate-900 text-slate-400 hover:bg-slate-850 hover:text-slate-200 border border-slate-800/40"
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {/* Cards Display Grid */}
          {filteredMods.length === 0 ? (
            <div className="bg-slate-900/20 border border-slate-800/40 rounded-xl p-12 text-center text-slate-500 font-mono text-xs uppercase flex flex-col items-center gap-2">
              <HelpCircle className="w-8 h-8 text-slate-600" />
              <p>No specifications matched current filters.</p>
              <button
                onClick={() => { setSearchQuery(""); setSelectedCategory("All"); setShowOnlyCompatible(false); }}
                className="mt-3 px-4 py-1.5 bg-slate-800 text-slate-300 text-[10px] uppercase font-bold rounded-lg hover:bg-slate-700 transition"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[55vh] overflow-y-auto pr-1">
              {filteredMods.map((mod) => {
                const dynamicDep = checkModificationDependencies(mod, installedModIds);
                const hasPendingDependency = !dynamicDep.passes;

                return (
                  <div
                    key={mod.id}
                    className={`relative bg-slate-950 border rounded-xl p-4 flex flex-col justify-between transition-all duration-200 group ${
                      mod.isInstalled
                        ? "border-purple-500 bg-purple-950/5 shadow-md shadow-purple-950/20"
                        : "border-slate-800 hover:border-slate-705 bg-slate-950/40"
                    }`}
                    onMouseEnter={() => setHoveredModId(mod.id)}
                    onMouseLeave={() => setHoveredModId(null)}
                  >
                    <div>
                      {/* Top status bar of card */}
                      <div className="flex justify-between items-start gap-2 mb-2">
                        <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded border ${getCategoryColor(mod.category)}`}>
                          {mod.category.toUpperCase()}
                        </span>

                        <span className="text-[10px] font-mono text-slate-500 font-bold">
                          {mod.minVal !== undefined && mod.maxVal !== undefined ? (
                            `Adj: ${mod.minVal}-${mod.maxVal} ${mod.unit || ""}`
                          ) : (
                            "Bespoke Bolt-On"
                          )}
                        </span>
                      </div>

                      {/* Header title */}
                      <h3 className="text-sm font-extrabold font-mono text-slate-200 group-hover:text-purple-400 transition leading-snug">
                        {mod.name}
                      </h3>
                      
                      {/* Description */}
                      <p className="text-[11px] text-slate-400 mt-1 lines-clamp-2 leading-relaxed">
                        {mod.description}
                      </p>

                      {/* Specs attributes table */}
                      {mod.specs && (
                        <div className="grid grid-cols-2 gap-x-3 gap-y-1 mt-3 pt-2.5 border-t border-slate-900 text-[9px] font-mono text-slate-500 uppercase">
                          {Object.entries(mod.specs).map(([key, val]) => (
                            <div key={key} className="flex justify-between">
                              <span className="text-slate-600 truncate mr-1">{key}:</span>
                              <span className="text-slate-400 font-bold truncate max-w-[65px]">{val}</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Incompatibility notification */}
                      {!mod.isCompatible && (
                        <div className="mt-3 bg-red-950/35 border border-red-900/30 p-2 rounded flex items-start gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                          <span className="text-[9px] font-mono text-rose-400 leading-normal uppercase">
                            {mod.incompatibilityReason}
                          </span>
                        </div>
                      )}

                      {/* Pending Dependencies warning block */}
                      {mod.dependencies && mod.dependencies.length > 0 && (
                        <div className="mt-2 text-[9px] font-mono flex flex-col gap-0.5 text-slate-500">
                          <span className="text-slate-600 text-[8px] uppercase font-bold tracking-wider">Required Pre-requisite:</span>
                          <span className={`${hasPendingDependency ? "text-amber-400/80" : "text-emerald-400/80"} uppercase inline-flex items-center gap-1`}>
                            {hasPendingDependency ? <AlertTriangle className="w-3 h-3 text-amber-500" /> : <CheckCircle2 className="w-3 h-3 text-emerald-500" />}
                            {mod.dependencies.map(depId => VEHICLE_MODS_DATABASE.find(m => m.id === depId)?.name || depId).join(", ")}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Footer Toggle / Action Button */}
                    <div className="mt-4 pt-3 border-t border-slate-900/60 flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">
                        {mod.hpBonus > 0 ? (
                          <span className="text-cyan-400">+{mod.hpBonus} HP Impact</span>
                        ) : mod.hpBonus < 0 ? (
                          <span className="text-rose-400">{mod.hpBonus} HP Res</span>
                        ) : (
                          "Structural Aero"
                        )}
                      </span>

                      <button
                        onClick={() => onToggleMod(mod.id)}
                        disabled={!mod.isCompatible}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-mono font-bold uppercase cursor-pointer transition ${
                          mod.isInstalled
                            ? "bg-purple-900 hover:bg-purple-800 text-white border border-purple-500"
                            : "bg-slate-900 hover:bg-slate-800 text-slate-350 hover:text-white border border-slate-800 disabled:opacity-30 disabled:cursor-not-allowed"
                        }`}
                      >
                        {mod.isInstalled ? "Uninstall Setup" : "Hot Install"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>

        {/* Right Grid: Live Active Modification Spec Preview / Help Panel (4 cols on xl) */}
        <div className="xl:col-span-4 flex flex-col gap-4">
          
          {/* Active Hover / Real-time Spec Preview Shield */}
          <div className="bg-slate-900/40 border border-slate-800 p-4 rounded-xl flex-1 flex flex-col gap-5 justify-between relative overflow-hidden">
            <div className="absolute top-0 left-0 p-8 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />
            
            <div>
              <div className="flex items-center gap-1.5 border-b border-slate-800 pb-2.5">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <h4 className="text-xs font-bold font-mono text-cyan-400 uppercase tracking-widest">
                  Live Modification Overlay
                </h4>
              </div>

              {hoveredModInfo ? (
                // Active Hover Preview State
                <div className="mt-4 animate-fadeIn flex flex-col gap-4">
                  <div>
                    <span className="text-[8px] font-mono text-slate-500 uppercase">Interactive Preview</span>
                    <h5 className="text-sm font-extrabold font-mono text-cyan-300 uppercase leading-snug">
                      {hoveredModInfo.name}
                    </h5>
                    <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                      {hoveredModInfo.description}
                    </p>
                  </div>

                  {/* HP & Torque bar preview */}
                  <div className="space-y-2.5 bg-slate-950/80 border border-slate-850 p-3 rounded-lg">
                    <span className="text-[8px] font-mono text-cyan-400 uppercase tracking-wider block font-bold">Estimated Dyno Shift</span>
                    
                    <div>
                      <div className="flex justify-between text-[9px] font-mono text-slate-400 uppercase mb-0.5">
                        <span>HORSEPOWER IMPACT</span>
                        <span className={`font-bold ${hoveredModInfo.hpBonus >= 0 ? "text-cyan-400" : "text-rose-400"}`}>
                          {hoveredModInfo.hpBonus >= 0 ? "+" : ""}{hoveredModInfo.hpBonus} HP
                        </span>
                      </div>
                      <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-cyan-400 h-full transition-all"
                          style={{ width: `${Math.min(100, (Math.abs(hoveredModInfo.hpBonus) / 210) * 100)}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-[9px] font-mono text-slate-400 uppercase mb-0.5">
                        <span>TORQUE IMPACT</span>
                        <span className={`font-bold ${hoveredModInfo.torqueBonus >= 0 ? "text-cyan-400" : "text-rose-400"}`}>
                          {hoveredModInfo.torqueBonus >= 0 ? "+" : ""}{hoveredModInfo.torqueBonus} Nm
                        </span>
                      </div>
                      <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-cyan-400 h-full transition-all"
                          style={{ width: `${Math.min(100, (Math.abs(hoveredModInfo.torqueBonus) / 260) * 100)}%` }}
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-[9px] font-mono text-slate-400 uppercase mb-0.5">
                        <span>WEIGHT SHIFT</span>
                        <span className={`font-bold ${hoveredModInfo.weightImpact <= 0 ? "text-emerald-400" : "text-amber-400"}`}>
                          {hoveredModInfo.weightImpact <= 0 ? "" : "+"}{hoveredModInfo.weightImpact} kg
                        </span>
                      </div>
                      <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-amber-400 h-full transition-all"
                          style={{ width: `${Math.min(100, (Math.abs(hoveredModInfo.weightImpact) / 50) * 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Sound parameters shift */}
                  {hoveredModInfo.soundImpact && (
                    <div className="bg-slate-950/40 p-2.5 rounded-lg border border-slate-800 flex flex-col gap-1 text-[9px] font-mono text-slate-400">
                      <span className="text-cyan-400 font-bold text-[8px] uppercase tracking-wider mb-1 flex items-center gap-1">
                        <Volume2 className="w-3.5 h-3.5" />
                        ACOUSTIC FREQUENCY MODIFICATIONS
                      </span>
                      {hoveredModInfo.soundImpact?.loudness && (
                        <div className="flex justify-between">
                          <span>Db Amplitude:</span>
                          <span className="text-slate-300 font-bold">+{Math.round((hoveredModInfo.soundImpact?.loudness ?? 0) * 100)}%</span>
                        </div>
                      )}
                      {hoveredModInfo.soundImpact?.roughness && (
                        <div className="flex justify-between">
                          <span>Idling Roughness (Lope):</span>
                          <span className="text-slate-300 font-bold">+{Math.round((hoveredModInfo.soundImpact?.roughness ?? 0) * 100)}%</span>
                        </div>
                      )}
                      {hoveredModInfo.soundImpact?.brightness && (
                        <div className="flex justify-between">
                          <span>Manifold Brightness / Resonance:</span>
                          <span className="text-slate-300 font-bold">+{Math.round((hoveredModInfo.soundImpact?.brightness ?? 0) * 100)}%</span>
                        </div>
                      )}
                      {hoveredModInfo.soundImpact?.backfireRate && (
                        <div className="flex justify-between">
                          <span>Muffler Backfire / Ignition Retard Pop:</span>
                          <span className="text-slate-300 font-bold">+{Math.round((hoveredModInfo.soundImpact?.backfireRate ?? 0) * 100)}%</span>
                        </div>
                      )}
                    </div>
                  )}

                </div>
              ) : (
                // Standby / Empty hover state
                <div className="mt-8 text-center py-10 flex flex-col items-center gap-3 text-slate-500 uppercase font-mono text-[10px]">
                  <Eye className="w-8 h-8 text-slate-700 animate-pulse" />
                  <p className="max-w-[190px] leading-relaxed">
                    Hover over or tap any modification block to visualize dyno curve overlay displacement.
                  </p>
                </div>
              )}
            </div>

            {/* Explanatory footer guideline box */}
            <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800 text-[10px] font-mono text-slate-400 leading-normal">
              <span className="text-purple-400 font-bold uppercase block mb-1">AUTOMOTIVE ADVICE</span>
              <p>
                Ensure to follow realistic modification dependencies to guarantee maximum compression. Massive setups (like Greddy Big Turbos or 3.8L Superchargers) will restrict horsepower outputs if high pressure fuel hangars or aluminum heat exchangers are absent.
              </p>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
