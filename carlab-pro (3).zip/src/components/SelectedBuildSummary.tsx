import React, { useMemo } from "react";
import { 
  Sparkles, 
  TrendingUp, 
  Zap, 
  Weight, 
  Volume2, 
  Check, 
  Trash2,
  Settings,
  Flame,
  AlertTriangle,
  Info
} from "lucide-react";
import { CarPlatform } from "../data/carDatabase";
import { 
  VEHICLE_MODS_DATABASE, 
  VehicleModification, 
  applySelectedModsToEngine, 
  checkModificationDependencies 
} from "../data/modsDatabase";
import { ShareBuildButton } from "./ShareBuildButton";

interface SelectedBuildSummaryProps {
  activeCar: CarPlatform;
  installedModIds: string[];
  onRemoveMod: (modId: string) => void;
  onClearAll: () => void;
  subParts?: Record<string, string>;
}

export const SelectedBuildSummary: React.FC<SelectedBuildSummaryProps> = ({
  activeCar,
  installedModIds,
  onRemoveMod,
  onClearAll,
  subParts
}) => {
  // Retrieve installed modifications
  const installedMods = useMemo(() => {
    return VEHICLE_MODS_DATABASE.filter(mod => installedModIds.includes(mod.id));
  }, [installedModIds]);

  // Total calculations
  const totals = useMemo(() => {
    return applySelectedModsToEngine(
      { 
        hp: activeCar.stock.hp, 
        torque: activeCar.stock.torque, 
        weight: activeCar.stock.weight, 
        loudness: 0, 
        roughness: 0, 
        brightness: 0, 
        backfireRate: 0 
      },
      installedMods
    );
  }, [activeCar, installedMods]);

  const finalHP = (activeCar?.stock?.hp ?? 0) + (totals?.hpAdd ?? 0);
  const finalTorque = (activeCar?.stock?.torque ?? 0) + (totals?.torqueAdd ?? 0);
  const finalWeight = Math.max(200, (activeCar?.stock?.weight ?? 0) + (totals?.weightImpact ?? 0));

  // Analyze if there are missing dependencies among active mods
  const brokenDependencies = useMemo(() => {
    return installedMods.filter(mod => {
      const check = checkModificationDependencies(mod, installedModIds);
      return !check.passes;
    });
  }, [installedMods, installedModIds]);

  // Sound ratings calculation (relative offsets + defaults)
  const soundProfile = useMemo(() => {
    const l = Math.max(0, Math.min(100, 30 + Math.round((totals?.soundImpact?.loudness ?? 0) * 100)));
    const r = Math.max(0, Math.min(100, 20 + Math.round((totals?.soundImpact?.roughness ?? 0) * 100)));
    const b = Math.max(0, Math.min(100, 40 + Math.round((totals?.soundImpact?.brightness ?? 0) * 100)));
    const f = Math.max(0, Math.min(100, 10 + Math.round((totals?.soundImpact?.backfireRate ?? 0) * 100)));
    return { l, r, b, f };
  }, [totals]);

  return (
    <div className="w-full bg-slate-950/90 border border-purple-500/10 rounded-2xl p-5 flex flex-col gap-5 relative overflow-hidden h-full shadow-2xl" id="selected-build-summary">
      <div className="absolute top-0 right-0 p-12 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
      
      {/* Header section */}
      <div className="relative z-10 flex justify-between items-center border-b border-slate-900 pb-3">
        <div>
          <span className="text-[9px] font-mono font-black text-purple-400 uppercase tracking-widest block">Garage Setup</span>
          <h3 className="text-sm font-black font-mono text-slate-100 uppercase tracking-tight flex items-center gap-1.5">
            <Settings className="w-3.5 h-3.5 text-purple-400 animate-spin-slow" />
            Active Modifications
          </h3>
        </div>
        {installedModIds.length > 0 && (
          <button
            onClick={onClearAll}
            className="text-[9px] font-mono font-bold text-rose-400 hover:text-rose-350 flex items-center gap-1 uppercase transition border border-rose-950 px-2 py-1 rounded bg-rose-955/10 bg-opacity-10 cursor-pointer"
          >
            <Trash2 className="w-3 h-3" />
            Clear Config
          </button>
        )}
      </div>

      {/* Main Aggressive Metrics Output Gauges */}
      <div className="grid grid-cols-2 gap-3 relative z-10">
        <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-900/60 flex flex-col justify-center">
          <span className="text-[8px] text-slate-500 uppercase font-mono block mb-0.5">Peak Horsepower</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black font-mono text-cyan-400 leading-none">
              {finalHP}
            </span>
            <span className="text-xs font-mono text-slate-500 font-bold uppercase">HP</span>
          </div>
          <span className="text-[9px] font-mono text-cyan-500/80 mt-1 font-bold">
            {totals.hpAdd >= 0 ? "+" : ""}{totals.hpAdd} HP Shift
          </span>
        </div>

        <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-900/60 flex flex-col justify-center">
          <span className="text-[8px] text-slate-500 uppercase font-mono block mb-0.5">Peak Drive Torque</span>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black font-mono text-fuchsia-400 leading-none">
              {finalTorque}
            </span>
            <span className="text-xs font-mono text-slate-500 font-bold uppercase">Nm</span>
          </div>
          <span className="text-[9px] font-mono text-fuchsia-500/80 mt-1 font-bold">
            {totals.torqueAdd >= 0 ? "+" : ""}{totals.torqueAdd} Nm Shift
          </span>
        </div>

        <div className="col-span-2 bg-slate-900/30 p-2.5 rounded-lg border border-slate-900 flex justify-between items-center">
          <div className="flex items-center gap-1.5">
            <Weight className="w-3.5 h-3.5 text-amber-500" />
            <span className="text-[10px] text-slate-400 font-mono uppercase">Vessel Weight:</span>
          </div>
          <span className="text-xs font-mono font-bold text-slate-250">
            {finalWeight} kg <span className="text-slate-500 text-[9px]">({totals.weightImpact <= 0 ? "" : "+"}{totals.weightImpact} kg)</span>
          </span>
        </div>
      </div>

      {/* Dependency alerts */}
      {brokenDependencies.length > 0 && (
        <div className="bg-amber-950/20 border border-amber-600/30 rounded-xl p-3 flex items-start gap-2 relative z-10 text-amber-300">
          <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-[9px] font-black font-mono tracking-wider uppercase">Active Setup Incompletely Configured</h4>
            <div className="mt-1 space-y-1">
              {brokenDependencies.map(mod => (
                <div key={mod.id} className="text-[9px] text-amber-400/80 font-mono Leading-snug">
                  • <span className="font-bold">{mod.name}</span> requires: {mod.dependencies?.map(depId => VEHICLE_MODS_DATABASE.find(m => m.id === depId)?.name || depId).join(", ")}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Acoustic Frequency modifications */}
      <div className="space-y-3 relative z-10 bg-slate-900/40 p-3.5 rounded-xl border border-slate-900">
        <h4 className="text-[9px] font-black font-mono text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
          <Volume2 className="w-3.5 h-3.5" />
          Acoustic Frequency Profile
        </h4>

        <div className="space-y-2 text-[9px] font-mono uppercase text-slate-400">
          {/* Loudness */}
          <div>
            <div className="flex justify-between mb-0.5">
              <span>DB Amplitude (Volume)</span>
              <span className="text-slate-300 font-bold">{soundProfile.l}%</span>
            </div>
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div className="bg-purple-500 h-full transition-all duration-300" style={{ width: `${soundProfile.l}%` }} />
            </div>
          </div>

          {/* Roughness */}
          <div>
            <div className="flex justify-between mb-0.5">
              <span>Roughness (Lumpy Lope IDLE)</span>
              <span className="text-slate-300 font-bold">{soundProfile.r}%</span>
            </div>
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div className="bg-orange-500 h-full transition-all duration-300" style={{ width: `${soundProfile.r}%` }} />
            </div>
          </div>

          {/* Brightness */}
          <div>
            <div className="flex justify-between mb-0.5">
              <span>Manifold Resonance (High Brightness)</span>
              <span className="text-slate-300 font-bold">{soundProfile.b}%</span>
            </div>
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div className="bg-cyan-500 h-full transition-all duration-300" style={{ width: `${soundProfile.b}%` }} />
            </div>
          </div>

          {/* Backfire Rates */}
          <div>
            <div className="flex justify-between mb-0.5">
              <span>Muffler Pop & Crackle Rate</span>
              <span className="text-slate-300 font-bold">{soundProfile.f}%</span>
            </div>
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div className="bg-rose-500 h-full transition-all duration-300" style={{ width: `${soundProfile.f}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* Installed modifications checklist split */}
      <div className="flex-1 flex flex-col gap-2 relative z-10 overflow-hidden">
        <h4 className="text-[9px] font-black font-mono text-slate-500 uppercase tracking-widest border-b border-slate-900 pb-1.5">
          Applied Hardware List ({installedMods.length})
        </h4>

        {installedMods.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 text-slate-600 font-mono text-[10px] uppercase">
            <Zap className="w-6 h-6 text-slate-800 mb-1 animate-pulse" />
            No Upgrades Stacked
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto pr-1 space-y-1.5 max-h-[30vh]">
            {installedMods.map(mod => {
              const check = checkModificationDependencies(mod, installedModIds);
              return (
                <div 
                  key={mod.id}
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-900 hover:border-slate-800 transition"
                >
                  <div className="flex items-center gap-2 max-w-[75%]">
                    <span className="p-0.5 rounded bg-purple-950/80 border border-purple-800/20 text-purple-400">
                      <Check className="w-3 h-3" />
                    </span>
                    <div className="truncate">
                      <span className="text-[10px] font-mono font-bold text-slate-300 truncate block uppercase leading-snug">
                        {mod.name}
                      </span>
                      <span className="text-[8px] font-mono text-slate-500 uppercase leading-none">
                        {mod.category} • {mod.hpBonus > 0 ? `+${mod.hpBonus} HP` : mod.hpBonus < 0 ? `${mod.hpBonus} HP` : "0 HP"}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => onRemoveMod(mod.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-955/10 rounded cursor-pointer transition shrink-0"
                    title="Remove Modification"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="mt-2 border-t border-slate-900 pt-4 relative z-10">
        <ShareBuildButton
          car={activeCar}
          installedModIds={installedModIds}
          engineState={{ horsepower: finalHP, torque: finalTorque }}
          subParts={subParts}
        />
      </div>

    </div>
  );
};
