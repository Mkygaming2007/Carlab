import { EngineState } from "./data/modificationRules";

// Task 1: Dyno Point interface
export interface DynoPoint {
  rpm: number;
  horsepower: number;
  torque: number;
}

// Task 1: Generate dynamic, realistic torque and HP curves based on modification rules
export function generateDynoCurve(engineState: EngineState): DynoPoint[] {
  const points: DynoPoint[] = [];
  const startRpm = 1000;
  const endRpm = engineState.rpmLimit;
  const step = 100;

  for (let rpm = startRpm; rpm <= endRpm; rpm += step) {
    // Peak torque usually peaks mid-range around 65% of the redline
    const peakTorqueRpm = Math.floor(engineState.rpmLimit * 0.65);
    
    // Parabolic distribution for torque centered around peakTorqueRpm
    const dist = (rpm - peakTorqueRpm) / (engineState.rpmLimit * 0.5);
    const torqueMult = Math.max(0.45, 1.0 - 0.4 * Math.pow(dist, 2));
    
    const pointTorque = engineState.torque * torqueMult;
    
    // HP calculation: HP = (Torque_Nm * RPM) / 9549 or standard metric/imperial scaling
    const rawHp = (pointTorque * rpm) / 5252;
    points.push({
      rpm,
      torque: pointTorque,
      horsepower: rawHp
    });
  }

  // Rescale curves to perfectly align with peak engine parameters
  const maxHp = Math.max(...points.map(p => p.horsepower));
  const maxTorque = Math.max(...points.map(p => p.torque));

  const hpScale = maxHp > 0 ? engineState.hp / maxHp : 1;
  const torqueScale = maxTorque > 0 ? engineState.torque / maxTorque : 1;

  return points.map(p => ({
    rpm: p.rpm,
    horsepower: Math.round(p.horsepower * hpScale),
    torque: Math.round(p.torque * torqueScale)
  }));
}

// Task 2: Acceleration Run State
export interface AccelerationRun {
  startTime: number | null;
  endTime: number | null;
  timeTo100: number | null;
  isActive: boolean;
}

// Task 3: Quarter Mile Run State
export interface QuarterMileRun {
  startTime: number | null;
  endTime: number | null;
  elapsedTime: number | null;
  trapSpeed: number | null;
  distance: number;
  isActive: boolean;
}

// Task 4: Real-time update logic for 0-100 acceleration timer
export function updateAccelerationRun(
  run: AccelerationRun,
  speedKmh: number,
  elapsedSec: number
): AccelerationRun {
  const result = { ...run };

  // Setup start trigger when speed increases from rest
  if (result.startTime === null && speedKmh > 0.2) {
    result.startTime = elapsedSec;
    result.isActive = true;
    result.endTime = null;
    result.timeTo100 = null;
  }

  if (result.isActive && result.startTime !== null) {
    const runTime = elapsedSec - result.startTime;

    if (speedKmh >= 100) {
      result.endTime = elapsedSec;
      result.timeTo100 = runTime;
      result.isActive = false;
    }
  }

  return result;
}

// Task 4: Real-time update logic for Quarter Mile speed tracker
export function updateQuarterMile(
  run: QuarterMileRun,
  speedKmh: number,
  dt: number,
  elapsedSec: number
): QuarterMileRun {
  const result = { ...run };

  // Setup start trigger when speed increases from rest
  if (result.startTime === null && speedKmh > 0.2) {
    result.startTime = elapsedSec;
    result.isActive = true;
    result.distance = 0;
    result.elapsedTime = null;
    result.trapSpeed = null;
    result.endTime = null;
  }

  if (result.isActive && result.startTime !== null) {
    const speedMs = speedKmh / 3.6;
    result.distance += speedMs * dt;
    const runTime = elapsedSec - result.startTime;

    if (result.distance >= 402) {
      result.isActive = false;
      result.endTime = elapsedSec;
      result.elapsedTime = runTime;
      result.trapSpeed = speedKmh;
    }
  }

  return result;
}
